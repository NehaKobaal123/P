# Architecture

This document explains how NexusCRM is structured and the main engineering
decisions behind it.

## Design goals

1. **Runnable with zero configuration.** The product must work the moment it's
   cloned — hence a demo adapter that needs no backend.
2. **Backend-swappable without UI churn.** Presentation code depends on an
   interface, not on a storage mechanism.
3. **Deterministic, auditable metrics.** Every number is derived from records by
   a pure function, so it can be reasoned about and unit-tested.
4. **Accessible, consistent, responsive** across the whole product.

## Layers

```
┌───────────────────────────────────────────────┐
│  App Router pages  (src/app)                   │  Route + composition
├───────────────────────────────────────────────┤
│  Feature components (src/components/*)          │  Presentation
├───────────────────────────────────────────────┤
│  React Query hooks  (src/hooks/use-crm.ts)      │  Server-state cache
├───────────────────────────────────────────────┤
│  CrmService interface (src/services)            │  ← the seam
│    ├─ LocalCrmService  (IndexedDB / Dexie)      │  ← default, standalone
│    └─ Supabase adapter (schema + client; future)│
├───────────────────────────────────────────────┤
│  Pure domain logic (src/lib: metrics, business) │  Framework-free, tested
├───────────────────────────────────────────────┤
│  Domain model (src/types/domain.ts)             │  Single source of truth
└───────────────────────────────────────────────┘
```

### The data-access seam

`src/services/crm-service.ts` defines `CrmService` — every read and write the app
performs, as async methods. Screens obtain it via `getService()` and never import
a concrete adapter. This is what makes the backend swappable:

- `LocalCrmService` (`src/services/local/`) persists an **IndexedDB** database
  via **Dexie**. It loads the dataset into an in-memory cache once, applies
  mutations through pure business rules, writes the cache back to IndexedDB on
  every change (so data survives refreshes), and records activity-log entries.
  `src/services/local/dexie.ts` defines the Dexie schema; `demo-db.ts` owns the
  cache/persist/reset logic.
- A Supabase adapter would implement the same interface over the schema in
  `supabase/migrations` — an optional future backend, not required to run.

### Why IndexedDB (not localStorage)

IndexedDB is asynchronous, far larger, and robust for structured records, so the
whole dataset (and settings/session preferences) persists reliably across
refreshes. Dexie gives it a typed, ergonomic API. Reads/writes are guarded so
SSR, static prerendering and private-mode all degrade gracefully.

Because the interface is the only contract, **no component changes** when the
backend changes.

### Server state vs client state

- **TanStack Query** owns everything that comes from the service — one query key
  per entity plus a whole-database query the dashboard/analytics aggregate over.
  Mutations invalidate the affected caches so all screens stay consistent.
- **Zustand** owns the little genuinely-client state: sidebar collapse and
  workspace preferences, each persisted per browser.
- Drag-and-drop uses an **optimistic update with rollback** (`useReorderDeal`):
  the card moves instantly, and reverts with a toast if the write fails.

### Pure domain logic

`src/lib/metrics.ts` and `src/lib/business.ts` contain no React and no I/O:

- `metrics.ts` — KPI calculations, time series, funnels, rep performance,
  forecasts and date-range math. Every dashboard/analytics figure routes through
  here.
- `business.ts` — `convertLead` (idempotent, de-duplicating), deal reordering
  with stable re-indexing, and order helpers.

Keeping these pure makes them trivially testable (`src/tests`) and is why metrics
are deterministic rather than hard-coded.

### Metric definitions (transparency)

| Metric | Definition |
| --- | --- |
| Total Revenue | Σ value of `won` deals (closed in range for the KPI) |
| Active Customers | customers with `status = active` |
| Active Deals | deals in `new`/`qualified`/`proposal`/`negotiation` |
| Conversion Rate | converted leads ÷ all leads created in range |
| Win Rate | won ÷ (won + lost) |
| Avg Deal Value | won revenue ÷ won count |
| Weighted Forecast | Σ (open deal value × stage probability) |
| Revenue Growth | % change of in-range revenue vs the previous equal period |

Forecasts are explicitly labelled as probability-weighted estimates, never
guaranteed revenue.

## Design system

Tokens are CSS variables (`src/app/globals.css`) as HSL channels so Tailwind's
opacity modifiers work. Semantic names (`surface`, `primary`, `destructive`,
`sidebar`, …) are mapped in `tailwind.config.ts` and re-defined under `.dark`, so
dark mode is one source of truth. Reusable primitives live in
`src/components/ui`; feature-specific components compose them.

## Routing

- `src/app/page.tsx` — public landing page.
- `src/app/(auth)/*` — auth screens with a dedicated split layout.
- `src/app/(app)/*` — the authenticated shell (sidebar + top bar) wrapping
  dashboard, customers (+detail), leads (+detail), deals, tasks, analytics, team,
  activity, settings, profile, plus `loading`, `error` and `unauthorized`.
- `not-found.tsx` and `error.tsx` provide global 404 and error boundaries.

### Static export & routing

The app is configured for **static export** (`output: "export"` in
`next.config.ts`), producing a static `out/` directory with no server
dependencies. Because records are created at runtime in the browser, detail
pages use a `?id=` **query parameter** (`/customers/record?id=…`, see
`src/lib/routes.ts`) rather than dynamic `[id]` segments — this keeps every route
statically renderable. Pages that read query params are wrapped in `<Suspense>`
as the export requires.

### Simulated roles

`src/stores/session-store.ts` records the chosen demo role (admin / manager /
rep) — a **simulation**, not secure auth. `usePermissions()` derives UI
permissions from `src/lib/permissions.ts`, gating actions like delete and role
changes. A real deployment would enforce the same rules server-side (the
Supabase RLS policies already do).

## Security model (Supabase path)

Authorization is enforced in the database, not the client:

- **Tenant isolation** — every row carries `organization_id`; RLS exposes only
  rows in the caller's organization.
- **Role-based access** — `admin`/`manager`/`rep` map to concrete policies that
  mirror `src/lib/permissions.ts`.
- **Least privilege** — only the anon key reaches the browser; the service-role
  key is never shipped.

See `supabase/migrations/0002_policies.sql`.

## Deployment

The app builds to a static `out/` directory and hosts anywhere static, with **no
environment variables**. For **Cloudflare Pages**: build command `npm run build`,
output directory `out`. The same works on Netlify, GitHub Pages, S3, or Vercel
(static). See the README for step-by-step Cloudflare Pages settings.

## Testing strategy

- **Unit/component (Vitest + Testing Library)** — pure logic and representative
  components; fast and deterministic, run on every push.
- **E2E (Playwright)** — user journeys against the built app; run in CI with
  installed browsers.
- **CI (GitHub Actions)** — type-check → lint → unit tests → production build,
  plus a separate E2E job. See `.github/workflows/ci.yml`.
