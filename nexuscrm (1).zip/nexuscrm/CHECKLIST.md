# Feature completion checklist

Status of the acceptance requirements. "Demo" = fully functional against the
local demo adapter; "Supabase" = schema/policies/seam provided, adapter not
wired end-to-end.

## Pages & navigation
- [x] Landing page (hero, preview, features, workflow, analytics preview, CTA, footer)
- [x] Sign in / Register / Forgot / Reset password (validated; demo bypass)
- [x] Dashboard (6 KPIs, 4 charts, recent deals, upcoming tasks, activity, top reps)
- [x] Customers list + Customer detail
- [x] Leads list + Lead detail
- [x] Deals pipeline (Kanban)
- [x] Tasks (list + board)
- [x] Analytics
- [x] Team management
- [x] Activity log
- [x] Settings + User profile
- [x] 404, error boundary, loading, unauthorized screens
- [x] All navigation works

## Functionality
- [x] Customer CRUD, search, status/industry filter, multi-column sort, pagination
- [x] Customer bulk selection + bulk delete, CSV export, related activity
- [x] Lead CRUD, advanced filtering, assignment, status updates
- [x] Lead conversion → creates/links customer + deal, transactional & de-duplicated
- [x] Deals: drag-and-drop + keyboard stage moves, create/edit/delete, detail drawer
- [x] Deals: owner/stage filters, pipeline/forecast/win-rate summaries, optimistic UI + rollback
- [x] Tasks: CRUD, list + board, due dates, overdue indicators, completion tracking, relations
- [x] Analytics: trends, funnel, win/loss, rep performance, sources, avg value, growth, forecast, CSV
- [x] Team: directory, role labels, in-place role changes, workload, permission matrix
- [x] Activity: searchable/filterable/paginated audit trail
- [x] Settings: theme, org, notifications; Profile view
- [x] Form validation (Zod) across all forms
- [x] Loading, empty and error states throughout
- [x] Reusable component library
- [x] Readable, strict TypeScript (no `any`)

## Data & security
- [x] Deterministic, database-backed analytics (no random KPIs)
- [x] Working, isolated demo mode with Reset Demo
- [x] Normalized Postgres schema + migrations (Supabase)
- [x] Row Level Security policies + role matrix (Supabase)
- [x] Auth profile provisioning trigger (Supabase)
- [~] Supabase runtime adapter — **interface, client & schema provided; adapter not wired end-to-end**
- [~] Live authentication — **UI + schema provided; activates with Supabase**

## Quality
- [x] TypeScript check passes (`npm run typecheck`)
- [x] Lint passes (`npm run lint`)
- [x] 28 unit/component tests pass (`npm run test`)
- [x] Production build passes (`npm run build`)
- [x] Playwright E2E specs provided (run in CI with installed browsers)
- [x] Responsive 375 → 1920px, dark mode, keyboard nav, reduced-motion
- [x] README, ARCHITECTURE, DEVELOPMENT_GUIDE, Supabase docs
- [x] GitHub Actions CI (type-check, lint, test, build, E2E)
- [x] `.env.example`, Vercel-ready configuration

Legend: [x] done · [~] partial (documented).
