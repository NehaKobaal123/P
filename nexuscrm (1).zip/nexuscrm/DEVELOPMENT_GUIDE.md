# Development Guide

A beginner-friendly tour of how NexusCRM works and where to find things. If
you're new to this codebase (or to React/Next.js), start here.

## 1. The big picture in one minute

- It's a **Next.js** app. Pages live in `src/app`. A folder with a `page.tsx`
  becomes a URL (`src/app/(app)/customers/page.tsx` → `/customers`).
- Data is **not** hard-coded into components. Components ask a small set of
  **hooks** for data; the hooks ask a **service**; the service reads/writes a
  **demo database** kept in your browser.
- All the "business maths" (revenue, conversion rate, moving a deal) lives in
  plain functions in `src/lib` that don't know anything about React.

So the flow is:

```
page/component  →  hook (useCustomers…)  →  service (CrmService)  →  demo database
                        ↑                                                 │
                        └──────────────── metrics/business logic ─────────┘
```

## 2. Where everything lives

```
src/
  app/                 Pages & layouts (the routes)
    (auth)/            Sign in / register / password screens
    (app)/             The logged-in app: dashboard, customers, deals, …
  components/
    ui/                Reusable building blocks (Button, Card, Table, Dialog…)
    layout/            Sidebar, top bar, navigation, brand
    common/            Shared bits (PageHeader, badges, pagination, forms)
    charts/            Recharts chart components
    customers/ leads/ deals/ tasks/   Feature-specific components (forms, cards)
    dashboard/         KPI card and date-range filter
    marketing/         Landing-page pieces
  hooks/               React Query hooks + small helpers (useDebounce, lookups)
  services/            The data layer (interface + demo adapter + Supabase)
  lib/                 Pure logic: metrics, business rules, utils, csv, permissions
  stores/              Zustand stores (sidebar, settings)
  types/               The domain model (Customer, Deal, Lead, …)
  tests/               Vitest unit & component tests
supabase/              SQL schema, RLS policies, seed (optional backend)
e2e/                   Playwright end-to-end tests
```

## 3. The domain model (`src/types/domain.ts`)

This file defines the shape of every business object — `Customer`, `Lead`,
`Deal`, `Task`, `TeamMember`, `ActivityLog` — and the allowed values for things
like deal stages and lead statuses. **Everything else builds on these types.** If
you want to understand the app, read this file first.

Records are connected like a real CRM:

- a **Customer** is assigned to a team member (`assignedRepId`);
- a **Deal** belongs to a customer (`customerId`) and an owner (`ownerId`);
- a **Lead**, when converted, points to the customer and deal it created;
- a **Task** can relate to a customer and/or a deal.

## 4. How a component gets data (hooks)

Open `src/hooks/use-crm.ts`. It exposes hooks like `useCustomers()`,
`useCreateCustomer()`, `useDeals()`, `useReorderDeal()`. These wrap
**TanStack Query**:

- **Queries** (reads) cache their result. `useCustomers()` gives you
  `{ data, isLoading }`.
- **Mutations** (writes) change data and then *invalidate* the caches so the
  screen refreshes automatically. They also pop a toast on success/failure.

Example from the customers page:

```tsx
const { data: customers, isLoading } = useCustomers();
const createMut = useCreateCustomer();
// …later…
await createMut.mutateAsync(formValues); // creates + refreshes the list + toast
```

You rarely call the service directly — you use these hooks.

## 5. The service layer (the clever part)

`src/services/crm-service.ts` is an **interface**: a list of every data
operation, like `listCustomers()`, `createDeal()`, `convertLead()`. Think of it
as a contract.

`src/services/local/local-crm-service.ts` is the **standalone implementation** of
that contract. It stores everything in **IndexedDB** using Dexie:
`src/services/local/dexie.ts` defines the database, and `demo-db.ts` loads it
into memory, writes changes back after every edit (so your data survives a page
refresh), and can reset to the seed. It also writes an entry to the activity log
for important changes — the same way a real server would keep an audit trail.

Why bother with an interface? Because a real backend (e.g. the **Supabase**
schema in `supabase/`) can implement the exact same contract later. You'd write
one new adapter file and return it from `getService()` — and **not a single page
or component would change**. That's the whole point of the design.

## 6. The business logic (`src/lib`)

These files are plain TypeScript functions with no React — which makes them easy
to test and reuse.

- **`metrics.ts`** — turns records into numbers: `totalRevenue(deals)`,
  `conversionRate(leads)`, `revenueByMonth(deals)`, `repPerformance(db)`, and so
  on. The dashboard and analytics pages call these; they never invent numbers.
- **`business.ts`** — the rules:
  - `convertLead(...)` creates (or links) a customer and a deal from a lead, and
    refuses to run twice on the same lead (so you can't create duplicates).
  - `reorderDealToStage(...)` works out the new order of cards when you drag a
    deal to a new column.
- **`utils.ts`** — formatting helpers (`formatCurrency`, `initials`, `cn`).
- **`csv.ts`** — turns a list of rows into a downloadable CSV.
- **`permissions.ts`** — the role → permission matrix shown on the Team page.

## 7. State management, simply

- **Server data** (customers, deals…) → TanStack Query (the hooks above), backed
  by IndexedDB.
- **Preferences & session** (sidebar, theme, settings, the chosen demo role) →
  Zustand stores in `src/stores`, persisted to IndexedDB (the sidebar uses
  `localStorage`; the theme is handled by next-themes).
- **Form state** → React Hook Form, with **Zod** describing what a valid form
  looks like. See any `*-form-dialog.tsx` for the pattern.

## 7a. Roles & the demo login

`src/stores/session-store.ts` holds the chosen demo role. It is a **simulation**,
not real authentication. `usePermissions()` (`src/hooks/use-session.ts`) reads
the role and tells components what's allowed via `src/lib/permissions.ts`, so
things like delete buttons appear only for roles that may delete. The sign-in
page (`src/app/(auth)/sign-in/page.tsx`) is the role picker.

## 7b. Routes

Internal links go through `src/lib/routes.ts`. Detail pages use a `?id=` query
param (e.g. `/customers/record?id=…`) instead of `[id]` segments, which is what
makes the app work as a **static export** on Cloudflare Pages.

## 8. Building blocks (`src/components/ui`)

These are small, reusable, accessible components built on Radix UI primitives:
`Button`, `Card`, `Dialog`, `Sheet` (drawer), `Select`, `Table`, `Tabs`,
`Badge`, `Checkbox`, `Switch`, `Tooltip`, `Skeleton`, `EmptyState`,
`ConfirmDialog`, and more. Feature components combine these rather than
re-styling from scratch, which keeps the whole app visually consistent.

## 9. Charts

`src/components/charts/crm-charts.tsx` wraps **Recharts** into ready-made charts
(revenue area chart, stage bar chart, source donut, etc.). They share a common
tooltip and colour palette from `chart-kit.tsx`, so every chart looks like part
of one system.

## 10. Common tasks

**Add a field to Customer**

1. Add it to the `Customer` type in `src/types/domain.ts`.
2. Add it to `CustomerInput` in `src/services/crm-service.ts`.
3. Add an input to `src/components/customers/customer-form-dialog.tsx` (and its
   Zod schema).
4. Show it in the table/detail pages if you want it visible.

**Add a new metric to the dashboard**

1. Write a pure function in `src/lib/metrics.ts` and a test in `src/tests`.
2. Use it in `src/app/(app)/dashboard/page.tsx`.

**Connect Supabase** — see `supabase/README.md`.

## 11. Running and checking the project

```bash
npm run dev         # develop locally
npm run typecheck   # TypeScript check
npm run lint        # ESLint
npm run test        # unit & component tests
npm run build       # production build
```

If all of these pass, your change is in good shape. CI runs the same steps on
every push.
