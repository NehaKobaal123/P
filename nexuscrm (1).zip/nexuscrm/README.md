# NexusCRM — *Your Business. In Command.*

NexusCRM is an enterprise **Customer Relationship Management & Business
Intelligence** web application. It brings customers, leads, deals, tasks,
analytics, team management and an activity audit trail into one connected
workspace.

It is a **complete, standalone frontend application**: all data lives in your
browser via **IndexedDB (Dexie)**, so there is **no backend, database, or API
key to configure**. It deploys as a fully static site to **Cloudflare Pages**
(or any static host), and its architecture still leaves a clean seam for adding
a real backend later.

> Portfolio project. Not affiliated with any real company. All data is synthetic
> and generated locally in your browser.

---

## Screenshots

| Demo login (simulated roles) | Landing |
| --- | --- |
| ![Sign in](docs/screenshots/sign-in.png) | ![Landing](docs/screenshots/landing.png) |

| Dashboard (light) | Dashboard (dark) |
| --- | --- |
| ![Dashboard](docs/screenshots/dashboard.png) | ![Dashboard dark](docs/screenshots/dashboard-dark.png) |

| Sales pipeline | Analytics |
| --- | --- |
| ![Deals](docs/screenshots/deals.png) | ![Analytics](docs/screenshots/analytics.png) |

---

## Features

- **Demo login with simulated roles** — choose **Administrator**, **Manager** or
  **Sales Representative**. Roles are clearly labelled as *simulated* (no real
  authentication) and drive role-based UI permissions (e.g. only managers/admins
  can delete; only admins change roles).
- **Executive dashboard** — six KPI tiles scoped to a 7/30/90-day or custom
  range, plus revenue, monthly-sales, pipeline-by-stage and lead-source charts,
  recent deals, upcoming tasks, recent activity and a top-reps board. Every
  figure is computed from the stored records.
- **Customers** — full CRUD, search, filter by status and industry, multi-column
  sort, pagination, bulk selection + delete, CSV export, a detail view with
  related deals/tasks/activity, and validated forms.
- **Leads** — full CRUD, advanced filtering, and **lead conversion** that creates
  (or links) a customer and opens a deal, idempotently and without duplicates.
- **Sales pipeline** — an interactive **drag-and-drop Kanban** with
  keyboard-accessible stage moves, a deal detail drawer, owner filtering,
  pipeline/forecast/win-rate summaries, and optimistic updates with rollback.
- **Tasks** — list **and** board views, completion tracking, overdue indicators,
  priorities, assignees and customer/deal relations.
- **Analytics** — revenue trends, a conversion funnel, win/loss, rep performance,
  lead sources, average deal value, customer growth and a probability-weighted
  forecast, with CSV export.
- **Team** — directory with per-member workload, in-place role changes (admins)
  and an explicit **role → permission matrix**.
- **Activity log** — a searchable, filterable, paginated audit trail.
- **Settings & profile** — theme (light/dark/system), organization and
  notification preferences, and a reset-demo control.
- **Polish** — responsive 375 → 1920px, full dark theme, keyboard navigation,
  focus states, loading skeletons, empty/error states, toasts, confirmation
  dialogs and reduced-motion support.

## Technology stack

| Area | Choices |
| --- | --- |
| Framework | Next.js 15 (App Router, **static export**), React 19, TypeScript (strict) |
| Styling | Tailwind CSS v3, CSS-variable design tokens, Radix UI primitives, Geist font |
| Persistence | **IndexedDB via Dexie** (local, offline-capable, survives refresh) |
| Server state | TanStack Query v5 |
| Client state | Zustand (UI, settings, session) |
| Forms | React Hook Form + Zod |
| Charts | Recharts |
| Drag & drop | dnd-kit |
| Testing | Vitest + Testing Library (unit/component), Playwright (E2E) |
| Tooling | ESLint, GitHub Actions CI |
| Future backend (optional) | Supabase schema + RLS provided, not required |

## Architecture overview

Screens never touch storage directly. They depend on a single **`CrmService`**
interface (`src/services/crm-service.ts`). The default implementation,
**`LocalCrmService`**, reads and writes an **IndexedDB** database through Dexie
(`src/services/local/`). Because the interface is the only contract, a real
backend (e.g. the Supabase schema in `supabase/`) can be added later as another
adapter **without changing any UI**.

Business rules (KPI math, lead conversion, deal ordering) live in pure,
unit-tested functions under `src/lib`. See [ARCHITECTURE.md](ARCHITECTURE.md) and
[DEVELOPMENT_GUIDE.md](DEVELOPMENT_GUIDE.md).

## Getting started

Requires Node 20+.

```bash
npm install
npm run dev            # http://localhost:3000
```

Open `/`, click **Explore Live Demo** (or **Sign in** to pick a role).

## Demo data & persistence

- A realistic synthetic dataset (team, customers, leads, deals, tasks, activity)
  is generated deterministically on first run and stored in **IndexedDB**.
- All CRUD changes **persist across browser refreshes** — they are saved to
  IndexedDB, isolated to your browser, and never sent anywhere or shared between
  users.
- **Reset demo data** any time from **Settings → Reset demo data** or the profile
  menu to restore the seeded dataset.
- Settings and the chosen demo role are also stored in IndexedDB.

## Demo login & roles

The sign-in screen is a **simulated** role picker — there is no password and no
real authentication. The chosen role (Administrator / Manager / Sales
Representative) adjusts what the UI allows, matching the permission matrix on the
Team page. Switch roles any time from the profile menu → **Switch role**.

## Testing

```bash
npm run typecheck      # tsc --noEmit
npm run lint           # next lint
npm run test           # Vitest unit + component tests (28 tests)
npm run build          # static export to out/
npm run preview        # serve the built out/ locally
npm run test:e2e       # Playwright (run `npx playwright install` first)
```

## Deployment — Cloudflare Pages

The app builds to a fully static `out/` directory (`output: "export"`), so it
hosts anywhere static.

**Cloudflare Pages:**

1. Push the repo to GitHub.
2. In Cloudflare Pages, **Create a project → Connect to Git** and select the repo.
3. Build settings:
   - **Framework preset:** Next.js (Static HTML Export) — or "None".
   - **Build command:** `npm run build`
   - **Build output directory:** `out`
4. Deploy. No environment variables are required.

Any other static host (Vercel static, Netlify, GitHub Pages, S3) works the same
way: build command `next build`, output directory `out`.

## Publishing to GitHub

```bash
git add .
git commit -m "Your message"
git branch -M main
git remote add origin https://github.com/<you>/nexuscrm.git
git push -u origin main
```

## Known limitations

- Data is **per-browser** (IndexedDB) — it is not shared between devices or
  users, by design. This is a standalone frontend, not a multi-user backend.
- The demo login is **simulated**, not secure authentication.
- Metrics are anchored to a fixed demo "today" so charts stay meaningful; a real
  backend would use the live clock.
- A Supabase schema, RLS policies and client are included as an **optional,
  future** backend path (`supabase/`), but are not required and not wired in.

## License

MIT — see [LICENSE](LICENSE). Provided as a portfolio demonstration.
