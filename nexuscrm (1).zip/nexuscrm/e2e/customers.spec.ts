import { test, expect } from "@playwright/test";

test.describe("Customers", () => {
  test("creates a customer through the dialog", async ({ page }) => {
    await page.goto("/customers");
    await page.getByRole("button", { name: /Add customer/i }).first().click();

    const dialog = page.getByRole("dialog");
    await expect(dialog).toBeVisible();
    await dialog.getByLabel("Contact name").fill("Dana E2E");
    await dialog.getByLabel("Company").fill("E2E Test Co");
    await dialog.getByLabel("Email").fill("dana@e2etest.com");
    await dialog.getByLabel("Phone").fill("+1 (555) 123-4567");
    await dialog.getByRole("button", { name: /Create customer/i }).click();

    await expect(page.getByText("Dana E2E")).toBeVisible();
  });

  test("filters customers by search", async ({ page }) => {
    await page.goto("/customers");
    await page.getByLabel("Search customers").fill("zzz-no-match-zzz");
    await expect(page.getByText(/No customers found/i)).toBeVisible();
  });
});
