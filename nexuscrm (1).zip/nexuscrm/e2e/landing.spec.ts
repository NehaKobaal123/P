import { test, expect } from "@playwright/test";

test.describe("Landing page", () => {
  test("shows the hero and primary CTAs", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("heading", { name: /In Command/i })).toBeVisible();
    await expect(page.getByRole("link", { name: /Explore Live Demo/i }).first()).toBeVisible();
  });

  test("Explore Live Demo navigates into the dashboard", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("link", { name: /Explore Live Demo/i }).first().click();
    await expect(page).toHaveURL(/\/dashboard/);
    await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
  });
});
