import { test, expect } from "@playwright/test";

test.describe("Application navigation", () => {
  test("pipeline board renders all stage columns", async ({ page }) => {
    await page.goto("/deals");
    await expect(page.getByRole("heading", { name: "Sales Pipeline" })).toBeVisible();
    for (const stage of ["New Opportunity", "Qualified", "Proposal Sent", "Negotiation", "Won", "Lost"]) {
      await expect(page.getByRole("heading", { name: stage })).toBeVisible();
    }
  });

  test("analytics page renders charts and KPIs", async ({ page }) => {
    await page.goto("/analytics");
    await expect(page.getByRole("heading", { name: "Analytics" })).toBeVisible();
    await expect(page.getByText("Total revenue")).toBeVisible();
    await expect(page.getByRole("heading", { name: "Revenue trends" })).toBeVisible();
  });

  test("mobile viewport exposes the drawer navigation trigger", async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 800 });
    await page.goto("/dashboard");
    await expect(page.getByRole("button", { name: /Open navigation/i })).toBeVisible();
  });
});
