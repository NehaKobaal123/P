import type { NextConfig } from "next";

/**
 * Static export for Cloudflare Pages (and any static host).
 *
 * The whole app is client-rendered against IndexedDB, so it has no
 * server-dependent features — `output: "export"` emits a fully static `out/`
 * directory. Detail pages use `?id=` query params (see src/lib/routes.ts)
 * rather than dynamic `[id]` segments, which keeps them static-compatible.
 */
const nextConfig: NextConfig = {
  output: "export",
  images: { unoptimized: true },
  trailingSlash: true,
};

export default nextConfig;
