"use client";

import * as React from "react";
import { Activity as ActivityIcon, Search } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { DataPagination } from "@/components/common/data-pagination";
import { MemberTag } from "@/components/common/member-tag";
import { useActivity } from "@/hooks/use-crm";
import { useMemberMap } from "@/hooks/use-lookups";
import { useDebounce } from "@/hooks/use-debounce";
import { type ActivityAction } from "@/types/domain";
import { format } from "date-fns";

const ACTION_LABELS: Record<ActivityAction, string> = {
  "customer.created": "Customer created",
  "customer.updated": "Customer updated",
  "customer.deleted": "Customer deleted",
  "lead.created": "Lead created",
  "lead.updated": "Lead updated",
  "lead.converted": "Lead converted",
  "deal.created": "Deal created",
  "deal.updated": "Deal updated",
  "deal.stage_changed": "Deal stage changed",
  "deal.deleted": "Deal deleted",
  "task.created": "Task created",
  "task.completed": "Task completed",
  "task.assigned": "Task assigned",
  "team.role_changed": "Role changed",
};

const TARGET_TYPES = ["customer", "lead", "deal", "task", "member"] as const;
const PAGE_SIZE = 12;

export default function ActivityPage() {
  const { data: activity, isLoading } = useActivity();
  const memberMap = useMemberMap();

  const [search, setSearch] = React.useState("");
  const debounced = useDebounce(search);
  const [targetType, setTargetType] = React.useState("all");
  const [page, setPage] = React.useState(1);

  React.useEffect(() => setPage(1), [debounced, targetType]);

  const filtered = React.useMemo(() => {
    let rows = activity ?? [];
    const q = debounced.trim().toLowerCase();
    if (q) rows = rows.filter((a) => a.targetLabel.toLowerCase().includes(q) || a.detail.toLowerCase().includes(q));
    if (targetType !== "all") rows = rows.filter((a) => a.targetType === targetType);
    return rows;
  }, [activity, debounced, targetType]);

  const pageRows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  return (
    <div className="space-y-6">
      <PageHeader title="Activity Log" description="An audit trail of significant changes across the workspace." />

      <Card>
        <div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search activity…" className="pl-9" aria-label="Search activity" />
          </div>
          <Select value={targetType} onValueChange={setTargetType}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {TARGET_TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="space-y-2 p-4">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-14" />)}</div>
        ) : filtered.length === 0 ? (
          <div className="p-6"><EmptyState icon={ActivityIcon} title="No activity found" description="Try a different search or filter." /></div>
        ) : (
          <>
            <ul className="divide-y divide-border">
              {pageRows.map((a) => (
                <li key={a.id} className="flex items-center gap-4 p-4">
                  <MemberTag member={memberMap[a.actorId]} className="[&_span]:hidden" />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium">{memberMap[a.actorId]?.name ?? "System"}</span>
                      <Badge variant="outline" className="capitalize">{ACTION_LABELS[a.action]}</Badge>
                    </div>
                    <p className="truncate text-sm text-muted-foreground">
                      {a.detail} · {a.targetLabel}
                    </p>
                  </div>
                  <time className="shrink-0 text-xs text-muted-foreground" dateTime={a.createdAt}>
                    {format(new Date(a.createdAt), "MMM d, h:mma")}
                  </time>
                </li>
              ))}
            </ul>
            <div className="border-t border-border px-4">
              <DataPagination page={page} pageSize={PAGE_SIZE} total={filtered.length} onPageChange={setPage} />
            </div>
          </>
        )}
      </Card>
    </div>
  );
}
