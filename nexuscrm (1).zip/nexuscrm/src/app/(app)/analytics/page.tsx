"use client";

import { Download } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  CountAreaChart,
  RepPerformanceBarChart,
  RevenueAreaChart,
  SourceDonutChart,
  StageBarChart,
  TrendLineChart,
} from "@/components/charts/crm-charts";
import { useDatabase } from "@/hooks/use-crm";
import {
  averageDealValue,
  avgDealValueByMonth,
  customerGrowthByMonth,
  dealsByStage,
  forecastPipelineValue,
  leadsBySource,
  repPerformance,
  revenueByMonth,
  salesFunnel,
  totalRevenue,
  winRate,
} from "@/lib/metrics";
import { downloadCsv, toCsv } from "@/lib/csv";
import { formatCompactCurrency, formatCurrency, formatPercent } from "@/lib/utils";

export default function AnalyticsPage() {
  const { data: db, isLoading } = useDatabase();

  if (isLoading || !db) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-56" />
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
        <Skeleton className="h-80" />
      </div>
    );
  }

  const revenue = revenueByMonth(db.deals);
  const funnel = salesFunnel(db);
  const sources = leadsBySource(db.leads);
  const stages = dealsByStage(db.deals).filter((s) => s.stage !== "lost");
  const reps = repPerformance(db)
    .filter((r) => r.wonValue > 0)
    .map((r) => ({ name: r.member.name, value: r.wonValue }));
  const avgByMonth = avgDealValueByMonth(db.deals);
  const growth = customerGrowthByMonth(db.customers);
  const wonDeals = db.deals.filter((d) => d.stage === "won").length;
  const lostDeals = db.deals.filter((d) => d.stage === "lost").length;

  function exportSummary() {
    const csv = toCsv(revenue, [
      { header: "Month", value: (r) => r.month },
      { header: "Revenue (USD)", value: (r) => r.revenue },
      { header: "Deals won", value: (r) => r.deals },
    ]);
    downloadCsv("nexuscrm-analytics-revenue.csv", csv);
  }

  const maxFunnel = funnel[0]?.count || 1;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Analytics"
        description="Performance across revenue, pipeline, conversion and team — computed from live records."
        actions={
          <Button variant="outline" onClick={exportSummary}>
            <Download className="size-4" /> Export CSV
          </Button>
        }
      />

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total revenue" value={formatCurrency(totalRevenue(db.deals))} hint="Closed-won, all time" />
        <StatCard label="Win rate" value={formatPercent(winRate(db.deals))} hint={`${wonDeals} won · ${lostDeals} lost`} />
        <StatCard label="Avg deal value" value={formatCurrency(averageDealValue(db.deals))} hint="Per closed-won deal" />
        <StatCard
          label="Weighted forecast"
          value={formatCompactCurrency(forecastPipelineValue(db.deals))}
          hint="Open pipeline × stage probability"
        />
      </section>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle>Revenue trends</CardTitle>
          <Badge variant="outline">Last 12 months</Badge>
        </CardHeader>
        <CardContent>
          <RevenueAreaChart data={revenue} />
        </CardContent>
      </Card>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Sales conversion funnel</CardTitle></CardHeader>
          <CardContent className="space-y-4 pt-2">
            {funnel.map((step, i) => {
              const pct = (step.count / maxFunnel) * 100;
              const conversion = i === 0 ? 100 : funnel[0].count === 0 ? 0 : (step.count / funnel[0].count) * 100;
              return (
                <div key={step.label}>
                  <div className="mb-1.5 flex items-center justify-between text-sm">
                    <span className="font-medium">{step.label}</span>
                    <span className="text-muted-foreground">
                      {step.count} · {formatPercent(conversion, 0)}
                    </span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-surface-muted">
                    <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${Math.max(pct, 3)}%` }} />
                  </div>
                </div>
              );
            })}
            <p className="pt-2 text-xs text-muted-foreground">
              Forecast figures are probability-weighted estimates, not guaranteed revenue.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Rep performance (closed-won)</CardTitle></CardHeader>
          <CardContent>
            {reps.length ? (
              <RepPerformanceBarChart data={reps} />
            ) : (
              <p className="py-12 text-center text-sm text-muted-foreground">No closed-won deals yet.</p>
            )}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Lead sources</CardTitle></CardHeader>
          <CardContent>
            {sources.length ? <SourceDonutChart data={sources} /> : <p className="py-12 text-center text-sm text-muted-foreground">No lead data.</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Pipeline stage distribution</CardTitle></CardHeader>
          <CardContent>
            <StageBarChart data={stages} />
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Average deal value</CardTitle></CardHeader>
          <CardContent>
            <TrendLineChart data={avgByMonth} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Customer growth</CardTitle></CardHeader>
          <CardContent>
            <CountAreaChart data={growth} seriesName="Total customers" />
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

function StatCard({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <Card className="p-5">
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className="mt-2 text-kpi tabular-nums">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </Card>
  );
}
