"use client";

import * as React from "react";
import Link from "next/link";
import { Download, MoreHorizontal, Plus, Search, Trash2, Users } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { DataPagination } from "@/components/common/data-pagination";
import { SortableHeader, type SortDirection } from "@/components/common/sortable-header";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { CustomerStatusBadge } from "@/components/common/status-badges";
import { MemberTag } from "@/components/common/member-tag";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CustomerFormDialog } from "@/components/customers/customer-form-dialog";
import { useCustomers, useDeleteCustomers } from "@/hooks/use-crm";
import { usePermissions } from "@/hooks/use-session";
import { useMemberMap } from "@/hooks/use-lookups";
import { useDebounce } from "@/hooks/use-debounce";
import {
  type Customer,
  CUSTOMER_STATUSES,
  CUSTOMER_STATUS_LABELS,
  INDUSTRIES,
} from "@/types/domain";
import { downloadCsv, toCsv } from "@/lib/csv";
import { routes } from "@/lib/routes";
import { format } from "date-fns";

type SortKey = "name" | "company" | "status" | "createdAt";
const PAGE_SIZE = 8;

export default function CustomersPage() {
  const { data: customers, isLoading } = useCustomers();
  const memberMap = useMemberMap();
  const deleteMut = useDeleteCustomers();
  const { can } = usePermissions();
  const canDelete = can("delete");

  const [search, setSearch] = React.useState("");
  const debounced = useDebounce(search);
  const [status, setStatus] = React.useState("all");
  const [industry, setIndustry] = React.useState("all");
  const [sortKey, setSortKey] = React.useState<SortKey>("createdAt");
  const [sortDir, setSortDir] = React.useState<SortDirection>("desc");
  const [page, setPage] = React.useState(1);
  const [selected, setSelected] = React.useState<Set<string>>(new Set());

  const [formOpen, setFormOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Customer | undefined>();
  const [toDelete, setToDelete] = React.useState<string[] | null>(null);

  React.useEffect(() => setPage(1), [debounced, status, industry]);

  const filtered = React.useMemo(() => {
    let rows = customers ?? [];
    const q = debounced.trim().toLowerCase();
    if (q) {
      rows = rows.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.company.toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q),
      );
    }
    if (status !== "all") rows = rows.filter((c) => c.status === status);
    if (industry !== "all") rows = rows.filter((c) => c.industry === industry);

    const dir = sortDir === "asc" ? 1 : -1;
    return [...rows].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      return String(av).localeCompare(String(bv)) * dir;
    });
  }, [customers, debounced, status, industry, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageRows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const pageIds = pageRows.map((r) => r.id);
  const allOnPageSelected = pageIds.length > 0 && pageIds.every((id) => selected.has(id));

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("asc");
    }
  }

  function toggleSelectAll() {
    setSelected((prev) => {
      const next = new Set(prev);
      if (allOnPageSelected) pageIds.forEach((id) => next.delete(id));
      else pageIds.forEach((id) => next.add(id));
      return next;
    });
  }

  function toggleRow(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function exportCsv() {
    const csv = toCsv(filtered, [
      { header: "Name", value: (c) => c.name },
      { header: "Company", value: (c) => c.company },
      { header: "Email", value: (c) => c.email },
      { header: "Phone", value: (c) => c.phone },
      { header: "Industry", value: (c) => c.industry },
      { header: "Status", value: (c) => CUSTOMER_STATUS_LABELS[c.status] },
      { header: "Representative", value: (c) => memberMap[c.assignedRepId]?.name ?? "" },
      { header: "Created", value: (c) => c.createdAt.slice(0, 10) },
    ]);
    downloadCsv("nexuscrm-customers.csv", csv);
  }

  async function confirmDelete() {
    if (!toDelete) return;
    await deleteMut.mutateAsync(toDelete);
    setSelected((prev) => {
      const next = new Set(prev);
      toDelete.forEach((id) => next.delete(id));
      return next;
    });
    setToDelete(null);
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Customers"
        description="Manage accounts, contacts and lifecycle across your book of business."
        actions={
          <>
            <Button variant="outline" onClick={exportCsv} disabled={filtered.length === 0}>
              <Download className="size-4" /> Export CSV
            </Button>
            <Button
              onClick={() => {
                setEditing(undefined);
                setFormOpen(true);
              }}
            >
              <Plus className="size-4" /> Add customer
            </Button>
          </>
        }
      />

      <Card>
        <div className="flex flex-col gap-3 border-b border-border p-4 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, company or email…"
              className="pl-9"
              aria-label="Search customers"
            />
          </div>
          <div className="flex gap-3">
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {CUSTOMER_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>{CUSTOMER_STATUS_LABELS[s]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={industry} onValueChange={setIndustry}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All industries</SelectItem>
                {INDUSTRIES.map((i) => (
                  <SelectItem key={i} value={i}>{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {selected.size > 0 && canDelete && (
          <div className="flex items-center justify-between gap-3 border-b border-border bg-primary/5 px-4 py-2.5">
            <p className="text-sm font-medium">{selected.size} selected</p>
            <Button variant="destructive" size="sm" onClick={() => setToDelete([...selected])}>
              <Trash2 className="size-4" /> Delete selected
            </Button>
          </div>
        )}

        {isLoading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState
              icon={Users}
              title="No customers found"
              description="Try adjusting your search or filters, or add a new customer."
              action={
                <Button onClick={() => { setEditing(undefined); setFormOpen(true); }}>
                  <Plus className="size-4" /> Add customer
                </Button>
              }
            />
          </div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox
                      checked={allOnPageSelected ? true : selected.size > 0 && pageIds.some((id) => selected.has(id)) ? "indeterminate" : false}
                      onCheckedChange={toggleSelectAll}
                      aria-label="Select all on page"
                    />
                  </TableHead>
                  <TableHead>
                    <SortableHeader label="Customer" active={sortKey === "name"} direction={sortDir} onClick={() => toggleSort("name")} />
                  </TableHead>
                  <TableHead className="hidden md:table-cell">
                    <SortableHeader label="Company" active={sortKey === "company"} direction={sortDir} onClick={() => toggleSort("company")} />
                  </TableHead>
                  <TableHead className="hidden lg:table-cell">Industry</TableHead>
                  <TableHead>
                    <SortableHeader label="Status" active={sortKey === "status"} direction={sortDir} onClick={() => toggleSort("status")} />
                  </TableHead>
                  <TableHead className="hidden xl:table-cell">Rep</TableHead>
                  <TableHead className="hidden lg:table-cell">
                    <SortableHeader label="Created" active={sortKey === "createdAt"} direction={sortDir} onClick={() => toggleSort("createdAt")} />
                  </TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {pageRows.map((c) => (
                  <TableRow key={c.id} data-state={selected.has(c.id) ? "selected" : undefined}>
                    <TableCell>
                      <Checkbox checked={selected.has(c.id)} onCheckedChange={() => toggleRow(c.id)} aria-label={`Select ${c.name}`} />
                    </TableCell>
                    <TableCell>
                      <Link href={routes.customer(c.id)} className="font-medium hover:text-primary hover:underline">
                        {c.name}
                      </Link>
                      <p className="text-xs text-muted-foreground md:hidden">{c.company}</p>
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">{c.company}</TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">{c.industry}</TableCell>
                    <TableCell><CustomerStatusBadge status={c.status} /></TableCell>
                    <TableCell className="hidden xl:table-cell"><MemberTag member={memberMap[c.assignedRepId]} /></TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">{format(new Date(c.createdAt), "MMM d, yyyy")}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8" aria-label="Row actions">
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link href={routes.customer(c.id)}>View details</Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => { setEditing(c); setFormOpen(true); }}>
                            Edit
                          </DropdownMenuItem>
                          {canDelete && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem destructive onSelect={() => setToDelete([c.id])}>
                                <Trash2 /> Delete
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="border-t border-border px-4">
              <DataPagination page={page} pageSize={PAGE_SIZE} total={filtered.length} onPageChange={(p) => setPage(Math.min(Math.max(1, p), totalPages))} />
            </div>
          </>
        )}
      </Card>

      <CustomerFormDialog open={formOpen} onOpenChange={setFormOpen} customer={editing} />
      <ConfirmDialog
        open={toDelete !== null}
        onOpenChange={(o) => !o && setToDelete(null)}
        title={toDelete && toDelete.length > 1 ? `Delete ${toDelete.length} customers?` : "Delete customer?"}
        description="This permanently removes the selected record(s) from the demo workspace. This action cannot be undone."
        confirmLabel="Delete"
        loading={deleteMut.isPending}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
