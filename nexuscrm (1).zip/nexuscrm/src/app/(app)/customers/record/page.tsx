"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { CustomerDetail } from "@/components/customers/customer-detail";

function CustomerRecord() {
  const id = useSearchParams().get("id") ?? "";
  return <CustomerDetail id={id} />;
}

export default function CustomerRecordPage() {
  return (
    <Suspense fallback={<div className="space-y-6"><Skeleton className="h-8 w-40" /><Skeleton className="h-48" /></div>}>
      <CustomerRecord />
    </Suspense>
  );
}
