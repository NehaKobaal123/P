"use client";

import * as React from "react";
import Link from "next/link";
import {
  CheckSquare,
  DollarSign,
  LineChart,
  Trello,
  TrendingUp,
  Users,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { RangeFilter } from "@/components/dashboard/range-filter";
import { MemberTag } from "@/components/common/member-tag";
import { DealStageBadge } from "@/components/common/status-badges";
import {
  MonthlySalesBarChart,
  RevenueAreaChart,
  SourceDonutChart,
  StageBarChart,
} from "@/components/charts/crm-charts";
import { useDatabase } from "@/hooks/use-crm";
import { useCustomerMap, useMemberMap } from "@/hooks/use-lookups";
import {
  computeKpis,
  type DateRange,
  type DateRangeKey,
  dealsByStage,
  isOverdue,
  leadsBySource,
  rangeFromKey,
  recentActivity,
  recentDeals,
  repPerformance,
  revenueByMonth,
  upcomingTasks,
} from "@/lib/metrics";
import { formatCurrency } from "@/lib/utils";
import { formatDistanceToNow, format } from "date-fns";

const KPI_ICONS = {
  revenue: DollarSign,
  customers: Users,
  deals: Trello,
  conversion: TrendingUp,
  tasks: CheckSquare,
  growth: LineChart,
} as const;

export default function DashboardPage() {
  const { data: db, isLoading } = useDatabase();
  const memberMap = useMemberMap();
  const customerMap = useCustomerMap();
  const [rangeKey, setRangeKey] = React.useState<DateRangeKey>("90d");
  const [range, setRange] = React.useState<DateRange>(() => rangeFromKey("90d"));

  function onRangeChange(key: DateRangeKey, next: DateRange) {
    setRangeKey(key);
    setRange(next);
  }

  if (isLoading || !db) return <DashboardSkeleton />;

  const kpis = computeKpis(db, range);
  const revenue = revenueByMonth(db.deals);
  const stages = dealsByStage(db.deals).filter((s) => s.stage !== "lost");
  const sources = leadsBySource(db.leads);
  const deals = recentDeals(db, 6);
  const tasks = upcomingTasks(db, 6);
  const activity = recentActivity(db.activity, 6);
  const reps = repPerformance(db).filter((r) => r.wonValue > 0).slice(0, 5);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        description="A live view of revenue, pipeline and team performance."
        actions={<RangeFilter value={rangeKey} range={range} onChange={onRangeChange} />}
      />

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {kpis.map((kpi) => (
          <KpiCard key={kpi.key} kpi={kpi} icon={KPI_ICONS[kpi.key as keyof typeof KPI_ICONS]} />
        ))}
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Revenue performance</CardTitle>
            <Badge variant="outline">Last 12 months</Badge>
          </CardHeader>
          <CardContent>
            <RevenueAreaChart data={revenue} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Lead sources</CardTitle>
          </CardHeader>
          <CardContent>
            {sources.length ? (
              <SourceDonutChart data={sources} />
            ) : (
              <p className="py-10 text-center text-sm text-muted-foreground">No lead data.</p>
            )}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Monthly sales</CardTitle>
          </CardHeader>
          <CardContent>
            <MonthlySalesBarChart data={revenue} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Open pipeline by stage</CardTitle>
          </CardHeader>
          <CardContent>
            <StageBarChart data={stages} />
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Recent deals</CardTitle>
            <Link href="/deals" className="text-sm font-medium text-primary hover:underline">
              View pipeline
            </Link>
          </CardHeader>
          <CardContent className="px-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Deal</TableHead>
                  <TableHead className="hidden md:table-cell">Owner</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Stage</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deals.map((d) => (
                  <TableRow key={d.id}>
                    <TableCell>
                      <p className="font-medium">{d.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {customerMap[d.customerId]?.company ?? "—"}
                      </p>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <MemberTag member={memberMap[d.ownerId]} />
                    </TableCell>
                    <TableCell className="font-medium tabular-nums">{formatCurrency(d.value)}</TableCell>
                    <TableCell>
                      <DealStageBadge stage={d.stage} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Upcoming tasks</CardTitle>
            <Link href="/tasks" className="text-sm font-medium text-primary hover:underline">
              All tasks
            </Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {tasks.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">No upcoming tasks.</p>
            ) : (
              tasks.map((t) => (
                <div key={t.id} className="flex items-start gap-3">
                  <span className="mt-1 size-2 shrink-0 rounded-full bg-primary" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{t.title}</p>
                    <p className="text-xs text-muted-foreground">
                      Due {format(new Date(t.dueDate), "MMM d")}
                      {isOverdue(t) ? <span className="ml-1 font-medium text-destructive">· overdue</span> : null}
                    </p>
                  </div>
                  <MemberTag member={memberMap[t.assigneeId]} className="[&_span]:hidden" />
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {activity.map((a) => (
              <div key={a.id} className="flex items-start gap-3">
                <MemberTag member={memberMap[a.actorId]} className="[&_span]:hidden" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm">
                    <span className="font-medium">{memberMap[a.actorId]?.name ?? "Someone"}</span>{" "}
                    <span className="text-muted-foreground">{a.detail.toLowerCase()}</span>
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {a.targetLabel} · {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top sales representatives</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {reps.map((r, i) => (
              <div key={r.member.id} className="flex items-center gap-3">
                <span className="w-5 text-sm font-semibold text-muted-foreground">{i + 1}</span>
                <MemberTag member={r.member} subtitle={`${r.wonCount} won · ${r.openCount} open`} />
                <span className="ml-auto font-semibold tabular-nums">{formatCurrency(r.wonValue)}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-64" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-32" />
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Skeleton className="h-80 lg:col-span-2" />
        <Skeleton className="h-80" />
      </div>
    </div>
  );
}
