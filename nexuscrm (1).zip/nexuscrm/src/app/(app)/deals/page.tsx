"use client";

import * as React from "react";
import { Plus } from "lucide-react";
import {
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  closestCorners,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DealCard } from "@/components/deals/deal-card";
import { DealFormDialog } from "@/components/deals/deal-form-dialog";
import { DealDetailDrawer } from "@/components/deals/deal-detail-drawer";
import { useDeals, useReorderDeal } from "@/hooks/use-crm";
import { useCustomerMap, useMemberMap } from "@/hooks/use-lookups";
import {
  type Deal,
  type DealStage,
  DEAL_STAGES,
  DEAL_STAGE_LABELS,
} from "@/types/domain";
import {
  forecastPipelineValue,
  openPipelineValue,
  totalRevenue,
  winRate,
} from "@/lib/metrics";
import { formatCompactCurrency, formatPercent } from "@/lib/utils";

const STAGE_ACCENT: Record<DealStage, string> = {
  new: "bg-stone-400",
  qualified: "bg-blue-500",
  proposal: "bg-teal-600",
  negotiation: "bg-amber-500",
  won: "bg-green-500",
  lost: "bg-red-500",
};

function Column({
  stage,
  deals,
  children,
}: {
  stage: DealStage;
  deals: Deal[];
  children: React.ReactNode;
}) {
  const { setNodeRef, isOver } = useDroppable({ id: `col:${stage}` });
  const total = deals.reduce((s, d) => s + d.value, 0);
  return (
    <div className="flex w-72 shrink-0 flex-col">
      <div className="mb-3 flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span className={`size-2.5 rounded-full ${STAGE_ACCENT[stage]}`} />
          <h3 className="text-sm font-semibold">{DEAL_STAGE_LABELS[stage]}</h3>
          <span className="rounded-full bg-surface-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
            {deals.length}
          </span>
        </div>
        <span className="text-xs font-medium text-muted-foreground">{formatCompactCurrency(total)}</span>
      </div>
      <div
        ref={setNodeRef}
        className={`flex min-h-32 flex-1 flex-col gap-2 rounded-lg border border-dashed p-2 transition-colors ${
          isOver ? "border-primary/50 bg-primary/5" : "border-border bg-surface-muted/30"
        }`}
      >
        {children}
        {deals.length === 0 && (
          <p className="py-6 text-center text-xs text-muted-foreground">Drop deals here</p>
        )}
      </div>
    </div>
  );
}

function SummaryStat({ label, value }: { label: string; value: string }) {
  return (
    <Card className="p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 text-xl font-semibold tabular-nums">{value}</p>
    </Card>
  );
}

export default function DealsPage() {
  const { data: deals, isLoading } = useDeals();
  const memberMap = useMemberMap();
  const customerMap = useCustomerMap();
  const reorderMut = useReorderDeal();

  const [owner, setOwner] = React.useState("all");
  const [activeId, setActiveId] = React.useState<string | null>(null);
  const [formOpen, setFormOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Deal | undefined>();
  const [defaultStage, setDefaultStage] = React.useState<DealStage | undefined>();
  const [drawerDeal, setDrawerDeal] = React.useState<Deal | null>(null);
  const [drawerOpen, setDrawerOpen] = React.useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const visibleDeals = React.useMemo(
    () => (deals ?? []).filter((d) => owner === "all" || d.ownerId === owner),
    [deals, owner],
  );

  const grouped = React.useMemo(() => {
    const map: Record<DealStage, Deal[]> = {
      new: [], qualified: [], proposal: [], negotiation: [], won: [], lost: [],
    };
    for (const d of visibleDeals) map[d.stage].push(d);
    for (const stage of DEAL_STAGES) map[stage].sort((a, b) => a.order - b.order);
    return map;
  }, [visibleDeals]);

  const activeDeal = activeId ? (deals ?? []).find((d) => d.id === activeId) : null;

  function handleDragStart(e: DragStartEvent) {
    setActiveId(String(e.active.id));
  }

  function handleDragEnd(e: DragEndEvent) {
    setActiveId(null);
    const { active, over } = e;
    if (!over) return;
    const dealId = String(active.id);
    const overId = String(over.id);
    const activeStage = (active.data.current?.stage as DealStage) ?? null;

    let toStage: DealStage;
    let toIndex: number;

    if (overId.startsWith("col:")) {
      toStage = overId.slice(4) as DealStage;
      toIndex = grouped[toStage].filter((d) => d.id !== dealId).length;
    } else {
      const overStage = (over.data.current?.stage as DealStage) ?? activeStage;
      if (!overStage) return;
      toStage = overStage;
      const column = grouped[toStage].filter((d) => d.id !== dealId);
      const idx = column.findIndex((d) => d.id === overId);
      toIndex = idx === -1 ? column.length : idx;
    }

    const current = (deals ?? []).find((d) => d.id === dealId);
    if (!current) return;
    const sameSpot = current.stage === toStage && grouped[toStage].findIndex((d) => d.id === dealId) === toIndex;
    if (sameSpot) return;

    reorderMut.mutate({ id: dealId, toStage, toIndex });
  }

  function handleMove(deal: Deal, stage: DealStage) {
    reorderMut.mutate({ id: deal.id, toStage: stage, toIndex: 0 });
  }

  function openCreate(stage?: DealStage) {
    setEditing(undefined);
    setDefaultStage(stage);
    setFormOpen(true);
  }

  function openDrawer(deal: Deal) {
    setDrawerDeal(deal);
    setDrawerOpen(true);
  }

  if (isLoading || !deals) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="flex gap-4 overflow-hidden">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-96 w-72 shrink-0" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Sales Pipeline"
        description="Drag deals between stages, or use each card's menu to move with the keyboard."
        actions={
          <>
            <Select value={owner} onValueChange={setOwner}>
              <SelectTrigger className="w-44"><SelectValue placeholder="Owner" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All owners</SelectItem>
                {Object.values(memberMap).map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button onClick={() => openCreate()}><Plus className="size-4" /> Add deal</Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryStat label="Open pipeline" value={formatCompactCurrency(openPipelineValue(visibleDeals))} />
        <SummaryStat label="Weighted forecast" value={formatCompactCurrency(forecastPipelineValue(visibleDeals))} />
        <SummaryStat label="Closed won" value={formatCompactCurrency(totalRevenue(visibleDeals))} />
        <SummaryStat label="Win rate" value={formatPercent(winRate(visibleDeals))} />
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragCancel={() => setActiveId(null)}
      >
        <div className="flex gap-4 overflow-x-auto pb-4">
          {DEAL_STAGES.map((stage) => (
            <Column key={stage} stage={stage} deals={grouped[stage]}>
              <SortableContext items={grouped[stage].map((d) => d.id)} strategy={verticalListSortingStrategy}>
                {grouped[stage].map((d) => (
                  <DealCard
                    key={d.id}
                    deal={d}
                    owner={memberMap[d.ownerId]}
                    company={customerMap[d.customerId]?.company}
                    onOpen={openDrawer}
                    onMove={handleMove}
                  />
                ))}
              </SortableContext>
            </Column>
          ))}
        </div>
        <DragOverlay>
          {activeDeal ? (
            <DealCard
              deal={activeDeal}
              owner={memberMap[activeDeal.ownerId]}
              company={customerMap[activeDeal.customerId]?.company}
              onOpen={() => {}}
              onMove={() => {}}
              overlay
            />
          ) : null}
        </DragOverlay>
      </DndContext>

      <DealFormDialog open={formOpen} onOpenChange={setFormOpen} deal={editing} defaultStage={defaultStage} />
      <DealDetailDrawer
        deal={drawerDeal}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        onEdit={(d) => {
          setDrawerOpen(false);
          setEditing(d);
          setDefaultStage(undefined);
          setFormOpen(true);
        }}
      />
    </div>
  );
}
