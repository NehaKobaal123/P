"use client";

import * as React from "react";
import Link from "next/link";
import { Download, GitBranch, MoreHorizontal, Plus, Search, Target, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { DataPagination } from "@/components/common/data-pagination";
import { SortableHeader, type SortDirection } from "@/components/common/sortable-header";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { LeadStatusBadge, PriorityBadge } from "@/components/common/status-badges";
import { MemberTag } from "@/components/common/member-tag";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LeadFormDialog } from "@/components/leads/lead-form-dialog";
import { useConvertLead, useDeleteLead, useLeads } from "@/hooks/use-crm";
import { usePermissions } from "@/hooks/use-session";
import { useMemberMap } from "@/hooks/use-lookups";
import { useDebounce } from "@/hooks/use-debounce";
import {
  type Lead,
  LEAD_SOURCES,
  LEAD_STATUSES,
  LEAD_STATUS_LABELS,
  PRIORITIES,
  PRIORITY_LABELS,
} from "@/types/domain";
import { downloadCsv, toCsv } from "@/lib/csv";
import { routes } from "@/lib/routes";
import { formatCurrency } from "@/lib/utils";

type SortKey = "name" | "estimatedValue" | "createdAt" | "status";
const PAGE_SIZE = 8;

function canConvert(lead: Lead): boolean {
  return lead.status !== "converted" && lead.status !== "lost";
}

export default function LeadsPage() {
  const { data: leads, isLoading } = useLeads();
  const memberMap = useMemberMap();
  const deleteMut = useDeleteLead();
  const convertMut = useConvertLead();
  const { can } = usePermissions();
  const canDelete = can("delete");

  const [search, setSearch] = React.useState("");
  const debounced = useDebounce(search);
  const [status, setStatus] = React.useState("all");
  const [source, setSource] = React.useState("all");
  const [priority, setPriority] = React.useState("all");
  const [sortKey, setSortKey] = React.useState<SortKey>("createdAt");
  const [sortDir, setSortDir] = React.useState<SortDirection>("desc");
  const [page, setPage] = React.useState(1);

  const [formOpen, setFormOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Lead | undefined>();
  const [toDelete, setToDelete] = React.useState<Lead | null>(null);
  const [toConvert, setToConvert] = React.useState<Lead | null>(null);

  React.useEffect(() => setPage(1), [debounced, status, source, priority]);

  const filtered = React.useMemo(() => {
    let rows = leads ?? [];
    const q = debounced.trim().toLowerCase();
    if (q) rows = rows.filter((l) => l.name.toLowerCase().includes(q) || l.company.toLowerCase().includes(q));
    if (status !== "all") rows = rows.filter((l) => l.status === status);
    if (source !== "all") rows = rows.filter((l) => l.source === source);
    if (priority !== "all") rows = rows.filter((l) => l.priority === priority);
    const dir = sortDir === "asc" ? 1 : -1;
    return [...rows].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
      return String(av).localeCompare(String(bv)) * dir;
    });
  }, [leads, debounced, status, source, priority, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageRows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("asc"); }
  }

  function exportCsv() {
    const csv = toCsv(filtered, [
      { header: "Name", value: (l) => l.name },
      { header: "Company", value: (l) => l.company },
      { header: "Email", value: (l) => l.email },
      { header: "Source", value: (l) => l.source },
      { header: "Estimated value", value: (l) => l.estimatedValue },
      { header: "Priority", value: (l) => PRIORITY_LABELS[l.priority] },
      { header: "Status", value: (l) => LEAD_STATUS_LABELS[l.status] },
      { header: "Representative", value: (l) => memberMap[l.assignedRepId]?.name ?? "" },
    ]);
    downloadCsv("nexuscrm-leads.csv", csv);
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Leads"
        description="Capture, qualify and convert prospective customers."
        actions={
          <>
            <Button variant="outline" onClick={exportCsv} disabled={filtered.length === 0}>
              <Download className="size-4" /> Export CSV
            </Button>
            <Button onClick={() => { setEditing(undefined); setFormOpen(true); }}>
              <Plus className="size-4" /> Add lead
            </Button>
          </>
        }
      />

      <Card>
        <div className="flex flex-col gap-3 border-b border-border p-4 xl:flex-row xl:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search leads…" className="pl-9" aria-label="Search leads" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {LEAD_STATUSES.map((s) => <SelectItem key={s} value={s}>{LEAD_STATUS_LABELS[s]}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={source} onValueChange={setSource}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All sources</SelectItem>
                {LEAD_SOURCES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={priority} onValueChange={setPriority}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All priorities</SelectItem>
                {PRIORITIES.map((p) => <SelectItem key={p} value={p}>{PRIORITY_LABELS[p]}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-2 p-4">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
        ) : filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState icon={Target} title="No leads found" description="Adjust your filters or capture a new lead."
              action={<Button onClick={() => { setEditing(undefined); setFormOpen(true); }}><Plus className="size-4" /> Add lead</Button>} />
          </div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead><SortableHeader label="Lead" active={sortKey === "name"} direction={sortDir} onClick={() => toggleSort("name")} /></TableHead>
                  <TableHead className="hidden lg:table-cell">Source</TableHead>
                  <TableHead><SortableHeader label="Value" active={sortKey === "estimatedValue"} direction={sortDir} onClick={() => toggleSort("estimatedValue")} /></TableHead>
                  <TableHead className="hidden md:table-cell">Priority</TableHead>
                  <TableHead><SortableHeader label="Status" active={sortKey === "status"} direction={sortDir} onClick={() => toggleSort("status")} /></TableHead>
                  <TableHead className="hidden xl:table-cell">Rep</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {pageRows.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell>
                      <Link href={routes.lead(l.id)} className="font-medium hover:text-primary hover:underline">{l.name}</Link>
                      <p className="text-xs text-muted-foreground">{l.company}</p>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">{l.source}</TableCell>
                    <TableCell className="font-medium tabular-nums">{formatCurrency(l.estimatedValue)}</TableCell>
                    <TableCell className="hidden md:table-cell"><PriorityBadge priority={l.priority} /></TableCell>
                    <TableCell><LeadStatusBadge status={l.status} /></TableCell>
                    <TableCell className="hidden xl:table-cell"><MemberTag member={memberMap[l.assignedRepId]} /></TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8" aria-label="Row actions"><MoreHorizontal className="size-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild><Link href={routes.lead(l.id)}>View details</Link></DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => { setEditing(l); setFormOpen(true); }}>Edit</DropdownMenuItem>
                          {canConvert(l) && (
                            <DropdownMenuItem onSelect={() => setToConvert(l)}><GitBranch /> Convert</DropdownMenuItem>
                          )}
                          {canDelete && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem destructive onSelect={() => setToDelete(l)}><Trash2 /> Delete</DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="border-t border-border px-4">
              <DataPagination page={page} pageSize={PAGE_SIZE} total={filtered.length} onPageChange={(p) => setPage(Math.min(Math.max(1, p), totalPages))} />
            </div>
          </>
        )}
      </Card>

      <LeadFormDialog open={formOpen} onOpenChange={setFormOpen} lead={editing} />
      <ConfirmDialog
        open={toDelete !== null}
        onOpenChange={(o) => !o && setToDelete(null)}
        title="Delete lead?"
        description={`This permanently removes ${toDelete?.name ?? "this lead"} from the demo workspace.`}
        confirmLabel="Delete"
        loading={deleteMut.isPending}
        onConfirm={async () => { if (toDelete) { await deleteMut.mutateAsync(toDelete.id); setToDelete(null); } }}
      />
      <ConfirmDialog
        open={toConvert !== null}
        onOpenChange={(o) => !o && setToConvert(null)}
        title="Convert this lead?"
        description="Converting creates (or links) a customer and opens a new deal in the Qualified stage. The lead is marked converted."
        confirmLabel="Convert lead"
        destructive={false}
        loading={convertMut.isPending}
        onConfirm={async () => { if (toConvert) { await convertMut.mutateAsync(toConvert.id); setToConvert(null); } }}
      />
    </div>
  );
}
