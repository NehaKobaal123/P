"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { LeadDetail } from "@/components/leads/lead-detail";

function LeadRecord() {
  const id = useSearchParams().get("id") ?? "";
  return <LeadDetail id={id} />;
}

export default function LeadRecordPage() {
  return (
    <Suspense fallback={<div className="space-y-6"><Skeleton className="h-8 w-40" /><Skeleton className="h-48" /></div>}>
      <LeadRecord />
    </Suspense>
  );
}
