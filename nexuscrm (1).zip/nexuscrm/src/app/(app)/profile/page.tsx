"use client";

import Link from "next/link";
import { Mail, Settings as SettingsIcon } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/ui/avatar";
import { RoleBadge, MemberStatusBadge } from "@/components/common/status-badges";
import { useDatabase } from "@/hooks/use-crm";
import { useSession } from "@/hooks/use-session";
import { OPEN_DEAL_STAGES } from "@/types/domain";
import { formatCurrency } from "@/lib/utils";
import { format } from "date-fns";

export default function ProfilePage() {
  const { data: db } = useDatabase();
  const { member: me } = useSession();

  if (!me || !db) {
    return <div className="space-y-6"><Skeleton className="h-10 w-40" /><Skeleton className="h-48" /></div>;
  }

  const myDeals = db.deals.filter((d) => d.ownerId === me.id);
  const openDeals = myDeals.filter((d) => OPEN_DEAL_STAGES.includes(d.stage));
  const wonValue = myDeals.filter((d) => d.stage === "won").reduce((s, d) => s + d.value, 0);
  const openTasks = db.tasks.filter((t) => t.assigneeId === me.id && t.status !== "done").length;

  const stats = [
    { label: "Open deals", value: String(openDeals.length) },
    { label: "Open tasks", value: String(openTasks) },
    { label: "Closed-won", value: formatCurrency(wonValue, { notation: "compact" }) },
    { label: "Member since", value: format(new Date(me.createdAt), "MMM yyyy") },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Profile"
        description="Your account details and performance."
        actions={
          <Button asChild variant="outline">
            <Link href="/settings"><SettingsIcon className="size-4" /> Preferences</Link>
          </Button>
        }
      />

      <Card>
        <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center">
          <Avatar name={me.name} color={me.avatarColor} size="lg" />
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="text-xl font-semibold">{me.name}</h2>
              <RoleBadge role={me.role} />
              <MemberStatusBadge status={me.status} />
            </div>
            <p className="text-muted-foreground">{me.title}</p>
            <a href={`mailto:${me.email}`} className="mt-1 inline-flex items-center gap-1.5 text-sm text-primary hover:underline">
              <Mail className="size-3.5" /> {me.email}
            </a>
          </div>
        </CardContent>
      </Card>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="p-5">
            <p className="text-sm font-medium text-muted-foreground">{s.label}</p>
            <p className="mt-2 text-kpi tabular-nums">{s.value}</p>
          </Card>
        ))}
      </section>

      <Card>
        <CardHeader><CardTitle>Account</CardTitle></CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          This is the signed-in demo administrator account. In a Supabase deployment, profile details
          come from the authenticated session and can be edited here with changes persisted to the
          database.
        </CardContent>
      </Card>
    </div>
  );
}
