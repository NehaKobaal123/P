"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { Monitor, Moon, RotateCcw, Sun } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { useResetDemo } from "@/hooks/use-crm";
import { useSettingsStore } from "@/stores/settings-store";
import { DATA_MODE } from "@/services";
import { cn } from "@/lib/utils";

const THEMES = [
  { value: "light", label: "Light", icon: Sun },
  { value: "dark", label: "Dark", icon: Moon },
  { value: "system", label: "System", icon: Monitor },
];

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const settings = useSettingsStore();
  const resetDemo = useResetDemo();
  const [orgName, setOrgName] = React.useState(settings.organizationName);
  const [mounted, setMounted] = React.useState(false);
  const [confirmReset, setConfirmReset] = React.useState(false);
  React.useEffect(() => setMounted(true), []);
  React.useEffect(() => setOrgName(settings.organizationName), [settings.organizationName]);

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Manage your workspace preferences and demo data." />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-1 lg:col-span-1">
          <h2 className="font-semibold">Appearance</h2>
          <p className="text-sm text-muted-foreground">Choose how NexusCRM looks on this device.</p>
        </div>
        <Card className="lg:col-span-2">
          <CardContent className="p-5">
            <Label className="mb-3 block">Theme</Label>
            <div className="grid grid-cols-3 gap-3">
              {THEMES.map((t) => {
                const active = mounted && theme === t.value;
                return (
                  <button
                    key={t.value}
                    onClick={() => setTheme(t.value)}
                    className={cn(
                      "flex flex-col items-center gap-2 rounded-lg border p-4 text-sm font-medium transition-colors",
                      active ? "border-primary bg-primary/5 text-primary" : "border-border hover:bg-surface-muted",
                    )}
                    aria-pressed={active}
                  >
                    <t.icon className="size-5" />
                    {t.label}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-1 lg:col-span-1">
          <h2 className="font-semibold">Organization</h2>
          <p className="text-sm text-muted-foreground">Basic details for your workspace.</p>
        </div>
        <Card className="lg:col-span-2">
          <CardContent className="space-y-4 p-5">
            <div className="space-y-1.5">
              <Label htmlFor="org">Organization name</Label>
              <Input id="org" value={orgName} onChange={(e) => setOrgName(e.target.value)} />
            </div>
            <Button
              onClick={() => {
                settings.setOrganizationName(orgName.trim() || "Untitled Workspace");
                toast.success("Organization updated");
              }}
            >
              Save changes
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-1 lg:col-span-1">
          <h2 className="font-semibold">Notifications</h2>
          <p className="text-sm text-muted-foreground">Control the digests and alerts you receive.</p>
        </div>
        <Card className="lg:col-span-2">
          <CardContent className="divide-y divide-border p-0">
            <ToggleRow label="Weekly performance digest" desc="A summary of pipeline and revenue every Monday." checked={settings.weeklyDigest} onChange={(v) => settings.toggle("weeklyDigest", v)} />
            <ToggleRow label="Deal stage alerts" desc="Notify me when a deal I own changes stage." checked={settings.dealAlerts} onChange={(v) => settings.toggle("dealAlerts", v)} />
            <ToggleRow label="Task reminders" desc="Remind me about tasks due within 24 hours." checked={settings.taskReminders} onChange={(v) => settings.toggle("taskReminders", v)} />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-1 lg:col-span-1">
          <h2 className="font-semibold">Data & demo</h2>
          <p className="text-sm text-muted-foreground">How this workspace stores and resets data.</p>
        </div>
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Data mode
              <Badge variant={DATA_MODE === "demo" ? "primary" : "success"} className="capitalize">{DATA_MODE}</Badge>
            </CardTitle>
            <CardDescription>
              {DATA_MODE === "demo"
                ? "Changes are stored in your browser only and are isolated from any server. No real-time or server-backed functionality is active."
                : "Connected to a Supabase backend with Row Level Security."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" onClick={() => setConfirmReset(true)}>
              <RotateCcw className="size-4" /> Reset demo data
            </Button>
            <p className="mt-2 text-xs text-muted-foreground">
              Restores the original seeded dataset and discards your local changes.
            </p>
          </CardContent>
        </Card>
      </div>

      <ConfirmDialog
        open={confirmReset}
        onOpenChange={setConfirmReset}
        title="Reset demo data?"
        description="This restores the seeded demo dataset and permanently discards changes you've made in this browser."
        confirmLabel="Reset data"
        loading={resetDemo.isPending}
        onConfirm={async () => { await resetDemo.mutateAsync(); setConfirmReset(false); }}
      />
    </div>
  );
}

function ToggleRow({ label, desc, checked, onChange }: { label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-4 p-5">
      <div>
        <p className="text-sm font-medium">{label}</p>
        <p className="text-sm text-muted-foreground">{desc}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} aria-label={label} />
    </div>
  );
}
