"use client";

import * as React from "react";
import { CheckSquare, MoreHorizontal, Plus, Search, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { PriorityBadge, TaskStatusBadge } from "@/components/common/status-badges";
import { Avatar } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { TaskFormDialog } from "@/components/tasks/task-form-dialog";
import { useDeleteTask, useSetTaskStatus, useTasks } from "@/hooks/use-crm";
import { useMemberMap } from "@/hooks/use-lookups";
import { useDebounce } from "@/hooks/use-debounce";
import { isOverdue } from "@/lib/metrics";
import {
  type Task,
  type TaskStatus,
  TASK_STATUSES,
  TASK_STATUS_LABELS,
  PRIORITIES,
  PRIORITY_LABELS,
} from "@/types/domain";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

export default function TasksPage() {
  const { data: tasks, isLoading } = useTasks();
  const memberMap = useMemberMap();
  const setStatus = useSetTaskStatus();
  const deleteMut = useDeleteTask();

  const [search, setSearch] = React.useState("");
  const debounced = useDebounce(search);
  const [status, setStatusFilter] = React.useState("all");
  const [assignee, setAssignee] = React.useState("all");
  const [priority, setPriority] = React.useState("all");

  const [formOpen, setFormOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Task | undefined>();
  const [toDelete, setToDelete] = React.useState<Task | null>(null);

  const filtered = React.useMemo(() => {
    let rows = tasks ?? [];
    const q = debounced.trim().toLowerCase();
    if (q) rows = rows.filter((t) => t.title.toLowerCase().includes(q));
    if (status !== "all") rows = rows.filter((t) => t.status === status);
    if (assignee !== "all") rows = rows.filter((t) => t.assigneeId === assignee);
    if (priority !== "all") rows = rows.filter((t) => t.priority === priority);
    return [...rows].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  }, [tasks, debounced, status, assignee, priority]);

  function toggleDone(task: Task) {
    setStatus.mutate({ id: task.id, status: task.status === "done" ? "todo" : "done" });
  }

  function openEdit(task: Task) {
    setEditing(task);
    setFormOpen(true);
  }

  const board: Record<TaskStatus, Task[]> = { todo: [], in_progress: [], done: [] };
  filtered.forEach((t) => board[t.status].push(t));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Tasks"
        description="Assign follow-ups, track due dates and keep deals moving."
        actions={
          <Button onClick={() => { setEditing(undefined); setFormOpen(true); }}>
            <Plus className="size-4" /> Add task
          </Button>
        }
      />

      <Card className="p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tasks…" className="pl-9" aria-label="Search tasks" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Select value={status} onValueChange={setStatusFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {TASK_STATUSES.map((s) => <SelectItem key={s} value={s}>{TASK_STATUS_LABELS[s]}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={assignee} onValueChange={setAssignee}>
              <SelectTrigger><SelectValue placeholder="Assignee" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All assignees</SelectItem>
                {Object.values(memberMap).map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={priority} onValueChange={setPriority}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All priorities</SelectItem>
                {PRIORITIES.map((p) => <SelectItem key={p} value={p}>{PRIORITY_LABELS[p]}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <Tabs defaultValue="list">
        <TabsList>
          <TabsTrigger value="list">List</TabsTrigger>
          <TabsTrigger value="board">Board</TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          <Card>
            {isLoading ? (
              <div className="space-y-2 p-4">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
            ) : filtered.length === 0 ? (
              <div className="p-6">
                <EmptyState icon={CheckSquare} title="No tasks found" description="Adjust filters or add a new task."
                  action={<Button onClick={() => { setEditing(undefined); setFormOpen(true); }}><Plus className="size-4" /> Add task</Button>} />
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10" />
                    <TableHead>Task</TableHead>
                    <TableHead className="hidden md:table-cell">Assignee</TableHead>
                    <TableHead className="hidden sm:table-cell">Priority</TableHead>
                    <TableHead>Due</TableHead>
                    <TableHead className="hidden lg:table-cell">Status</TableHead>
                    <TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((t) => {
                    const overdue = isOverdue(t);
                    const assigneeMember = memberMap[t.assigneeId];
                    return (
                      <TableRow key={t.id}>
                        <TableCell>
                          <Checkbox checked={t.status === "done"} onCheckedChange={() => toggleDone(t)} aria-label={`Mark ${t.title} complete`} />
                        </TableCell>
                        <TableCell>
                          <p className={cn("font-medium", t.status === "done" && "text-muted-foreground line-through")}>{t.title}</p>
                          {t.description ? <p className="truncate text-xs text-muted-foreground">{t.description}</p> : null}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {assigneeMember ? (
                            <span className="flex items-center gap-2">
                              <Avatar name={assigneeMember.name} color={assigneeMember.avatarColor} size="sm" />
                              <span className="text-sm">{assigneeMember.name}</span>
                            </span>
                          ) : "—"}
                        </TableCell>
                        <TableCell className="hidden sm:table-cell"><PriorityBadge priority={t.priority} /></TableCell>
                        <TableCell className={cn("text-sm", overdue && "font-medium text-destructive")}>
                          {format(new Date(t.dueDate), "MMM d")}
                          {overdue ? <span className="ml-1 text-xs">overdue</span> : null}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell"><TaskStatusBadge status={t.status} /></TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="size-8" aria-label="Task actions"><MoreHorizontal className="size-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onSelect={() => openEdit(t)}>Edit</DropdownMenuItem>
                              <DropdownMenuLabel>Set status</DropdownMenuLabel>
                              {TASK_STATUSES.map((s) => (
                                <DropdownMenuItem key={s} onSelect={() => setStatus.mutate({ id: t.id, status: s })}>
                                  {TASK_STATUS_LABELS[s]}
                                </DropdownMenuItem>
                              ))}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem destructive onSelect={() => setToDelete(t)}><Trash2 /> Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="board">
          <div className="grid gap-4 md:grid-cols-3">
            {TASK_STATUSES.map((s) => (
              <div key={s} className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <h3 className="text-sm font-semibold">{TASK_STATUS_LABELS[s]}</h3>
                  <span className="rounded-full bg-surface-muted px-2 py-0.5 text-xs text-muted-foreground">{board[s].length}</span>
                </div>
                <div className="space-y-2 rounded-lg border border-dashed border-border bg-surface-muted/30 p-2">
                  {board[s].length === 0 ? (
                    <p className="py-6 text-center text-xs text-muted-foreground">No tasks</p>
                  ) : (
                    board[s].map((t) => {
                      const m = memberMap[t.assigneeId];
                      const overdue = isOverdue(t);
                      return (
                        <div key={t.id} className="rounded-lg border border-border bg-surface p-3">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-sm font-medium leading-snug">{t.title}</p>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="rounded p-0.5 text-muted-foreground hover:bg-surface-muted" aria-label="Move task"><MoreHorizontal className="size-4" /></button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onSelect={() => openEdit(t)}>Edit</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuLabel>Move to</DropdownMenuLabel>
                                {TASK_STATUSES.filter((x) => x !== s).map((x) => (
                                  <DropdownMenuItem key={x} onSelect={() => setStatus.mutate({ id: t.id, status: x })}>
                                    {TASK_STATUS_LABELS[x]}
                                  </DropdownMenuItem>
                                ))}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                          <div className="mt-3 flex items-center justify-between">
                            <span className={cn("text-xs", overdue ? "font-medium text-destructive" : "text-muted-foreground")}>
                              {format(new Date(t.dueDate), "MMM d")}{overdue ? " · overdue" : ""}
                            </span>
                            <div className="flex items-center gap-2">
                              <PriorityBadge priority={t.priority} />
                              {m ? <Avatar name={m.name} color={m.avatarColor} size="sm" /> : null}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <TaskFormDialog open={formOpen} onOpenChange={setFormOpen} task={editing} />
      <ConfirmDialog
        open={toDelete !== null}
        onOpenChange={(o) => !o && setToDelete(null)}
        title="Delete task?"
        description={`This permanently removes "${toDelete?.title ?? "this task"}".`}
        confirmLabel="Delete"
        loading={deleteMut.isPending}
        onConfirm={async () => { if (toDelete) { await deleteMut.mutateAsync(toDelete.id); setToDelete(null); } }}
      />
    </div>
  );
}
