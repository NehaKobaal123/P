"use client";

import { Check, Minus } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MemberStatusBadge } from "@/components/common/status-badges";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useDatabase, useMembers, useUpdateMemberRole } from "@/hooks/use-crm";
import { usePermissions } from "@/hooks/use-session";
import { PERMISSIONS } from "@/lib/permissions";
import { formatCurrency } from "@/lib/utils";
import {
  type Role,
  ROLE_LABELS,
  ROLES,
  OPEN_DEAL_STAGES,
} from "@/types/domain";

export default function TeamPage() {
  const { data: members, isLoading } = useMembers();
  const { data: db } = useDatabase();
  const updateRole = useUpdateMemberRole();
  const { can } = usePermissions();
  const canManageTeam = can("manage_team");

  if (isLoading || !members || !db) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-44" />)}
        </div>
      </div>
    );
  }

  function statsFor(memberId: string) {
    const deals = db!.deals.filter((d) => d.ownerId === memberId);
    const openDeals = deals.filter((d) => OPEN_DEAL_STAGES.includes(d.stage)).length;
    const wonValue = deals.filter((d) => d.stage === "won").reduce((s, d) => s + d.value, 0);
    const openTasks = db!.tasks.filter((t) => t.assigneeId === memberId && t.status !== "done").length;
    return { openDeals, wonValue, openTasks };
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Team Management" description="Your revenue team, their roles, workload and performance." />

      {!canManageTeam && (
        <div className="rounded-md border border-border bg-surface-muted/50 px-4 py-2.5 text-sm text-muted-foreground">
          You&apos;re viewing as a non-administrator — changing roles is disabled for your role.
        </div>
      )}

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {members.map((m) => {
          const s = statsFor(m.id);
          return (
            <Card key={m.id}>
              <CardContent className="p-5">
                <div className="flex items-start gap-3">
                  <Avatar name={m.name} color={m.avatarColor} size="lg" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{m.name}</p>
                    <p className="truncate text-sm text-muted-foreground">{m.title}</p>
                    <div className="mt-1"><MemberStatusBadge status={m.status} /></div>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 border-y border-border py-3 text-center">
                  <div>
                    <p className="text-sm font-semibold tabular-nums">{s.openDeals}</p>
                    <p className="text-xs text-muted-foreground">Open deals</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold tabular-nums">{s.openTasks}</p>
                    <p className="text-xs text-muted-foreground">Open tasks</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold tabular-nums">{formatCurrency(s.wonValue, { notation: "compact" })}</p>
                    <p className="text-xs text-muted-foreground">Won</p>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <label htmlFor={`role-${m.id}`} className="text-sm text-muted-foreground">Role</label>
                  <Select
                    value={m.role}
                    onValueChange={(v) => updateRole.mutate({ id: m.id, role: v as Role })}
                    disabled={!canManageTeam}
                  >
                    <SelectTrigger id={`role-${m.id}`} className="h-8 flex-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {ROLES.map((r) => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <Card>
        <CardHeader>
          <CardTitle>Role & permission matrix</CardTitle>
        </CardHeader>
        <CardContent className="px-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Permission</TableHead>
                {ROLES.map((r) => <TableHead key={r} className="text-center">{ROLE_LABELS[r]}</TableHead>)}
              </TableRow>
            </TableHeader>
            <TableBody>
              {PERMISSIONS.map((p) => (
                <TableRow key={p.key}>
                  <TableCell className="font-medium">{p.label}</TableCell>
                  {ROLES.map((r) => (
                    <TableCell key={r} className="text-center">
                      {p.roles[r] ? (
                        <Check className="mx-auto size-4 text-success" aria-label="Allowed" />
                      ) : (
                        <Minus className="mx-auto size-4 text-muted-foreground/40" aria-label="Not allowed" />
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <p className="px-5 pt-4 text-xs text-muted-foreground">
            In a Supabase deployment these rules are enforced by Row Level Security — the frontend is
            never the only gatekeeper.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
