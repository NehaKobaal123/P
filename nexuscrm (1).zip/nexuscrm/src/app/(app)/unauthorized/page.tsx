import Link from "next/link";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

/**
 * Shown when a user's role doesn't permit an action. In demo mode the admin
 * account can reach everything; a Supabase deployment routes here on a denied
 * RLS check or a role-guarded route.
 */
export default function UnauthorizedPage() {
  return (
    <Card className="mx-auto mt-10 max-w-md">
      <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
        <span className="flex size-12 items-center justify-center rounded-full bg-warning/15 text-warning">
          <Lock className="size-6" />
        </span>
        <div className="space-y-1">
          <h2 className="text-lg font-semibold">You don&apos;t have access</h2>
          <p className="text-sm text-muted-foreground">
            Your role doesn&apos;t permit viewing this page. Contact an administrator if you believe
            this is a mistake.
          </p>
        </div>
        <Button asChild><Link href="/dashboard">Back to dashboard</Link></Button>
      </CardContent>
    </Card>
  );
}
