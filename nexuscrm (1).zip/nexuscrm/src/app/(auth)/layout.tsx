import Link from "next/link";
import { Brand } from "@/components/layout/brand";
import { ThemeToggle } from "@/components/layout/theme-toggle";

/** Split layout: a brand panel on the left, the form on the right. */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-sidebar p-10 text-sidebar-foreground lg:flex">
        <div
          className="pointer-events-none absolute inset-0 opacity-30"
          style={{
            backgroundImage: "radial-gradient(hsl(var(--primary)/0.5) 1px, transparent 1px)",
            backgroundSize: "26px 26px",
          }}
          aria-hidden
        />
        <Link href="/" className="relative">
          <Brand onDark />
        </Link>
        <div className="relative max-w-sm">
          <p className="text-2xl font-semibold leading-snug">
            Your Business. In Command.
          </p>
          <p className="mt-3 text-sidebar-muted">
            Manage customers, leads, deals, tasks and performance in one connected workspace.
          </p>
        </div>
        <p className="relative text-xs text-sidebar-muted">© {new Date().getFullYear()} NexusCRM</p>
      </div>
      <div className="relative flex flex-col">
        <div className="flex items-center justify-between p-4">
          <Link href="/" className="lg:hidden">
            <Brand />
          </Link>
          <div className="ml-auto">
            <ThemeToggle />
          </div>
        </div>
        <div className="flex flex-1 items-center justify-center p-4">
          <div className="w-full max-w-sm">{children}</div>
        </div>
      </div>
    </div>
  );
}
