"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, Check, ShieldCheck, UserCog, Users } from "lucide-react";
import { type LucideIcon } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { useSession } from "@/hooks/use-session";
import { type Role, ROLE_LABELS } from "@/types/domain";
import { cn } from "@/lib/utils";

interface RoleOption {
  role: Role;
  icon: LucideIcon;
  blurb: string;
  can: string[];
}

const OPTIONS: RoleOption[] = [
  {
    role: "admin",
    icon: ShieldCheck,
    blurb: "Full control of the workspace.",
    can: ["Manage the team & change roles", "Delete any record", "See the full activity log"],
  },
  {
    role: "manager",
    icon: UserCog,
    blurb: "Lead the pipeline and the team's records.",
    can: ["Edit any team member's records", "Delete customers & deals", "View the activity log"],
  },
  {
    role: "rep",
    icon: Users,
    blurb: "Work your own book of business.",
    can: ["Create & edit your own records", "Convert leads", "Move deals through the pipeline"],
  },
];

export default function SignInPage() {
  const router = useRouter();
  const { loginAs } = useSession();

  function choose(role: Role) {
    loginAs(role);
    toast.success(`Signed in as ${ROLE_LABELS[role]}`);
    router.push("/dashboard");
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Choose a demo role</h1>
        <p className="mt-1.5 text-sm text-muted-foreground">
          Pick a role to explore NexusCRM. You can switch any time.
        </p>
      </div>

      <div className="mb-5 rounded-md border border-border bg-surface-muted px-3 py-2 text-xs text-muted-foreground">
        <strong className="font-medium text-foreground">Simulated roles.</strong> No real
        authentication — all data is stored locally in your browser.
      </div>

      <div className="space-y-3">
        {OPTIONS.map((opt) => (
          <button
            key={opt.role}
            onClick={() => choose(opt.role)}
            className={cn(
              "group flex w-full items-start gap-4 rounded-lg border border-border bg-surface p-4 text-left transition-colors hover:border-primary/50 hover:bg-primary/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            )}
          >
            <span className="mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <opt.icon className="size-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex items-center justify-between">
                <span className="font-semibold">{ROLE_LABELS[opt.role]}</span>
                <ArrowRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
              </span>
              <span className="text-sm text-muted-foreground">{opt.blurb}</span>
              <span className="mt-2 flex flex-col gap-1">
                {opt.can.map((c) => (
                  <span key={c} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Check className="size-3 text-success" /> {c}
                  </span>
                ))}
              </span>
            </span>
          </button>
        ))}
      </div>

      <div className="mt-6 flex items-center justify-between text-sm">
        <Badge variant="outline">No password required</Badge>
        <Link href="/" className="font-medium text-muted-foreground hover:text-foreground">
          Back to home
        </Link>
      </div>
    </div>
  );
}
