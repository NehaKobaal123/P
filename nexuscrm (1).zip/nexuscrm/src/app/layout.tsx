import type { Metadata } from "next";
import "@fontsource-variable/plus-jakarta-sans";
import "@fontsource-variable/jetbrains-mono";
import "./globals.css";
import { AppProviders } from "@/components/providers";

const siteUrl = "https://nexuscrm.example.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "NexusCRM — Your Business. In Command.",
    template: "%s · NexusCRM",
  },
  description:
    "NexusCRM is an enterprise CRM and business-intelligence workspace to manage customers, leads, deals, tasks and performance in one connected product.",
  applicationName: "NexusCRM",
  keywords: ["CRM", "sales pipeline", "business intelligence", "customer management"],
  openGraph: {
    title: "NexusCRM — Your Business. In Command.",
    description:
      "Manage customers, leads, deals, tasks and performance in one connected workspace.",
    url: siteUrl,
    siteName: "NexusCRM",
    type: "website",
  },
  twitter: { card: "summary_large_image", title: "NexusCRM" },
  icons: { icon: "/favicon.ico" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}
