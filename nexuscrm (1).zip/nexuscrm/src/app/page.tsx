import Link from "next/link";
import {
  Activity,
  ArrowRight,
  BarChart3,
  CheckSquare,
  GitBranch,
  LayoutDashboard,
  ShieldCheck,
  Target,
  Trello,
  Users,
  Zap,
} from "lucide-react";
import { Brand } from "@/components/layout/brand";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LandingNav } from "@/components/marketing/landing-nav";
import { ProductPreview } from "@/components/marketing/product-preview";

const FEATURES = [
  { icon: Users, title: "Customer 360", desc: "Every contact, company, lifecycle stage and activity in one connected record." },
  { icon: Target, title: "Lead management", desc: "Capture, qualify and convert leads into customers and deals without duplicates." },
  { icon: Trello, title: "Visual pipeline", desc: "A drag-and-drop Kanban with weighted forecasting and win/loss reporting." },
  { icon: CheckSquare, title: "Tasks & follow-ups", desc: "Assign work, track due dates and never let an opportunity go cold." },
  { icon: BarChart3, title: "Business intelligence", desc: "Revenue trends, conversion funnels and rep performance from live records." },
  { icon: ShieldCheck, title: "Role-based access", desc: "Administrator, Manager and Representative roles with scoped permissions." },
];

const WORKFLOW = [
  { icon: Target, title: "Capture", desc: "New leads arrive from website, referral, events and outbound." },
  { icon: GitBranch, title: "Qualify", desc: "Score and route leads, then convert the best into opportunities." },
  { icon: Trello, title: "Close", desc: "Move deals through the pipeline with forecasting at every stage." },
  { icon: Activity, title: "Grow", desc: "Analyse performance and expand accounts with data you can trust." },
];

const BENEFITS = [
  "One connected workspace for the whole revenue team",
  "Deterministic, auditable metrics — no vanity numbers",
  "Keyboard-accessible, responsive and dark-mode ready",
  "Explore instantly in demo mode, no sign-up required",
];

export default function LandingPage() {
  return (
    <div className="min-h-dvh bg-background">
      <LandingNav />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div
          className="pointer-events-none absolute inset-0 -z-10 opacity-60 [mask-image:radial-gradient(60%_50%_at_50%_0%,black,transparent)]"
          style={{
            backgroundImage:
              "radial-gradient(hsl(var(--primary)/0.12) 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
          aria-hidden
        />
        <div className="mx-auto max-w-6xl px-4 pb-10 pt-16 sm:px-6 sm:pt-24">
          <div className="mx-auto max-w-3xl text-center">
            <Badge variant="primary" className="mb-5">
              <Zap className="size-3" /> Enterprise CRM & Business Intelligence
            </Badge>
            <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              Your Business. <span className="text-primary">In Command.</span>
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-balance text-lg text-muted-foreground">
              NexusCRM unifies customers, leads, deals, tasks and analytics into one
              connected workspace — so your revenue team can see everything and act with
              confidence.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button asChild size="lg">
                <Link href="/dashboard">
                  Explore Live Demo <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/register">Get Started</Link>
              </Button>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              No sign-up required — the demo runs on realistic synthetic data in your browser.
            </p>
          </div>

          <div className="mx-auto mt-14 max-w-5xl">
            <ProductPreview />
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="border-t border-border bg-surface/40 py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-semibold tracking-tight">Everything your revenue team needs</h2>
            <p className="mt-3 text-muted-foreground">
              Purpose-built modules that share one data model — so the numbers always line up.
            </p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="group rounded-lg border border-border bg-surface p-6 shadow-sm transition-shadow hover:shadow-md"
              >
                <span className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <f.icon className="size-5" />
                </span>
                <h3 className="mt-4 font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Workflow */}
      <section id="workflow" className="py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-semibold tracking-tight">A workflow that mirrors how you sell</h2>
            <p className="mt-3 text-muted-foreground">
              From first touch to closed-won, every stage connects to the next.
            </p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {WORKFLOW.map((s, i) => (
              <div key={s.title} className="relative rounded-lg border border-border bg-surface p-6">
                <span className="absolute right-4 top-4 text-sm font-semibold text-muted-foreground/40">
                  0{i + 1}
                </span>
                <span className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <s.icon className="size-5" />
                </span>
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Analytics preview + benefits */}
      <section id="analytics" className="border-y border-border bg-surface/40 py-20">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2">
          <div>
            <Badge variant="primary" className="mb-4">
              <BarChart3 className="size-3" /> Business intelligence
            </Badge>
            <h2 className="text-3xl font-semibold tracking-tight">Decisions backed by real numbers</h2>
            <p className="mt-3 text-muted-foreground">
              Every KPI and chart is computed from the underlying records with transparent,
              deterministic formulas. No random figures, no disconnected dashboards.
            </p>
            <ul className="mt-6 space-y-3">
              {BENEFITS.map((b) => (
                <li key={b} className="flex items-start gap-3 text-sm">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-success/15 text-success">
                    <CheckSquare className="size-3" />
                  </span>
                  {b}
                </li>
              ))}
            </ul>
            <Button asChild className="mt-8">
              <Link href="/analytics">
                See the analytics <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
          <div className="rounded-xl border border-border bg-surface p-6 shadow-md">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">Pipeline by stage</p>
              <Badge>Live demo data</Badge>
            </div>
            <div className="mt-6 space-y-4">
              {[
                { label: "New Opportunity", pct: 100, value: "$640K" },
                { label: "Qualified", pct: 74, value: "$472K" },
                { label: "Proposal Sent", pct: 52, value: "$333K" },
                { label: "Negotiation", pct: 33, value: "$211K" },
                { label: "Won", pct: 21, value: "$134K" },
              ].map((row) => (
                <div key={row.label}>
                  <div className="mb-1.5 flex items-center justify-between text-xs">
                    <span className="font-medium text-foreground">{row.label}</span>
                    <span className="text-muted-foreground">{row.value}</span>
                  </div>
                  <div className="h-2.5 overflow-hidden rounded-full bg-surface-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${row.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6">
          <LayoutDashboard className="mx-auto size-10 text-primary" />
          <h2 className="mt-5 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Put your whole revenue operation in one command center
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Jump straight into the live demo — explore real workflows with realistic data, no
            account needed.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg">
              <Link href="/dashboard">
                Explore Live Demo <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/register">Get Started</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 px-4 sm:px-6 md:flex-row">
          <Brand />
          <nav className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground">Features</a>
            <a href="#workflow" className="hover:text-foreground">Workflow</a>
            <a href="#analytics" className="hover:text-foreground">Analytics</a>
            <Link href="/dashboard" className="hover:text-foreground">Live Demo</Link>
          </nav>
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} NexusCRM. A portfolio demo product.
          </p>
        </div>
      </footer>
    </div>
  );
}
