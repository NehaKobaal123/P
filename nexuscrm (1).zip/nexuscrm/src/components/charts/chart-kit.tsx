"use client";

import { type TooltipProps } from "recharts";
import { formatCompactCurrency, formatCurrency, formatNumber } from "@/lib/utils";

/**
 * Categorical palette — distinct hues chosen for contrast in both themes and
 * for colour-blind legibility. Never rely on colour alone; every series is
 * also labelled.
 */
export const CHART_COLORS = [
  "#0D9488", // teal (brand)
  "#2563EB", // blue
  "#16A34A", // green
  "#D97706", // amber
  "#DC2626", // red
  "#0EA5E9", // sky
  "#CA8A04", // gold
];

export const AXIS_PROPS = {
  stroke: "hsl(var(--muted-foreground))",
  fontSize: 12,
  tickLine: false,
  axisLine: false,
} as const;

export const GRID_STROKE = "hsl(var(--border))";

export type ValueFormat = "currency" | "compactCurrency" | "number";

export function formatValue(value: number, format: ValueFormat): string {
  if (format === "currency") return formatCurrency(value);
  if (format === "compactCurrency") return formatCompactCurrency(value);
  return formatNumber(value);
}

/** Themed tooltip shared by every chart. */
export function ChartTooltip({
  active,
  payload,
  label,
  format = "number",
}: TooltipProps<number, string> & { format?: ValueFormat }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md border border-border bg-surface px-3 py-2 text-xs shadow-md">
      {label ? <p className="mb-1 font-semibold text-foreground">{label}</p> : null}
      <div className="space-y-1">
        {payload.map((entry) => (
          <div key={entry.name} className="flex items-center gap-2">
            <span className="size-2 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-muted-foreground">{entry.name}</span>
            <span className="ml-auto font-medium text-foreground">
              {formatValue(Number(entry.value), format)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
