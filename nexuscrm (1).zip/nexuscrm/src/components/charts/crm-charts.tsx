"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AXIS_PROPS, CHART_COLORS, ChartTooltip, GRID_STROKE } from "@/components/charts/chart-kit";
import { formatCompactCurrency } from "@/lib/utils";
import { type MonthlyPoint, type SourceDatum, type StageDatum } from "@/lib/metrics";

export function RevenueAreaChart({ data }: { data: MonthlyPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: 4, bottom: 0 }}>
        <defs>
          <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={CHART_COLORS[0]} stopOpacity={0.3} />
            <stop offset="100%" stopColor={CHART_COLORS[0]} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} stroke={GRID_STROKE} strokeDasharray="3 3" />
        <XAxis dataKey="month" {...AXIS_PROPS} />
        <YAxis {...AXIS_PROPS} tickFormatter={(v) => formatCompactCurrency(Number(v))} width={56} />
        <Tooltip content={<ChartTooltip format="currency" />} />
        <Area
          type="monotone"
          dataKey="revenue"
          name="Revenue"
          stroke={CHART_COLORS[0]}
          strokeWidth={2.5}
          fill="url(#revFill)"
          activeDot={{ r: 4 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function MonthlySalesBarChart({ data }: { data: MonthlyPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: 4, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke={GRID_STROKE} strokeDasharray="3 3" />
        <XAxis dataKey="month" {...AXIS_PROPS} />
        <YAxis {...AXIS_PROPS} allowDecimals={false} width={28} />
        <Tooltip content={<ChartTooltip format="number" />} cursor={{ fill: "hsl(var(--surface-muted))" }} />
        <Bar dataKey="deals" name="Deals won" fill={CHART_COLORS[1]} radius={[4, 4, 0, 0]} maxBarSize={28} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function StageBarChart({ data }: { data: StageDatum[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 12, left: 8, bottom: 0 }}>
        <CartesianGrid horizontal={false} stroke={GRID_STROKE} strokeDasharray="3 3" />
        <XAxis type="number" {...AXIS_PROPS} tickFormatter={(v) => formatCompactCurrency(Number(v))} />
        <YAxis type="category" dataKey="label" {...AXIS_PROPS} width={110} />
        <Tooltip content={<ChartTooltip format="currency" />} cursor={{ fill: "hsl(var(--surface-muted))" }} />
        <Bar dataKey="value" name="Pipeline value" radius={[0, 4, 4, 0]} maxBarSize={26}>
          {data.map((_, i) => (
            <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function SourceDonutChart({ data }: { data: SourceDatum[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart>
        <Pie
          data={data}
          dataKey="count"
          nameKey="source"
          innerRadius={58}
          outerRadius={96}
          paddingAngle={2}
          stroke="hsl(var(--surface))"
          strokeWidth={2}
        >
          {data.map((_, i) => (
            <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
          ))}
        </Pie>
        <Tooltip content={<ChartTooltip format="number" />} />
        <Legend
          verticalAlign="bottom"
          iconType="circle"
          wrapperStyle={{ fontSize: 12, color: "hsl(var(--muted-foreground))" }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}

export function RepPerformanceBarChart({
  data,
}: {
  data: { name: string; value: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
        <CartesianGrid horizontal={false} stroke={GRID_STROKE} strokeDasharray="3 3" />
        <XAxis type="number" {...AXIS_PROPS} tickFormatter={(v) => formatCompactCurrency(Number(v))} />
        <YAxis type="category" dataKey="name" {...AXIS_PROPS} width={110} />
        <Tooltip content={<ChartTooltip format="currency" />} cursor={{ fill: "hsl(var(--surface-muted))" }} />
        <Bar dataKey="value" name="Closed-won" fill={CHART_COLORS[0]} radius={[0, 4, 4, 0]} maxBarSize={24} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function CountAreaChart({
  data,
  seriesName,
}: {
  data: { label: string; value: number }[];
  seriesName: string;
}) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: 4, bottom: 0 }}>
        <defs>
          <linearGradient id="countFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={CHART_COLORS[2]} stopOpacity={0.3} />
            <stop offset="100%" stopColor={CHART_COLORS[2]} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} stroke={GRID_STROKE} strokeDasharray="3 3" />
        <XAxis dataKey="label" {...AXIS_PROPS} />
        <YAxis {...AXIS_PROPS} allowDecimals={false} width={32} />
        <Tooltip content={<ChartTooltip format="number" />} />
        <Area type="monotone" dataKey="value" name={seriesName} stroke={CHART_COLORS[2]} strokeWidth={2.5} fill="url(#countFill)" dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function TrendLineChart({
  data,
}: {
  data: { label: string; value: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={data} margin={{ top: 8, right: 8, left: 4, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke={GRID_STROKE} strokeDasharray="3 3" />
        <XAxis dataKey="label" {...AXIS_PROPS} />
        <YAxis {...AXIS_PROPS} tickFormatter={(v) => formatCompactCurrency(Number(v))} width={56} />
        <Tooltip content={<ChartTooltip format="currency" />} />
        <Line type="monotone" dataKey="value" name="Avg deal value" stroke={CHART_COLORS[3]} strokeWidth={2.5} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
