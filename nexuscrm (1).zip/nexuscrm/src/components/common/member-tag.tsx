import { Avatar } from "@/components/ui/avatar";
import { type TeamMember } from "@/types/domain";
import { cn } from "@/lib/utils";

/** Avatar + name for a team member, with a graceful unknown fallback. */
export function MemberTag({
  member,
  size = "sm",
  className,
  subtitle,
}: {
  member?: TeamMember;
  size?: "sm" | "md";
  className?: string;
  subtitle?: string;
}) {
  if (!member) {
    return <span className={cn("text-sm text-muted-foreground", className)}>Unassigned</span>;
  }
  return (
    <span className={cn("flex items-center gap-2", className)}>
      <Avatar name={member.name} color={member.avatarColor} size={size} />
      <span className="min-w-0">
        <span className="block truncate text-sm font-medium text-foreground">{member.name}</span>
        {subtitle ? <span className="block truncate text-xs text-muted-foreground">{subtitle}</span> : null}
      </span>
    </span>
  );
}
