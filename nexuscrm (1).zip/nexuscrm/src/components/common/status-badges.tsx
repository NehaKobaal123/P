import { Badge } from "@/components/ui/badge";
import {
  type CustomerStatus,
  CUSTOMER_STATUS_LABELS,
  type DealStage,
  DEAL_STAGE_LABELS,
  type LeadStatus,
  LEAD_STATUS_LABELS,
  type MemberStatus,
  type Priority,
  PRIORITY_LABELS,
  type Role,
  ROLE_LABELS,
  type TaskStatus,
  TASK_STATUS_LABELS,
} from "@/types/domain";

type Variant = React.ComponentProps<typeof Badge>["variant"];

const customerVariant: Record<CustomerStatus, Variant> = {
  active: "success",
  prospect: "primary",
  at_risk: "warning",
  churned: "destructive",
};

export function CustomerStatusBadge({ status }: { status: CustomerStatus }) {
  return <Badge variant={customerVariant[status]}>{CUSTOMER_STATUS_LABELS[status]}</Badge>;
}

const leadVariant: Record<LeadStatus, Variant> = {
  new: "default",
  contacted: "primary",
  qualified: "primary",
  proposal: "warning",
  converted: "success",
  lost: "destructive",
};

export function LeadStatusBadge({ status }: { status: LeadStatus }) {
  return <Badge variant={leadVariant[status]}>{LEAD_STATUS_LABELS[status]}</Badge>;
}

const stageVariant: Record<DealStage, Variant> = {
  new: "default",
  qualified: "primary",
  proposal: "primary",
  negotiation: "warning",
  won: "success",
  lost: "destructive",
};

export function DealStageBadge({ stage }: { stage: DealStage }) {
  return <Badge variant={stageVariant[stage]}>{DEAL_STAGE_LABELS[stage]}</Badge>;
}

const priorityVariant: Record<Priority, Variant> = {
  low: "default",
  medium: "primary",
  high: "destructive",
};

export function PriorityBadge({ priority }: { priority: Priority }) {
  return <Badge variant={priorityVariant[priority]}>{PRIORITY_LABELS[priority]}</Badge>;
}

const taskVariant: Record<TaskStatus, Variant> = {
  todo: "default",
  in_progress: "primary",
  done: "success",
};

export function TaskStatusBadge({ status }: { status: TaskStatus }) {
  return <Badge variant={taskVariant[status]}>{TASK_STATUS_LABELS[status]}</Badge>;
}

const roleVariant: Record<Role, Variant> = {
  admin: "primary",
  manager: "warning",
  rep: "default",
};

export function RoleBadge({ role }: { role: Role }) {
  return <Badge variant={roleVariant[role]}>{ROLE_LABELS[role]}</Badge>;
}

const memberVariant: Record<MemberStatus, Variant> = {
  active: "success",
  invited: "warning",
  inactive: "default",
};

export function MemberStatusBadge({ status }: { status: MemberStatus }) {
  return <Badge variant={memberVariant[status]} className="capitalize">{status}</Badge>;
}
