import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Delta pill. `invert` flips the colour semantics for metrics where a decrease
 * is good (not used yet, but kept so the component reads honestly).
 */
export function TrendPill({
  value,
  className,
  invert = false,
}: {
  value: number | null;
  className?: string;
  invert?: boolean;
}) {
  if (value === null) {
    return <span className={cn("text-xs text-muted-foreground", className)}>—</span>;
  }
  const positive = invert ? value < 0 : value > 0;
  const neutral = value === 0;
  const Icon = neutral ? Minus : value > 0 ? ArrowUpRight : ArrowDownRight;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-xs font-medium",
        neutral
          ? "bg-surface-muted text-muted-foreground"
          : positive
            ? "bg-success/10 text-success"
            : "bg-destructive/10 text-destructive",
        className,
      )}
    >
      <Icon className="size-3" />
      {Math.abs(value).toFixed(1)}%
    </span>
  );
}
