"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  Building2,
  CheckSquare,
  Mail,
  Pencil,
  Phone,
  Trash2,
  Trello,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Avatar } from "@/components/ui/avatar";
import { CustomerStatusBadge, DealStageBadge, TaskStatusBadge } from "@/components/common/status-badges";
import { MemberTag } from "@/components/common/member-tag";
import { CustomerFormDialog } from "@/components/customers/customer-form-dialog";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { useCustomer, useDeals, useTasks, useActivity, useDeleteCustomers } from "@/hooks/use-crm";
import { useMemberMap } from "@/hooks/use-lookups";
import { usePermissions } from "@/hooks/use-session";
import { formatCurrency } from "@/lib/utils";
import { format, formatDistanceToNow } from "date-fns";

export function CustomerDetail({ id }: { id: string }) {
  const router = useRouter();
  const { data: customer, isLoading } = useCustomer(id);
  const { data: deals } = useDeals();
  const { data: tasks } = useTasks();
  const { data: activity } = useActivity();
  const memberMap = useMemberMap();
  const deleteMut = useDeleteCustomers();
  const { can } = usePermissions();

  const [editOpen, setEditOpen] = React.useState(false);
  const [confirmOpen, setConfirmOpen] = React.useState(false);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-48" />
      </div>
    );
  }

  if (!customer) {
    return (
      <EmptyState
        icon={Building2}
        title="Customer not found"
        description="This record may have been removed."
        action={
          <Button asChild variant="outline">
            <Link href="/customers">Back to customers</Link>
          </Button>
        }
      />
    );
  }

  const relatedDeals = (deals ?? []).filter((d) => d.customerId === id);
  const relatedTasks = (tasks ?? []).filter((t) => t.relatedCustomerId === id);
  const relatedActivity = (activity ?? []).filter((a) => a.targetId === id).slice(0, 8);
  const rep = memberMap[customer.assignedRepId];

  async function handleDelete() {
    await deleteMut.mutateAsync([id]);
    router.push("/customers");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button asChild variant="ghost" size="sm" className="-ml-2">
          <Link href="/customers">
            <ArrowLeft className="size-4" /> Customers
          </Link>
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setEditOpen(true)}>
            <Pencil className="size-4" /> Edit
          </Button>
          {can("delete") && (
            <Button variant="destructive" onClick={() => setConfirmOpen(true)}>
              <Trash2 className="size-4" /> Delete
            </Button>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center">
          <Avatar name={customer.name} color={rep?.avatarColor} size="lg" />
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl font-semibold tracking-tight">{customer.name}</h1>
              <CustomerStatusBadge status={customer.status} />
            </div>
            <p className="text-muted-foreground">{customer.company} · {customer.industry}</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <Card>
            <CardHeader><CardTitle>Contact</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <Mail className="size-4 text-muted-foreground" />
                <a href={`mailto:${customer.email}`} className="hover:text-primary hover:underline">{customer.email}</a>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="size-4 text-muted-foreground" />
                <span>{customer.phone}</span>
              </div>
              <div className="flex items-center justify-between border-t border-border pt-3">
                <span className="text-muted-foreground">Representative</span>
                <MemberTag member={rep} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Customer since</span>
                <span>{format(new Date(customer.createdAt), "MMM d, yyyy")}</span>
              </div>
            </CardContent>
          </Card>
          {customer.notes ? (
            <Card>
              <CardHeader><CardTitle>Notes</CardTitle></CardHeader>
              <CardContent className="text-sm text-muted-foreground">{customer.notes}</CardContent>
            </Card>
          ) : null}
        </div>

        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2"><Trello className="size-4" /> Deals ({relatedDeals.length})</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {relatedDeals.length === 0 ? (
                <p className="py-4 text-sm text-muted-foreground">No deals linked to this customer.</p>
              ) : (
                relatedDeals.map((d) => (
                  <div key={d.id} className="flex items-center justify-between rounded-md border border-border p-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{d.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Close {format(new Date(d.expectedCloseDate), "MMM d, yyyy")}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-semibold tabular-nums">{formatCurrency(d.value)}</span>
                      <DealStageBadge stage={d.stage} />
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><CheckSquare className="size-4" /> Tasks ({relatedTasks.length})</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {relatedTasks.length === 0 ? (
                <p className="py-4 text-sm text-muted-foreground">No tasks for this customer.</p>
              ) : (
                relatedTasks.map((t) => (
                  <div key={t.id} className="flex items-center justify-between rounded-md border border-border p-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{t.title}</p>
                      <p className="text-xs text-muted-foreground">Due {format(new Date(t.dueDate), "MMM d, yyyy")}</p>
                    </div>
                    <TaskStatusBadge status={t.status} />
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Activity history</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              {relatedActivity.length === 0 ? (
                <p className="py-4 text-sm text-muted-foreground">No recorded activity yet.</p>
              ) : (
                relatedActivity.map((a) => (
                  <div key={a.id} className="flex items-start gap-3">
                    <span className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" />
                    <div>
                      <p className="text-sm">{a.detail}</p>
                      <p className="text-xs text-muted-foreground">
                        {memberMap[a.actorId]?.name ?? "System"} · {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <CustomerFormDialog open={editOpen} onOpenChange={setEditOpen} customer={customer} />
      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="Delete customer?"
        description={`This permanently removes ${customer.name} from the demo workspace.`}
        confirmLabel="Delete"
        loading={deleteMut.isPending}
        onConfirm={handleDelete}
      />
    </div>
  );
}
