"use client";

import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormField } from "@/components/common/form-field";
import { Spinner } from "@/components/ui/spinner";
import { useCreateCustomer, useMembers, useUpdateCustomer } from "@/hooks/use-crm";
import {
  type Customer,
  CUSTOMER_STATUSES,
  CUSTOMER_STATUS_LABELS,
  INDUSTRIES,
  ROLE_LABELS,
} from "@/types/domain";

const schema = z.object({
  name: z.string().min(2, "Enter a contact name"),
  company: z.string().min(1, "Enter a company"),
  email: z.string().email("Enter a valid email"),
  phone: z.string().min(5, "Enter a phone number"),
  industry: z.enum(INDUSTRIES as [string, ...string[]]),
  status: z.enum(CUSTOMER_STATUSES as [string, ...string[]]),
  assignedRepId: z.string().min(1, "Assign a representative"),
  notes: z.string().max(1000).optional().default(""),
});
type Values = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer?: Customer;
}

export function CustomerFormDialog({ open, onOpenChange, customer }: Props) {
  const { data: members } = useMembers();
  const createMut = useCreateCustomer();
  const updateMut = useUpdateCustomer();
  const isEdit = Boolean(customer);

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<Values>({ resolver: zodResolver(schema) });

  React.useEffect(() => {
    if (!open) return;
    reset(
      customer
        ? {
            name: customer.name,
            company: customer.company,
            email: customer.email,
            phone: customer.phone,
            industry: customer.industry,
            status: customer.status,
            assignedRepId: customer.assignedRepId,
            notes: customer.notes,
          }
        : {
            name: "",
            company: "",
            email: "",
            phone: "",
            industry: "Technology",
            status: "prospect",
            assignedRepId: members?.[0]?.id ?? "",
            notes: "",
          },
    );
  }, [open, customer, members, reset]);

  const submitting = createMut.isPending || updateMut.isPending;

  async function onSubmit(values: Values) {
    const payload = { ...values, notes: values.notes ?? "" } as Customer;
    if (isEdit && customer) {
      await updateMut.mutateAsync({ id: customer.id, input: payload });
    } else {
      await createMut.mutateAsync(payload);
    }
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit customer" : "New customer"}</DialogTitle>
          <DialogDescription>
            {isEdit ? "Update this customer's details." : "Add a customer to your workspace."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Contact name" htmlFor="name" error={errors.name?.message} required>
              <Input id="name" {...register("name")} aria-invalid={!!errors.name} />
            </FormField>
            <FormField label="Company" htmlFor="company" error={errors.company?.message} required>
              <Input id="company" {...register("company")} aria-invalid={!!errors.company} />
            </FormField>
            <FormField label="Email" htmlFor="email" error={errors.email?.message} required>
              <Input id="email" type="email" {...register("email")} aria-invalid={!!errors.email} />
            </FormField>
            <FormField label="Phone" htmlFor="phone" error={errors.phone?.message} required>
              <Input id="phone" {...register("phone")} aria-invalid={!!errors.phone} />
            </FormField>
            <FormField label="Industry" error={errors.industry?.message} required>
              <Controller
                control={control}
                name="industry"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {INDUSTRIES.map((i) => (
                        <SelectItem key={i} value={i}>
                          {i}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
            </FormField>
            <FormField label="Lifecycle status" error={errors.status?.message} required>
              <Controller
                control={control}
                name="status"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {CUSTOMER_STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {CUSTOMER_STATUS_LABELS[s]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
            </FormField>
          </div>
          <FormField label="Assigned representative" error={errors.assignedRepId?.message} required>
            <Controller
              control={control}
              name="assignedRepId"
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select representative" />
                  </SelectTrigger>
                  <SelectContent>
                    {(members ?? []).map((m) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.name} · {ROLE_LABELS[m.role]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
          </FormField>
          <FormField label="Notes" htmlFor="notes" error={errors.notes?.message}>
            <Textarea id="notes" rows={3} {...register("notes")} placeholder="Context, next steps, account history…" />
          </FormField>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? <Spinner /> : null}
              {isEdit ? "Save changes" : "Create customer"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
