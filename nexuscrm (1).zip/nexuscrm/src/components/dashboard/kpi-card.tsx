import { type LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";
import { TrendPill } from "@/components/common/trend";
import { type Kpi } from "@/lib/metrics";
import { formatCompactCurrency, formatNumber, formatPercent } from "@/lib/utils";

function renderValue(kpi: Kpi): string {
  if (kpi.format === "currency") return formatCompactCurrency(kpi.value);
  if (kpi.format === "percent") return formatPercent(kpi.value);
  return formatNumber(kpi.value);
}

export function KpiCard({ kpi, icon: Icon }: { kpi: Kpi; icon: LucideIcon }) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <p className="text-sm font-medium text-muted-foreground">{kpi.label}</p>
        <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="size-[18px]" />
        </span>
      </div>
      <p className="mt-3 text-kpi tabular-nums">{renderValue(kpi)}</p>
      <div className="mt-2 flex items-center gap-2">
        <TrendPill value={kpi.deltaPercent} />
        <span className="text-xs text-muted-foreground">{kpi.hint}</span>
      </div>
    </Card>
  );
}
