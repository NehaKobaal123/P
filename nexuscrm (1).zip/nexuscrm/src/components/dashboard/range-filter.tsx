"use client";

import * as React from "react";
import { CalendarDays } from "lucide-react";
import * as Popover from "@radix-ui/react-popover";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { type DateRange, type DateRangeKey, rangeFromKey } from "@/lib/metrics";
import { now } from "@/lib/clock";

const PRESETS: { key: Exclude<DateRangeKey, "custom">; label: string }[] = [
  { key: "7d", label: "7 days" },
  { key: "30d", label: "30 days" },
  { key: "90d", label: "90 days" },
];

function toInputDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

interface RangeFilterProps {
  value: DateRangeKey;
  range: DateRange;
  onChange: (key: DateRangeKey, range: DateRange) => void;
}

/** Segmented 7/30/90-day presets plus a custom-range popover. */
export function RangeFilter({ value, range, onChange }: RangeFilterProps) {
  const [from, setFrom] = React.useState(toInputDate(range.from));
  const [to, setTo] = React.useState(toInputDate(range.to));
  const [open, setOpen] = React.useState(false);

  function applyCustom() {
    const f = new Date(from);
    const t = new Date(to);
    if (Number.isNaN(f.getTime()) || Number.isNaN(t.getTime()) || f > t) return;
    onChange("custom", { from: f, to: t });
    setOpen(false);
  }

  return (
    <div className="inline-flex items-center gap-1 rounded-lg border border-border bg-surface p-1">
      {PRESETS.map((p) => (
        <button
          key={p.key}
          onClick={() => onChange(p.key, rangeFromKey(p.key))}
          className={cn(
            "rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
            value === p.key ? "bg-primary text-primary-foreground shadow-xs" : "text-muted-foreground hover:text-foreground",
          )}
        >
          {p.label}
        </button>
      ))}
      <Popover.Root open={open} onOpenChange={setOpen}>
        <Popover.Trigger asChild>
          <button
            className={cn(
              "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
              value === "custom" ? "bg-primary text-primary-foreground shadow-xs" : "text-muted-foreground hover:text-foreground",
            )}
          >
            <CalendarDays className="size-4" /> Custom
          </button>
        </Popover.Trigger>
        <Popover.Portal>
          <Popover.Content
            align="end"
            sideOffset={8}
            className="z-50 w-72 rounded-md border border-border bg-surface p-4 shadow-lg animate-scale-in"
          >
            <p className="mb-3 text-sm font-semibold">Custom range</p>
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="from">From</Label>
                <Input id="from" type="date" value={from} max={toInputDate(now())} onChange={(e) => setFrom(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="to">To</Label>
                <Input id="to" type="date" value={to} max={toInputDate(now())} onChange={(e) => setTo(e.target.value)} />
              </div>
              <Button className="w-full" size="sm" onClick={applyCustom}>
                Apply range
              </Button>
            </div>
          </Popover.Content>
        </Popover.Portal>
      </Popover.Root>
    </div>
  );
}
