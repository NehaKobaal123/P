"use client";

import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { CalendarClock, GripVertical, MoveRight } from "lucide-react";
import { cn, formatCompactCurrency } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { PriorityBadge } from "@/components/common/status-badges";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  type Deal,
  type DealStage,
  DEAL_STAGES,
  DEAL_STAGE_LABELS,
  type TeamMember,
} from "@/types/domain";
import { format } from "date-fns";

interface DealCardProps {
  deal: Deal;
  owner?: TeamMember;
  company?: string;
  onOpen: (deal: Deal) => void;
  onMove: (deal: Deal, stage: DealStage) => void;
  overlay?: boolean;
}

export function DealCard({ deal, owner, company, onOpen, onMove, overlay = false }: DealCardProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: deal.id,
    data: { stage: deal.stage },
  });

  const style = {
    transform: CSS.Translate.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "group rounded-lg border border-border bg-surface p-3 shadow-xs transition-shadow",
        isDragging && "opacity-40",
        overlay && "shadow-lg ring-1 ring-primary/30",
      )}
    >
      <div className="flex items-start gap-2">
        <button
          className="mt-0.5 cursor-grab touch-none text-muted-foreground/50 hover:text-muted-foreground active:cursor-grabbing"
          aria-label="Drag deal"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="size-4" />
        </button>
        <button onClick={() => onOpen(deal)} className="min-w-0 flex-1 text-left">
          <p className="truncate text-sm font-medium leading-snug hover:text-primary">{deal.name}</p>
          <p className="truncate text-xs text-muted-foreground">{company ?? "—"}</p>
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="rounded p-1 text-muted-foreground opacity-0 transition-opacity hover:bg-surface-muted focus:opacity-100 group-hover:opacity-100"
              aria-label="Move deal to stage"
            >
              <MoveRight className="size-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Move to stage</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {DEAL_STAGES.filter((s) => s !== deal.stage).map((s) => (
              <DropdownMenuItem key={s} onSelect={() => onMove(deal, s)}>
                {DEAL_STAGE_LABELS[s]}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <span className="text-sm font-semibold tabular-nums">{formatCompactCurrency(deal.value)}</span>
        <PriorityBadge priority={deal.priority} />
      </div>
      <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <CalendarClock className="size-3.5" />
          {format(new Date(deal.expectedCloseDate), "MMM d")}
        </span>
        {owner ? <Avatar name={owner.name} color={owner.avatarColor} size="sm" /> : null}
      </div>
    </div>
  );
}
