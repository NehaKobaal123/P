"use client";

import * as React from "react";
import Link from "next/link";
import { Pencil, Trash2 } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { DealStageBadge, PriorityBadge } from "@/components/common/status-badges";
import { MemberTag } from "@/components/common/member-tag";
import { useDeleteDeal } from "@/hooks/use-crm";
import { usePermissions } from "@/hooks/use-session";
import { useCustomerMap, useMemberMap } from "@/hooks/use-lookups";
import { type Deal } from "@/types/domain";
import { formatCurrency } from "@/lib/utils";
import { routes } from "@/lib/routes";
import { format } from "date-fns";

interface Props {
  deal: Deal | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit: (deal: Deal) => void;
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-border py-3 text-sm last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{children}</span>
    </div>
  );
}

export function DealDetailDrawer({ deal, open, onOpenChange, onEdit }: Props) {
  const memberMap = useMemberMap();
  const customerMap = useCustomerMap();
  const deleteMut = useDeleteDeal();
  const { can } = usePermissions();
  const [confirm, setConfirm] = React.useState(false);

  if (!deal) return null;
  const owner = memberMap[deal.ownerId];
  const customer = customerMap[deal.customerId];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col sm:max-w-md">
        <SheetHeader>
          <div className="flex items-center gap-2">
            <DealStageBadge stage={deal.stage} />
            <PriorityBadge priority={deal.priority} />
          </div>
          <SheetTitle className="mt-1">{deal.name}</SheetTitle>
          <SheetDescription>{customer?.company ?? "No customer linked"}</SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6">
          <div className="rounded-lg border border-border bg-surface-muted/40 p-4 text-center">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Deal value</p>
            <p className="mt-1 text-2xl font-semibold tabular-nums">{formatCurrency(deal.value)}</p>
          </div>
          <div className="mt-4">
            <Row label="Owner"><MemberTag member={owner} /></Row>
            <Row label="Customer">
              {customer ? (
                <Link href={routes.customer(customer.id)} className="text-primary hover:underline">
                  {customer.name}
                </Link>
              ) : (
                "—"
              )}
            </Row>
            <Row label="Expected close">{format(new Date(deal.expectedCloseDate), "MMM d, yyyy")}</Row>
            <Row label="Created">{format(new Date(deal.createdAt), "MMM d, yyyy")}</Row>
            {deal.sourceLeadId ? <Row label="Source">Converted from lead</Row> : null}
          </div>
        </div>

        <div className="flex gap-2 border-t border-border p-4">
          <Button variant="outline" className="flex-1" onClick={() => onEdit(deal)}>
            <Pencil className="size-4" /> Edit
          </Button>
          {can("delete") && (
            <Button variant="destructive" onClick={() => setConfirm(true)}>
              <Trash2 className="size-4" /> Delete
            </Button>
          )}
        </div>
      </SheetContent>
      <ConfirmDialog
        open={confirm}
        onOpenChange={setConfirm}
        title="Delete deal?"
        description={`This permanently removes "${deal.name}" from the pipeline.`}
        confirmLabel="Delete"
        loading={deleteMut.isPending}
        onConfirm={async () => {
          await deleteMut.mutateAsync(deal.id);
          setConfirm(false);
          onOpenChange(false);
        }}
      />
    </Sheet>
  );
}
