"use client";

import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormField } from "@/components/common/form-field";
import { Spinner } from "@/components/ui/spinner";
import { useCreateDeal, useCustomers, useMembers, useUpdateDeal } from "@/hooks/use-crm";
import {
  type Deal,
  DEAL_STAGES,
  DEAL_STAGE_LABELS,
  PRIORITIES,
  PRIORITY_LABELS,
} from "@/types/domain";

const schema = z.object({
  name: z.string().min(2, "Enter a deal name"),
  customerId: z.string().min(1, "Select a customer"),
  value: z.coerce.number().min(0, "Must be 0 or more"),
  ownerId: z.string().min(1, "Assign an owner"),
  priority: z.enum(PRIORITIES as [string, ...string[]]),
  stage: z.enum(DEAL_STAGES as [string, ...string[]]),
  expectedCloseDate: z.string().min(1, "Choose a close date"),
});
type Values = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  deal?: Deal;
  defaultStage?: Deal["stage"];
}

export function DealFormDialog({ open, onOpenChange, deal, defaultStage }: Props) {
  const { data: members } = useMembers();
  const { data: customers } = useCustomers();
  const createMut = useCreateDeal();
  const updateMut = useUpdateDeal();
  const isEdit = Boolean(deal);

  const { register, handleSubmit, control, reset, formState: { errors } } = useForm<Values>({
    resolver: zodResolver(schema),
  });

  React.useEffect(() => {
    if (!open) return;
    reset(
      deal
        ? {
            name: deal.name,
            customerId: deal.customerId,
            value: deal.value,
            ownerId: deal.ownerId,
            priority: deal.priority,
            stage: deal.stage,
            expectedCloseDate: deal.expectedCloseDate.slice(0, 10),
          }
        : {
            name: "",
            customerId: customers?.[0]?.id ?? "",
            value: 25000,
            ownerId: members?.[0]?.id ?? "",
            priority: "medium",
            stage: defaultStage ?? "new",
            expectedCloseDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString().slice(0, 10),
          },
    );
  }, [open, deal, defaultStage, customers, members, reset]);

  const submitting = createMut.isPending || updateMut.isPending;

  async function onSubmit(values: Values) {
    const payload = { ...values, expectedCloseDate: new Date(values.expectedCloseDate).toISOString() } as Deal;
    if (isEdit && deal) await updateMut.mutateAsync({ id: deal.id, input: payload });
    else await createMut.mutateAsync(payload);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit deal" : "New deal"}</DialogTitle>
          <DialogDescription>
            {isEdit ? "Update this opportunity." : "Add an opportunity to your pipeline."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <FormField label="Deal name" htmlFor="name" error={errors.name?.message} required>
            <Input id="name" {...register("name")} aria-invalid={!!errors.name} />
          </FormField>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Customer" error={errors.customerId?.message} required>
              <Controller control={control} name="customerId" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                  <SelectContent>
                    {(customers ?? []).map((c) => <SelectItem key={c.id} value={c.id}>{c.company}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Value (USD)" htmlFor="value" error={errors.value?.message} required>
              <Input id="value" type="number" min={0} step={1000} {...register("value")} aria-invalid={!!errors.value} />
            </FormField>
            <FormField label="Owner" error={errors.ownerId?.message} required>
              <Controller control={control} name="ownerId" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue placeholder="Select owner" /></SelectTrigger>
                  <SelectContent>
                    {(members ?? []).map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Priority" error={errors.priority?.message} required>
              <Controller control={control} name="priority" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PRIORITIES.map((p) => <SelectItem key={p} value={p}>{PRIORITY_LABELS[p]}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Stage" error={errors.stage?.message} required>
              <Controller control={control} name="stage" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DEAL_STAGES.map((s) => <SelectItem key={s} value={s}>{DEAL_STAGE_LABELS[s]}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Expected close" htmlFor="expectedCloseDate" error={errors.expectedCloseDate?.message} required>
              <Input id="expectedCloseDate" type="date" {...register("expectedCloseDate")} aria-invalid={!!errors.expectedCloseDate} />
            </FormField>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>Cancel</Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? <Spinner /> : null}
              {isEdit ? "Save changes" : "Create deal"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
