import { cn } from "@/lib/utils";

/** NexusCRM wordmark + glyph. The glyph is an original interlocking-node mark. */
export function BrandGlyph({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm",
        className,
      )}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" fill="none" className="size-5">
        <path
          d="M5 17V7l7 5.5V7l7 5v5"
          stroke="currentColor"
          strokeWidth="2.1"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="5" cy="7" r="1.6" fill="currentColor" />
        <circle cx="19" cy="17" r="1.6" fill="currentColor" />
      </svg>
    </span>
  );
}

export function Brand({
  className,
  onDark = false,
}: {
  className?: string;
  onDark?: boolean;
}) {
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <BrandGlyph />
      <span className={cn("text-lg font-semibold tracking-tight", onDark ? "text-sidebar-foreground" : "text-foreground")}>
        Nexus<span className="text-primary">CRM</span>
      </span>
    </span>
  );
}
