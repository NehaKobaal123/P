"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Search, Users, Target, Trello } from "lucide-react";
import { useDatabase } from "@/hooks/use-crm";
import { Input } from "@/components/ui/input";
import { routes } from "@/lib/routes";

interface Result {
  id: string;
  label: string;
  sub: string;
  href: string;
  kind: "customer" | "lead" | "deal";
}

const ICON = { customer: Users, lead: Target, deal: Trello } as const;

/** Lightweight global search across customers, leads and deals. */
export function GlobalSearch() {
  const { data: db } = useDatabase();
  const router = useRouter();
  const [query, setQuery] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    function onClick(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const results: Result[] = React.useMemo(() => {
    if (!db || query.trim().length < 1) return [];
    const q = query.toLowerCase();
    const matches = (s: string) => s.toLowerCase().includes(q);
    const out: Result[] = [];
    db.customers.filter((c) => matches(c.name) || matches(c.company)).slice(0, 4).forEach((c) =>
      out.push({ id: c.id, label: c.name, sub: c.company, href: routes.customer(c.id), kind: "customer" }),
    );
    db.leads.filter((l) => matches(l.name) || matches(l.company)).slice(0, 4).forEach((l) =>
      out.push({ id: l.id, label: l.name, sub: l.company, href: routes.lead(l.id), kind: "lead" }),
    );
    db.deals.filter((d) => matches(d.name)).slice(0, 4).forEach((d) =>
      out.push({ id: d.id, label: d.name, sub: "Deal", href: `/deals`, kind: "deal" }),
    );
    return out;
  }, [db, query]);

  function go(href: string) {
    setOpen(false);
    setQuery("");
    router.push(href);
  }

  return (
    <div ref={containerRef} className="relative w-full max-w-md">
      <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
      <Input
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder="Search customers, leads, deals…"
        className="pl-9"
        aria-label="Global search"
      />
      {open && results.length > 0 && (
        <div className="absolute z-50 mt-2 w-full overflow-hidden rounded-md border border-border bg-surface shadow-lg animate-scale-in">
          <ul className="max-h-80 overflow-y-auto p-1">
            {results.map((r) => {
              const Icon = ICON[r.kind];
              return (
                <li key={`${r.kind}-${r.id}`}>
                  <button
                    onClick={() => go(r.href)}
                    className="flex w-full items-center gap-3 rounded-sm px-2 py-2 text-left text-sm hover:bg-surface-muted"
                  >
                    <Icon className="size-4 text-muted-foreground" />
                    <span className="flex-1 truncate">
                      <span className="font-medium">{r.label}</span>
                      <span className="ml-2 text-xs text-muted-foreground">{r.sub}</span>
                    </span>
                    <span className="text-[11px] capitalize text-muted-foreground">{r.kind}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      )}
      {open && query.trim().length >= 1 && results.length === 0 && (
        <div className="absolute z-50 mt-2 w-full rounded-md border border-border bg-surface p-4 text-center text-sm text-muted-foreground shadow-lg">
          No matches for “{query}”.
        </div>
      )}
    </div>
  );
}
