import {
  Activity,
  BarChart3,
  CheckSquare,
  LayoutDashboard,
  type LucideIcon,
  Settings,
  Target,
  Trello,
  Users,
  UsersRound,
} from "lucide-react";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

export interface NavSection {
  heading: string;
  items: NavItem[];
}

export const NAV_SECTIONS: NavSection[] = [
  {
    heading: "Workspace",
    items: [
      { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
      { label: "Analytics", href: "/analytics", icon: BarChart3 },
    ],
  },
  {
    heading: "Pipeline",
    items: [
      { label: "Customers", href: "/customers", icon: Users },
      { label: "Leads", href: "/leads", icon: Target },
      { label: "Deals", href: "/deals", icon: Trello },
      { label: "Tasks", href: "/tasks", icon: CheckSquare },
    ],
  },
  {
    heading: "Organization",
    items: [
      { label: "Team", href: "/team", icon: UsersRound },
      { label: "Activity", href: "/activity", icon: Activity },
      { label: "Settings", href: "/settings", icon: Settings },
    ],
  },
];

export const ALL_NAV_ITEMS: NavItem[] = NAV_SECTIONS.flatMap((s) => s.items);

/** Resolve a breadcrumb label for a pathname segment. */
export function labelForPath(pathname: string): string {
  const match = ALL_NAV_ITEMS.find((i) => pathname.startsWith(i.href));
  if (match) return match.label;
  if (pathname.startsWith("/profile")) return "Profile";
  return "Dashboard";
}
