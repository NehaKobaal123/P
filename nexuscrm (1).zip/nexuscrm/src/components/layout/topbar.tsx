"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bell, LogOut, Menu, Repeat, RotateCcw, Settings as SettingsIcon, User } from "lucide-react";
import { Brand } from "@/components/layout/brand";
import { SidebarNav } from "@/components/layout/sidebar";
import { GlobalSearch } from "@/components/layout/global-search";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { labelForPath } from "@/components/layout/nav-config";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useActivity, useResetDemo } from "@/hooks/use-crm";
import { useSession } from "@/hooks/use-session";
import { ROLE_LABELS } from "@/types/domain";
import { formatDistanceToNow } from "date-fns";

export function Topbar() {
  const pathname = usePathname();
  const { member: me, role, logout } = useSession();
  const { data: activity } = useActivity();
  const resetDemo = useResetDemo();
  const crumb = labelForPath(pathname);
  const recent = (activity ?? []).slice(0, 5);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-surface/80 px-4 backdrop-blur-md md:px-6">
      {/* Mobile nav trigger */}
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation">
            <Menu className="size-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="flex w-72 flex-col bg-sidebar p-0">
          <div className="flex h-16 items-center border-b border-sidebar-border px-4">
            <Brand onDark />
          </div>
          <SidebarNav />
        </SheetContent>
      </Sheet>

      {/* Breadcrumb */}
      <div className="hidden min-w-0 items-center gap-2 text-sm md:flex">
        <span className="text-muted-foreground">NexusCRM</span>
        <span className="text-muted-foreground/50">/</span>
        <span className="truncate font-medium text-foreground">{crumb}</span>
      </div>

      <div className="flex flex-1 justify-center px-2 md:px-6">
        <GlobalSearch />
      </div>

      <div className="flex items-center gap-1">
        <Badge variant="primary" className="hidden sm:inline-flex">
          Demo · {ROLE_LABELS[role]}
        </Badge>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Notifications" className="relative">
              <Bell className="size-4" />
              {recent.length > 0 && (
                <span className="absolute right-2 top-2 size-2 rounded-full bg-primary ring-2 ring-surface" />
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel>Recent activity</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {recent.length === 0 ? (
              <p className="px-2 py-4 text-center text-sm text-muted-foreground">Nothing yet.</p>
            ) : (
              recent.map((a) => (
                <DropdownMenuItem key={a.id} className="flex-col items-start gap-0.5">
                  <span className="text-sm font-medium text-foreground">{a.targetLabel}</span>
                  <span className="text-xs text-muted-foreground">
                    {a.detail} · {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}
                  </span>
                </DropdownMenuItem>
              ))
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/activity">View all activity</Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <ThemeToggle />

        {/* Profile */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="ml-1 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-ring" aria-label="Account menu">
              <Avatar name={me?.name ?? "User"} color={me?.avatarColor} size="sm" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-60">
            <div className="flex items-center gap-3 px-2 py-2">
              <Avatar name={me?.name ?? "User"} color={me?.avatarColor} />
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{me?.name ?? "Demo User"}</p>
                <p className="truncate text-xs text-muted-foreground">{ROLE_LABELS[role]}</p>
              </div>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/profile">
                <User /> Profile
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/settings">
                <SettingsIcon /> Settings
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/sign-in">
                <Repeat /> Switch role
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem onSelect={() => resetDemo.mutate()}>
              <RotateCcw /> Reset demo data
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild destructive>
              <Link href="/" onClick={() => logout()}>
                <LogOut /> Sign out
              </Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
