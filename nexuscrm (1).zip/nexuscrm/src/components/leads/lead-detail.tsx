"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, GitBranch, Mail, Pencil, Phone, Target, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Avatar } from "@/components/ui/avatar";
import { LeadStatusBadge, PriorityBadge } from "@/components/common/status-badges";
import { MemberTag } from "@/components/common/member-tag";
import { LeadFormDialog } from "@/components/leads/lead-form-dialog";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { useActivity, useConvertLead, useDeleteLead, useLead } from "@/hooks/use-crm";
import { useMemberMap } from "@/hooks/use-lookups";
import { usePermissions } from "@/hooks/use-session";
import { formatCurrency } from "@/lib/utils";
import { routes } from "@/lib/routes";
import { format, formatDistanceToNow } from "date-fns";

export function LeadDetail({ id }: { id: string }) {
  const router = useRouter();
  const { data: lead, isLoading } = useLead(id);
  const { data: activity } = useActivity();
  const memberMap = useMemberMap();
  const deleteMut = useDeleteLead();
  const convertMut = useConvertLead();
  const { can } = usePermissions();

  const [editOpen, setEditOpen] = React.useState(false);
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  const [confirmConvert, setConfirmConvert] = React.useState(false);

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-8 w-40" /><Skeleton className="h-48" /></div>;

  if (!lead) {
    return (
      <EmptyState icon={Target} title="Lead not found" description="This record may have been removed."
        action={<Button asChild variant="outline"><Link href="/leads">Back to leads</Link></Button>} />
    );
  }

  const rep = memberMap[lead.assignedRepId];
  const canConvert = lead.status !== "converted" && lead.status !== "lost";
  const leadActivity = (activity ?? []).filter((a) => a.targetId === id).slice(0, 8);

  async function handleDelete() {
    await deleteMut.mutateAsync(id);
    router.push("/leads");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button asChild variant="ghost" size="sm" className="-ml-2">
          <Link href="/leads"><ArrowLeft className="size-4" /> Leads</Link>
        </Button>
        <div className="flex gap-2">
          {canConvert && (
            <Button onClick={() => setConfirmConvert(true)}><GitBranch className="size-4" /> Convert</Button>
          )}
          <Button variant="outline" onClick={() => setEditOpen(true)}><Pencil className="size-4" /> Edit</Button>
          {can("delete") && (
            <Button variant="destructive" onClick={() => setConfirmDelete(true)}><Trash2 className="size-4" /> Delete</Button>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center">
          <Avatar name={lead.name} color={rep?.avatarColor} size="lg" />
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl font-semibold tracking-tight">{lead.name}</h1>
              <LeadStatusBadge status={lead.status} />
              <PriorityBadge priority={lead.priority} />
            </div>
            <p className="text-muted-foreground">{lead.company} · via {lead.source}</p>
          </div>
          <div className="text-right">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Estimated value</p>
            <p className="text-xl font-semibold tabular-nums">{formatCurrency(lead.estimatedValue)}</p>
          </div>
        </CardContent>
      </Card>

      {lead.status === "converted" && (
        <Card className="border-success/30 bg-success/5">
          <CardContent className="flex flex-wrap items-center gap-4 p-5 text-sm">
            <span className="font-medium text-success">This lead has been converted.</span>
            {lead.convertedCustomerId && (
              <Button asChild variant="outline" size="sm"><Link href={routes.customer(lead.convertedCustomerId)}>View customer</Link></Button>
            )}
            {lead.convertedDealId && (
              <Button asChild variant="outline" size="sm"><Link href="/deals">View deal in pipeline</Link></Button>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader><CardTitle>Contact</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-center gap-3">
              <Mail className="size-4 text-muted-foreground" />
              <a href={`mailto:${lead.email}`} className="hover:text-primary hover:underline">{lead.email}</a>
            </div>
            <div className="flex items-center gap-3"><Phone className="size-4 text-muted-foreground" /><span>{lead.phone}</span></div>
            <div className="flex items-center justify-between border-t border-border pt-3">
              <span className="text-muted-foreground">Representative</span><MemberTag member={rep} />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Created</span>
              <span>{format(new Date(lead.createdAt), "MMM d, yyyy")}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Last contacted</span>
              <span>{lead.lastContactedAt ? format(new Date(lead.lastContactedAt), "MMM d, yyyy") : "Not yet"}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Activity history</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {leadActivity.length === 0 ? (
              <p className="py-4 text-sm text-muted-foreground">No recorded activity yet.</p>
            ) : (
              leadActivity.map((a) => (
                <div key={a.id} className="flex items-start gap-3">
                  <span className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" />
                  <div>
                    <p className="text-sm">{a.detail}</p>
                    <p className="text-xs text-muted-foreground">
                      {memberMap[a.actorId]?.name ?? "System"} · {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <LeadFormDialog open={editOpen} onOpenChange={setEditOpen} lead={lead} />
      <ConfirmDialog open={confirmDelete} onOpenChange={setConfirmDelete} title="Delete lead?"
        description={`This permanently removes ${lead.name} from the demo workspace.`} confirmLabel="Delete"
        loading={deleteMut.isPending} onConfirm={handleDelete} />
      <ConfirmDialog open={confirmConvert} onOpenChange={setConfirmConvert} title="Convert this lead?"
        description="Converting creates (or links) a customer and opens a new deal in the Qualified stage."
        confirmLabel="Convert lead" destructive={false} loading={convertMut.isPending}
        onConfirm={async () => { await convertMut.mutateAsync(id); setConfirmConvert(false); }} />
    </div>
  );
}
