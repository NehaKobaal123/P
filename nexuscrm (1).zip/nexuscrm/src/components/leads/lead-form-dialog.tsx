"use client";

import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormField } from "@/components/common/form-field";
import { Spinner } from "@/components/ui/spinner";
import { useCreateLead, useMembers, useUpdateLead } from "@/hooks/use-crm";
import {
  type Lead,
  LEAD_SOURCES,
  LEAD_STATUSES,
  LEAD_STATUS_LABELS,
  PRIORITIES,
  PRIORITY_LABELS,
} from "@/types/domain";

const schema = z.object({
  name: z.string().min(2, "Enter a lead name"),
  company: z.string().min(1, "Enter a company"),
  email: z.string().email("Enter a valid email"),
  phone: z.string().min(5, "Enter a phone number"),
  source: z.enum(LEAD_SOURCES as [string, ...string[]]),
  estimatedValue: z.coerce.number().min(0, "Must be 0 or more"),
  assignedRepId: z.string().min(1, "Assign a representative"),
  priority: z.enum(PRIORITIES as [string, ...string[]]),
  status: z.enum(LEAD_STATUSES as [string, ...string[]]),
});
type Values = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lead?: Lead;
}

/** Converted leads are read-only in the form, so status cannot be reset by hand. */
const EDITABLE_STATUSES = LEAD_STATUSES.filter((s) => s !== "converted");

export function LeadFormDialog({ open, onOpenChange, lead }: Props) {
  const { data: members } = useMembers();
  const createMut = useCreateLead();
  const updateMut = useUpdateLead();
  const isEdit = Boolean(lead);

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<Values>({ resolver: zodResolver(schema) });

  React.useEffect(() => {
    if (!open) return;
    reset(
      lead
        ? {
            name: lead.name,
            company: lead.company,
            email: lead.email,
            phone: lead.phone,
            source: lead.source,
            estimatedValue: lead.estimatedValue,
            assignedRepId: lead.assignedRepId,
            priority: lead.priority,
            status: lead.status,
          }
        : {
            name: "",
            company: "",
            email: "",
            phone: "",
            source: "Website",
            estimatedValue: 10000,
            assignedRepId: members?.[0]?.id ?? "",
            priority: "medium",
            status: "new",
          },
    );
  }, [open, lead, members, reset]);

  const submitting = createMut.isPending || updateMut.isPending;

  async function onSubmit(values: Values) {
    if (isEdit && lead) await updateMut.mutateAsync({ id: lead.id, input: values as Lead });
    else await createMut.mutateAsync(values as Lead);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit lead" : "New lead"}</DialogTitle>
          <DialogDescription>
            {isEdit ? "Update this lead's details." : "Capture a new lead for qualification."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Lead name" htmlFor="name" error={errors.name?.message} required>
              <Input id="name" {...register("name")} aria-invalid={!!errors.name} />
            </FormField>
            <FormField label="Company" htmlFor="company" error={errors.company?.message} required>
              <Input id="company" {...register("company")} aria-invalid={!!errors.company} />
            </FormField>
            <FormField label="Email" htmlFor="email" error={errors.email?.message} required>
              <Input id="email" type="email" {...register("email")} aria-invalid={!!errors.email} />
            </FormField>
            <FormField label="Phone" htmlFor="phone" error={errors.phone?.message} required>
              <Input id="phone" {...register("phone")} aria-invalid={!!errors.phone} />
            </FormField>
            <FormField label="Estimated value (USD)" htmlFor="estimatedValue" error={errors.estimatedValue?.message} required>
              <Input id="estimatedValue" type="number" min={0} step={500} {...register("estimatedValue")} aria-invalid={!!errors.estimatedValue} />
            </FormField>
            <FormField label="Source" error={errors.source?.message} required>
              <Controller control={control} name="source" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue placeholder="Select source" /></SelectTrigger>
                  <SelectContent>
                    {LEAD_SOURCES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Priority" error={errors.priority?.message} required>
              <Controller control={control} name="priority" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PRIORITIES.map((p) => <SelectItem key={p} value={p}>{PRIORITY_LABELS[p]}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Status" error={errors.status?.message} required>
              <Controller control={control} name="status" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange} disabled={lead?.status === "converted"}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {EDITABLE_STATUSES.map((s) => <SelectItem key={s} value={s}>{LEAD_STATUS_LABELS[s]}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
          </div>
          <FormField label="Assigned representative" error={errors.assignedRepId?.message} required>
            <Controller control={control} name="assignedRepId" render={({ field }) => (
              <Select value={field.value} onValueChange={field.onChange}>
                <SelectTrigger><SelectValue placeholder="Select representative" /></SelectTrigger>
                <SelectContent>
                  {(members ?? []).map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )} />
          </FormField>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>Cancel</Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? <Spinner /> : null}
              {isEdit ? "Save changes" : "Create lead"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
