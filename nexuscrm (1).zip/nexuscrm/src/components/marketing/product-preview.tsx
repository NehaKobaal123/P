import { ArrowUpRight, LayoutDashboard, Search } from "lucide-react";
import { BrandGlyph } from "@/components/layout/brand";

const BARS = [38, 52, 44, 61, 70, 58, 82, 76, 90, 84, 97, 100];
const MONTHS = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];

const KPIS = [
  { label: "Total Revenue", value: "$2.4M", delta: "+12.5%" },
  { label: "Active Deals", value: "32", delta: "+4" },
  { label: "Conversion", value: "24.8%", delta: "+2.1%" },
];

const ROWS = [
  { name: "Vertex Systems — Enterprise", owner: "Ava R.", value: "$84,000", stage: "Negotiation" },
  { name: "Lumen Analytics — Platform", owner: "Marcus H.", value: "$52,500", stage: "Proposal" },
  { name: "Cobalt Health — Expansion", owner: "Priya P.", value: "$39,000", stage: "Qualified" },
];

/**
 * Static, original composition of the real NexusCRM UI, shown in the hero.
 * Hand-built from product components — no screenshots or stock imagery.
 */
export function ProductPreview() {
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-surface shadow-lg">
      {/* Window chrome */}
      <div className="flex items-center gap-2 border-b border-border bg-surface-muted/60 px-4 py-3">
        <span className="size-3 rounded-full bg-destructive/60" />
        <span className="size-3 rounded-full bg-warning/70" />
        <span className="size-3 rounded-full bg-success/60" />
        <div className="ml-3 flex flex-1 items-center gap-2 rounded-md bg-surface px-3 py-1.5 text-xs text-muted-foreground">
          <Search className="size-3.5" /> Search customers, leads, deals…
        </div>
      </div>
      <div className="flex">
        {/* Mini sidebar */}
        <div className="hidden w-40 shrink-0 flex-col gap-1 border-r border-sidebar-border bg-sidebar p-3 sm:flex">
          <div className="mb-2 flex items-center gap-2">
            <BrandGlyph className="size-6" />
            <span className="text-sm font-semibold text-sidebar-foreground">NexusCRM</span>
          </div>
          <div className="flex items-center gap-2 rounded-md bg-sidebar-accent px-2.5 py-2 text-xs font-medium text-white">
            <LayoutDashboard className="size-3.5" /> Dashboard
          </div>
          {["Customers", "Leads", "Deals", "Tasks", "Analytics"].map((l) => (
            <div key={l} className="rounded-md px-2.5 py-2 text-xs font-medium text-sidebar-muted">
              {l}
            </div>
          ))}
        </div>
        {/* Content */}
        <div className="min-w-0 flex-1 space-y-4 p-4">
          <div className="grid grid-cols-3 gap-3">
            {KPIS.map((k) => (
              <div key={k.label} className="rounded-lg border border-border bg-surface p-3">
                <p className="truncate text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                  {k.label}
                </p>
                <p className="mt-1 text-lg font-semibold tracking-tight">{k.value}</p>
                <p className="mt-0.5 inline-flex items-center gap-0.5 text-[10px] font-medium text-success">
                  <ArrowUpRight className="size-3" /> {k.delta}
                </p>
              </div>
            ))}
          </div>
          <div className="rounded-lg border border-border bg-surface p-4">
            <p className="mb-3 text-xs font-semibold text-foreground">Revenue performance</p>
            <div className="flex h-28 items-end gap-1.5">
              {BARS.map((h, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-1">
                  <div
                    className="w-full rounded-sm bg-gradient-to-t from-primary/70 to-primary"
                    style={{ height: `${h}%` }}
                  />
                  <span className="text-[8px] text-muted-foreground">{MONTHS[i]}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="overflow-hidden rounded-lg border border-border">
            <table className="w-full text-left text-[11px]">
              <thead className="bg-surface-muted/60 text-[9px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 font-semibold">Deal</th>
                  <th className="px-3 py-2 font-semibold">Owner</th>
                  <th className="px-3 py-2 font-semibold">Value</th>
                </tr>
              </thead>
              <tbody>
                {ROWS.map((r) => (
                  <tr key={r.name} className="border-t border-border">
                    <td className="truncate px-3 py-2 font-medium">{r.name}</td>
                    <td className="px-3 py-2 text-muted-foreground">{r.owner}</td>
                    <td className="px-3 py-2 font-medium">{r.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
