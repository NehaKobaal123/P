"use client";

import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormField } from "@/components/common/form-field";
import { Spinner } from "@/components/ui/spinner";
import { useCreateTask, useCustomers, useDeals, useMembers, useUpdateTask } from "@/hooks/use-crm";
import {
  type Task,
  PRIORITIES,
  PRIORITY_LABELS,
  TASK_STATUSES,
  TASK_STATUS_LABELS,
} from "@/types/domain";

const NONE = "__none__";

const schema = z.object({
  title: z.string().min(2, "Enter a task title"),
  description: z.string().max(500).optional().default(""),
  assigneeId: z.string().min(1, "Assign the task"),
  priority: z.enum(PRIORITIES as [string, ...string[]]),
  status: z.enum(TASK_STATUSES as [string, ...string[]]),
  dueDate: z.string().min(1, "Choose a due date"),
  relatedCustomerId: z.string(),
  relatedDealId: z.string(),
});
type Values = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task?: Task;
}

export function TaskFormDialog({ open, onOpenChange, task }: Props) {
  const { data: members } = useMembers();
  const { data: customers } = useCustomers();
  const { data: deals } = useDeals();
  const createMut = useCreateTask();
  const updateMut = useUpdateTask();
  const isEdit = Boolean(task);

  const { register, handleSubmit, control, reset, formState: { errors } } = useForm<Values>({
    resolver: zodResolver(schema),
  });

  React.useEffect(() => {
    if (!open) return;
    reset(
      task
        ? {
            title: task.title,
            description: task.description,
            assigneeId: task.assigneeId,
            priority: task.priority,
            status: task.status,
            dueDate: task.dueDate.slice(0, 10),
            relatedCustomerId: task.relatedCustomerId ?? NONE,
            relatedDealId: task.relatedDealId ?? NONE,
          }
        : {
            title: "",
            description: "",
            assigneeId: members?.[0]?.id ?? "",
            priority: "medium",
            status: "todo",
            dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString().slice(0, 10),
            relatedCustomerId: NONE,
            relatedDealId: NONE,
          },
    );
  }, [open, task, members, reset]);

  const submitting = createMut.isPending || updateMut.isPending;

  async function onSubmit(values: Values) {
    const payload: Task = {
      ...values,
      description: values.description ?? "",
      dueDate: new Date(values.dueDate).toISOString(),
      relatedCustomerId: values.relatedCustomerId === NONE ? null : values.relatedCustomerId,
      relatedDealId: values.relatedDealId === NONE ? null : values.relatedDealId,
    } as Task;
    if (isEdit && task) await updateMut.mutateAsync({ id: task.id, input: payload });
    else await createMut.mutateAsync(payload);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit task" : "New task"}</DialogTitle>
          <DialogDescription>
            {isEdit ? "Update this task." : "Create and assign a task to your team."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <FormField label="Title" htmlFor="title" error={errors.title?.message} required>
            <Input id="title" {...register("title")} aria-invalid={!!errors.title} />
          </FormField>
          <FormField label="Description" htmlFor="description" error={errors.description?.message}>
            <Textarea id="description" rows={2} {...register("description")} placeholder="Optional details…" />
          </FormField>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Assignee" error={errors.assigneeId?.message} required>
              <Controller control={control} name="assigneeId" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue placeholder="Select assignee" /></SelectTrigger>
                  <SelectContent>
                    {(members ?? []).map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Due date" htmlFor="dueDate" error={errors.dueDate?.message} required>
              <Input id="dueDate" type="date" {...register("dueDate")} aria-invalid={!!errors.dueDate} />
            </FormField>
            <FormField label="Priority" error={errors.priority?.message} required>
              <Controller control={control} name="priority" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PRIORITIES.map((p) => <SelectItem key={p} value={p}>{PRIORITY_LABELS[p]}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Status" error={errors.status?.message} required>
              <Controller control={control} name="status" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {TASK_STATUSES.map((s) => <SelectItem key={s} value={s}>{TASK_STATUS_LABELS[s]}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Related customer">
              <Controller control={control} name="relatedCustomerId" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>None</SelectItem>
                    {(customers ?? []).map((c) => <SelectItem key={c.id} value={c.id}>{c.company}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
            <FormField label="Related deal">
              <Controller control={control} name="relatedDealId" render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>None</SelectItem>
                    {(deals ?? []).map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              )} />
            </FormField>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>Cancel</Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? <Spinner /> : null}
              {isEdit ? "Save changes" : "Create task"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
