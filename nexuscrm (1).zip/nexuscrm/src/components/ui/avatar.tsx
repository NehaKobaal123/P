"use client";

import * as React from "react";
import { cn, initials } from "@/lib/utils";

interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  name: string;
  color?: string;
  size?: "sm" | "md" | "lg";
}

const sizeMap = {
  sm: "size-7 text-[11px]",
  md: "size-9 text-xs",
  lg: "size-12 text-sm",
};

/** Deterministic initials avatar — no image dependency. */
export function Avatar({ name, color = "#0D9488", size = "md", className, ...props }: AvatarProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-full font-semibold text-white ring-2 ring-surface",
        sizeMap[size],
        className,
      )}
      style={{ backgroundColor: color }}
      aria-hidden
      {...props}
    >
      {initials(name)}
    </span>
  );
}
