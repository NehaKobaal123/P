"use client";

/**
 * Typed React Query hooks over the active CrmService.
 *
 * Reads are cached queries; writes are mutations that invalidate the affected
 * caches (and the whole-database query the dashboard/analytics depend on) so
 * every screen stays consistent after a change.
 */
import {
  useMutation,
  useQuery,
  useQueryClient,
  type QueryClient,
} from "@tanstack/react-query";
import { toast } from "sonner";
import { getService } from "@/services";
import {
  type CustomerInput,
  type DealInput,
  type LeadInput,
  type TaskInput,
} from "@/services/crm-service";
import { type Deal, type DealStage, type Role, type TaskStatus } from "@/types/domain";

const svc = getService();

export const qk = {
  database: ["database"] as const,
  members: ["members"] as const,
  member: (id: string) => ["members", id] as const,
  customers: ["customers"] as const,
  customer: (id: string) => ["customers", id] as const,
  leads: ["leads"] as const,
  lead: (id: string) => ["leads", id] as const,
  deals: ["deals"] as const,
  deal: (id: string) => ["deals", id] as const,
  tasks: ["tasks"] as const,
  activity: ["activity"] as const,
};

/** Invalidate the caches that aggregate across entities. */
function invalidateAggregates(client: QueryClient) {
  client.invalidateQueries({ queryKey: qk.database });
  client.invalidateQueries({ queryKey: qk.activity });
}

// --- Aggregate / reference data -------------------------------------------

export function useDatabase() {
  return useQuery({ queryKey: qk.database, queryFn: () => svc.getDatabase() });
}

export function useMembers() {
  return useQuery({ queryKey: qk.members, queryFn: () => svc.listMembers() });
}

export function useMember(id: string) {
  return useQuery({ queryKey: qk.member(id), queryFn: () => svc.getMember(id), enabled: !!id });
}

export function useUpdateMemberRole() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, role }: { id: string; role: Role }) => svc.updateMemberRole(id, role),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.members });
      invalidateAggregates(client);
      toast.success("Role updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useActivity() {
  return useQuery({ queryKey: qk.activity, queryFn: () => svc.listActivity() });
}

// --- Customers ------------------------------------------------------------

export function useCustomers() {
  return useQuery({ queryKey: qk.customers, queryFn: () => svc.listCustomers() });
}

export function useCustomer(id: string) {
  return useQuery({ queryKey: qk.customer(id), queryFn: () => svc.getCustomer(id), enabled: !!id });
}

export function useCreateCustomer() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (input: CustomerInput) => svc.createCustomer(input),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.customers });
      invalidateAggregates(client);
      toast.success("Customer created");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useUpdateCustomer() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: CustomerInput }) =>
      svc.updateCustomer(id, input),
    onSuccess: (_data, { id }) => {
      client.invalidateQueries({ queryKey: qk.customers });
      client.invalidateQueries({ queryKey: qk.customer(id) });
      invalidateAggregates(client);
      toast.success("Customer updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteCustomers() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (ids: string[]) => svc.deleteCustomers(ids),
    onSuccess: (_data, ids) => {
      client.invalidateQueries({ queryKey: qk.customers });
      invalidateAggregates(client);
      toast.success(ids.length > 1 ? `${ids.length} customers deleted` : "Customer deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

// --- Leads ----------------------------------------------------------------

export function useLeads() {
  return useQuery({ queryKey: qk.leads, queryFn: () => svc.listLeads() });
}

export function useLead(id: string) {
  return useQuery({ queryKey: qk.lead(id), queryFn: () => svc.getLead(id), enabled: !!id });
}

export function useCreateLead() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (input: LeadInput) => svc.createLead(input),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.leads });
      invalidateAggregates(client);
      toast.success("Lead created");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useUpdateLead() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: LeadInput }) => svc.updateLead(id, input),
    onSuccess: (_data, { id }) => {
      client.invalidateQueries({ queryKey: qk.leads });
      client.invalidateQueries({ queryKey: qk.lead(id) });
      invalidateAggregates(client);
      toast.success("Lead updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteLead() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => svc.deleteLead(id),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.leads });
      invalidateAggregates(client);
      toast.success("Lead deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useConvertLead() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => svc.convertLead(id),
    onSuccess: (result) => {
      client.invalidateQueries({ queryKey: qk.leads });
      client.invalidateQueries({ queryKey: qk.customers });
      client.invalidateQueries({ queryKey: qk.deals });
      invalidateAggregates(client);
      toast.success(
        result.linkedExistingCustomer
          ? "Lead converted and linked to an existing customer"
          : "Lead converted — customer and deal created",
      );
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

// --- Deals ----------------------------------------------------------------

export function useDeals() {
  return useQuery({ queryKey: qk.deals, queryFn: () => svc.listDeals() });
}

export function useDeal(id: string) {
  return useQuery({ queryKey: qk.deal(id), queryFn: () => svc.getDeal(id), enabled: !!id });
}

export function useCreateDeal() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (input: DealInput) => svc.createDeal(input),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.deals });
      invalidateAggregates(client);
      toast.success("Deal created");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useUpdateDeal() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: DealInput }) => svc.updateDeal(id, input),
    onSuccess: (_data, { id }) => {
      client.invalidateQueries({ queryKey: qk.deals });
      client.invalidateQueries({ queryKey: qk.deal(id) });
      invalidateAggregates(client);
      toast.success("Deal updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteDeal() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => svc.deleteDeal(id),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.deals });
      invalidateAggregates(client);
      toast.success("Deal deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

/** Drag-and-drop reorder with optimistic update and rollback on failure. */
export function useReorderDeal() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, toStage, toIndex }: { id: string; toStage: DealStage; toIndex: number }) =>
      svc.reorderDeal(id, toStage, toIndex),
    onMutate: async (vars) => {
      await client.cancelQueries({ queryKey: qk.deals });
      const previous = client.getQueryData<Deal[]>(qk.deals);
      if (previous) {
        // Optimistically reflect the new stage so the card doesn't snap back.
        const next = previous.map((d) =>
          d.id === vars.id ? { ...d, stage: vars.toStage } : d,
        );
        client.setQueryData(qk.deals, next);
      }
      return { previous };
    },
    onError: (e: Error, _vars, context) => {
      if (context?.previous) client.setQueryData(qk.deals, context.previous);
      toast.error(e.message || "Could not move deal — reverted");
    },
    onSuccess: (deals) => {
      client.setQueryData(qk.deals, deals);
      invalidateAggregates(client);
    },
    onSettled: () => {
      client.invalidateQueries({ queryKey: qk.deals });
    },
  });
}

// --- Tasks ----------------------------------------------------------------

export function useTasks() {
  return useQuery({ queryKey: qk.tasks, queryFn: () => svc.listTasks() });
}

export function useCreateTask() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (input: TaskInput) => svc.createTask(input),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.tasks });
      invalidateAggregates(client);
      toast.success("Task created");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useUpdateTask() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: TaskInput }) => svc.updateTask(id, input),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.tasks });
      invalidateAggregates(client);
      toast.success("Task updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useSetTaskStatus() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: string; status: TaskStatus }) =>
      svc.setTaskStatus(id, status),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.tasks });
      invalidateAggregates(client);
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteTask() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => svc.deleteTask(id),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: qk.tasks });
      invalidateAggregates(client);
      toast.success("Task deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

// --- Demo controls --------------------------------------------------------

export function useResetDemo() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: () => svc.resetDemo?.() ?? Promise.resolve(),
    onSuccess: () => {
      client.invalidateQueries();
      toast.success("Demo data reset");
    },
  });
}
