"use client";

import * as React from "react";
import { useCustomers, useMembers } from "@/hooks/use-crm";
import { type Customer, type TeamMember } from "@/types/domain";

/** Map of member id → member, for resolving owners/assignees in tables. */
export function useMemberMap(): Record<string, TeamMember> {
  const { data } = useMembers();
  return React.useMemo(() => {
    const map: Record<string, TeamMember> = {};
    (data ?? []).forEach((m) => (map[m.id] = m));
    return map;
  }, [data]);
}

/** Map of customer id → customer, for resolving deal/task relations. */
export function useCustomerMap(): Record<string, Customer> {
  const { data } = useCustomers();
  return React.useMemo(() => {
    const map: Record<string, Customer> = {};
    (data ?? []).forEach((c) => (map[c.id] = c));
    return map;
  }, [data]);
}
