"use client";

import { useSessionStore } from "@/stores/session-store";
import { useMemberMap } from "@/hooks/use-lookups";
import { can as roleCan } from "@/lib/permissions";

/** Current simulated session plus the resolved team member record. */
export function useSession() {
  const userId = useSessionStore((s) => s.userId);
  const role = useSessionStore((s) => s.role);
  const authenticated = useSessionStore((s) => s.authenticated);
  const loginAs = useSessionStore((s) => s.loginAs);
  const logout = useSessionStore((s) => s.logout);
  const member = useMemberMap()[userId];
  return { userId, role, authenticated, member, loginAs, logout };
}

/** Permission checker bound to the current role. */
export function usePermissions() {
  const role = useSessionStore((s) => s.role);
  return {
    role,
    can: (key: string) => roleCan(role, key),
  };
}
