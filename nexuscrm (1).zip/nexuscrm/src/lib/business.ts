/**
 * Pure business-rule helpers shared by the data store and the tests.
 *
 * These functions never touch storage or React — they take the current data
 * and return the records that should change, so the rules (lead conversion,
 * deal ordering, stage transitions) can be reasoned about and unit-tested.
 */
import {
  type ActivityLog,
  type Customer,
  type Database,
  type Deal,
  type DealStage,
  type Lead,
} from "@/types/domain";

export function genId(prefix: string): string {
  const rand =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
  return `${prefix}_${rand}`;
}

/** Highest-priority position for a new card at the top of a stage column. */
export function topOrderForStage(deals: Deal[], stage: DealStage): number {
  const min = Math.min(...deals.filter((d) => d.stage === stage).map((d) => d.order), 0);
  return min - 1;
}

export interface LeadConversionResult {
  customer: Customer;
  deal: Deal;
  lead: Lead;
  activity: ActivityLog[];
  /** True when an existing customer was linked rather than a new one created. */
  linkedExistingCustomer: boolean;
}

export class LeadConversionError extends Error {}

/**
 * Convert a lead into a customer + an open deal.
 *
 * Idempotency: a lead that is already converted throws, so repeated clicks or
 * double submissions cannot create duplicate customers or deals. An existing
 * customer with the same email is reused instead of duplicated.
 */
export function convertLead(db: Database, leadId: string, actorId: string, at: string): LeadConversionResult {
  const lead = db.leads.find((l) => l.id === leadId);
  if (!lead) throw new LeadConversionError("Lead not found");
  if (lead.status === "converted" || lead.convertedCustomerId) {
    throw new LeadConversionError("This lead has already been converted");
  }
  if (lead.status === "lost") {
    throw new LeadConversionError("A lost lead cannot be converted");
  }

  const existing = db.customers.find(
    (c) => c.email.toLowerCase() === lead.email.toLowerCase(),
  );

  const customer: Customer =
    existing ??
    ({
      id: genId("cust"),
      name: lead.name,
      company: lead.company,
      email: lead.email,
      phone: lead.phone,
      industry: "Technology",
      status: "active",
      assignedRepId: lead.assignedRepId,
      notes: `Converted from lead (${lead.source}).`,
      createdAt: at,
      updatedAt: at,
    } satisfies Customer);

  const deal: Deal = {
    id: genId("deal"),
    name: `${customer.company} — New Opportunity`,
    customerId: customer.id,
    value: lead.estimatedValue,
    ownerId: lead.assignedRepId,
    priority: lead.priority,
    stage: "qualified",
    expectedCloseDate: new Date(new Date(at).getTime() + 1000 * 60 * 60 * 24 * 45).toISOString(),
    createdAt: at,
    updatedAt: at,
    order: topOrderForStage(db.deals, "qualified"),
    sourceLeadId: lead.id,
  };

  const convertedLead: Lead = {
    ...lead,
    status: "converted",
    convertedCustomerId: customer.id,
    convertedDealId: deal.id,
    lastContactedAt: at,
  };

  const activity: ActivityLog[] = [
    {
      id: genId("act"),
      actorId,
      action: "lead.converted",
      targetType: "lead",
      targetId: lead.id,
      targetLabel: `${lead.name} · ${lead.company}`,
      detail: existing
        ? "Converted and linked to existing customer"
        : "Converted to new customer and deal",
      createdAt: at,
    },
  ];

  return { customer, deal, lead: convertedLead, activity, linkedExistingCustomer: Boolean(existing) };
}

/**
 * Reposition a deal onto a target stage at a target index, renumbering the
 * affected columns so ordering stays stable and gap-free.
 */
export function reorderDealToStage(
  deals: Deal[],
  dealId: string,
  toStage: DealStage,
  toIndex: number,
  at: string,
): Deal[] {
  const moving = deals.find((d) => d.id === dealId);
  if (!moving) return deals;
  const fromStage = moving.stage;

  const target = deals
    .filter((d) => d.stage === toStage && d.id !== dealId)
    .sort((a, b) => a.order - b.order);

  const clampedIndex = Math.max(0, Math.min(toIndex, target.length));
  const updatedMoving: Deal = {
    ...moving,
    stage: toStage,
    updatedAt: fromStage !== toStage ? at : moving.updatedAt,
  };
  target.splice(clampedIndex, 0, updatedMoving);

  const reindexed = new Map<string, number>();
  target.forEach((d, i) => reindexed.set(d.id, i));

  // Also compact the source column if the stage changed.
  if (fromStage !== toStage) {
    deals
      .filter((d) => d.stage === fromStage && d.id !== dealId)
      .sort((a, b) => a.order - b.order)
      .forEach((d, i) => reindexed.set(d.id, i));
  }

  return deals.map((d) => {
    if (d.id === dealId) return { ...updatedMoving, order: reindexed.get(d.id) ?? d.order };
    if (reindexed.has(d.id)) return { ...d, order: reindexed.get(d.id)! };
    return d;
  });
}

/** Human-readable description of a stage change, for the activity log. */
export function describeStageChange(deal: Deal, from: DealStage, to: DealStage): string {
  if (from === to) return "Reordered";
  return `Moved from ${from} to ${to}`;
}
