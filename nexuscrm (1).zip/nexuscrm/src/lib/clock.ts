import { DEMO_NOW } from "@/lib/demo/seed";

/**
 * Reference "now" for the application.
 *
 * In demo mode the dataset is anchored to a fixed date so charts, overdue
 * badges and relative times stay stable and meaningful. A Supabase-backed
 * deployment would return `new Date()` here instead.
 */
export function now(): Date {
  return new Date(DEMO_NOW);
}
