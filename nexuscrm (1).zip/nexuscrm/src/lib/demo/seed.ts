import {
  type ActivityLog,
  type Customer,
  type CustomerStatus,
  type Database,
  type Deal,
  type DealStage,
  type Industry,
  type Lead,
  type LeadSource,
  LEAD_SOURCES,
  type LeadStatus,
  type Priority,
  type Task,
  type TaskStatus,
  type TeamMember,
} from "@/types/domain";

/** Bump when the seed shape changes so stored demo data is regenerated. */
export const DB_VERSION = 4;

/** Deterministic PRNG (mulberry32) — identical data on every seed. */
function mulberry32(seed: number) {
  let a = seed;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** A fixed "today" keeps charts and relative dates stable across reseeds. */
export const DEMO_NOW = new Date("2026-10-15T09:00:00.000Z");

function daysAgo(rand: () => number, maxDays: number): string {
  const d = new Date(DEMO_NOW);
  d.setDate(d.getDate() - Math.floor(rand() * maxDays));
  d.setHours(8 + Math.floor(rand() * 9), Math.floor(rand() * 60), 0, 0);
  return d.toISOString();
}

function daysFromNow(rand: () => number, maxDays: number): string {
  const d = new Date(DEMO_NOW);
  d.setDate(d.getDate() + Math.floor(rand() * maxDays) - Math.floor(maxDays / 4));
  return d.toISOString();
}

function pick<T>(rand: () => number, arr: readonly T[]): T {
  return arr[Math.floor(rand() * arr.length)];
}

const AVATAR_COLORS = [
  "#0D9488",
  "#2563EB",
  "#16A34A",
  "#D97706",
  "#DC2626",
  "#0EA5E9",
  "#EA580C",
  "#475569",
];

const FIRST_NAMES = [
  "Ava", "Liam", "Maya", "Noah", "Priya", "Ethan", "Sofia", "Lucas", "Nina", "Omar",
  "Elena", "Diego", "Hana", "Marcus", "Zoe", "Ian", "Leah", "Theo", "Ruby", "Sam",
  "Ivy", "Kai", "Nora", "Jonah", "Amara", "Felix", "Tara", "Rory", "Dana", "Max",
];
const LAST_NAMES = [
  "Reyes", "Okafor", "Nguyen", "Patel", "Brooks", "Castellanos", "Lindqvist", "Haddad",
  "Moreau", "Kowalski", "Serrano", "Abebe", "Fischer", "Rossi", "Dubois", "Novak",
  "Tanaka", "Ferreira", "Andersen", "Costa", "Walsh", "Mbeki", "Larsen", "Romano",
];
const COMPANY_PREFIX = [
  "North", "Bright", "Vertex", "Lumen", "Quant", "Atlas", "Cobalt", "Cedar", "Orbit",
  "Pulse", "Summit", "Nova", "Harbor", "Ironwood", "Beacon", "Meridian", "Arbor", "Flux",
];
const COMPANY_SUFFIX = [
  "Labs", "Systems", "Dynamics", "Health", "Capital", "Retail Group", "Analytics",
  "Logistics", "Media", "Works", "Technologies", "Partners", "Industries", "Networks",
];

function fullName(rand: () => number): string {
  return `${pick(rand, FIRST_NAMES)} ${pick(rand, LAST_NAMES)}`;
}

function companyName(rand: () => number): string {
  return `${pick(rand, COMPANY_PREFIX)} ${pick(rand, COMPANY_SUFFIX)}`;
}

function slugEmail(name: string, domain: string): string {
  return `${name.toLowerCase().replace(/[^a-z]+/g, ".")}@${domain}`;
}

function companyDomain(company: string): string {
  return `${company.toLowerCase().replace(/[^a-z]+/g, "")}.com`;
}

const INDUSTRY_WEIGHT: Industry[] = [
  "Technology", "Technology", "Healthcare", "Finance", "Retail",
  "Manufacturing", "Education", "Real Estate", "Media", "Technology",
];

/** Build the full deterministic demo database. */
export function buildSeedDatabase(): Database {
  const rand = mulberry32(20260815);

  // --- Team members -------------------------------------------------------
  const members: TeamMember[] = [
    { role: "admin", title: "Head of Revenue" },
    { role: "manager", title: "Sales Manager" },
    { role: "manager", title: "Partnerships Manager" },
    { role: "rep", title: "Account Executive" },
    { role: "rep", title: "Account Executive" },
    { role: "rep", title: "Sales Development Rep" },
  ].map((base, i) => {
    const name = fullName(rand);
    return {
      id: `member_${i + 1}`,
      name,
      email: slugEmail(name, "nexuscrm.demo"),
      role: base.role as TeamMember["role"],
      status: (i === 5 ? "invited" : "active") as TeamMember["status"],
      title: base.title,
      avatarColor: AVATAR_COLORS[i % AVATAR_COLORS.length],
      createdAt: daysAgo(rand, 420),
    };
  });
  const repIds = members.map((m) => m.id);

  // --- Customers ----------------------------------------------------------
  const customerStatusPool: CustomerStatus[] = [
    "active", "active", "active", "prospect", "prospect", "at_risk", "churned",
  ];
  const customers: Customer[] = Array.from({ length: 52 }, (_, i) => {
    const company = companyName(rand);
    const contact = fullName(rand);
    const createdAt = daysAgo(rand, 400);
    return {
      id: `cust_${i + 1}`,
      name: contact,
      company,
      email: slugEmail(contact, companyDomain(company)),
      phone: `+1 (${200 + Math.floor(rand() * 700)}) ${100 + Math.floor(rand() * 900)}-${1000 + Math.floor(rand() * 9000)}`,
      industry: pick(rand, INDUSTRY_WEIGHT),
      status: pick(rand, customerStatusPool),
      assignedRepId: pick(rand, repIds),
      notes: "",
      createdAt,
      updatedAt: createdAt,
    };
  });

  // --- Leads --------------------------------------------------------------
  const leadStatusPool: LeadStatus[] = [
    "new", "new", "contacted", "contacted", "qualified", "qualified", "proposal", "lost",
  ];
  const leads: Lead[] = Array.from({ length: 44 }, (_, i) => {
    const company = companyName(rand);
    const contact = fullName(rand);
    const createdAt = daysAgo(rand, 120);
    const status = pick(rand, leadStatusPool);
    return {
      id: `lead_${i + 1}`,
      name: contact,
      company,
      email: slugEmail(contact, companyDomain(company)),
      phone: `+1 (${200 + Math.floor(rand() * 700)}) ${100 + Math.floor(rand() * 900)}-${1000 + Math.floor(rand() * 9000)}`,
      source: pick(rand, LEAD_SOURCES) as LeadSource,
      estimatedValue: (5 + Math.floor(rand() * 60)) * 1000,
      assignedRepId: pick(rand, repIds),
      priority: pick(rand, ["low", "medium", "high"] as Priority[]),
      status,
      createdAt,
      lastContactedAt: status === "new" ? null : daysAgo(rand, 20),
      convertedCustomerId: null,
      convertedDealId: null,
    };
  });

  // --- Deals --------------------------------------------------------------
  // Spread won/lost close dates across the past 12 months for revenue charts.
  const stagePool: DealStage[] = [
    "new", "new", "qualified", "qualified", "proposal", "proposal",
    "negotiation", "won", "won", "won", "lost",
  ];
  const stageCounters: Record<string, number> = {};
  const deals: Deal[] = Array.from({ length: 46 }, (_, i) => {
    const customer = pick(rand, customers);
    const stage = pick(rand, stagePool);
    stageCounters[stage] = (stageCounters[stage] ?? 0) + 1;
    const createdAt = daysAgo(rand, 330);
    const isClosed = stage === "won" || stage === "lost";
    // Closed deals land across the last ~11 months; open deals close in future.
    const closeOffset = Math.floor(rand() * 330);
    const closed = new Date(DEMO_NOW);
    closed.setDate(closed.getDate() - closeOffset);
    return {
      id: `deal_${i + 1}`,
      name: `${customer.company} — ${pick(rand, ["Platform", "Expansion", "Renewal", "Pilot", "Enterprise", "Add-on"])} ${pick(rand, ["Deal", "Agreement", "Rollout", "Contract"])}`,
      customerId: customer.id,
      value: (8 + Math.floor(rand() * 90)) * 1000,
      ownerId: customer.assignedRepId,
      priority: pick(rand, ["low", "medium", "high"] as Priority[]),
      stage,
      expectedCloseDate: isClosed ? closed.toISOString() : daysFromNow(rand, 120),
      createdAt,
      updatedAt: isClosed ? closed.toISOString() : createdAt,
      order: stageCounters[stage],
      sourceLeadId: null,
    };
  });

  // --- Tasks --------------------------------------------------------------
  const taskTitles = [
    "Follow up on proposal", "Schedule discovery call", "Send pricing deck",
    "Prepare QBR summary", "Renewal check-in", "Draft contract redlines",
    "Demo the analytics module", "Confirm security review", "Share onboarding plan",
    "Loop in solutions engineer", "Update account notes", "Negotiate final terms",
  ];
  const taskStatusPool: TaskStatus[] = ["todo", "todo", "in_progress", "in_progress", "done", "done"];
  const tasks: Task[] = Array.from({ length: 34 }, (_, i) => {
    const status = pick(rand, taskStatusPool);
    const relatedCustomer = rand() > 0.3 ? pick(rand, customers) : null;
    const relatedDeal = rand() > 0.5 ? pick(rand, deals) : null;
    const createdAt = daysAgo(rand, 40);
    const due = daysFromNow(rand, 30);
    return {
      id: `task_${i + 1}`,
      title: pick(rand, taskTitles),
      description: "",
      assigneeId: pick(rand, repIds),
      priority: pick(rand, ["low", "medium", "high"] as Priority[]),
      status,
      dueDate: due,
      relatedCustomerId: relatedCustomer?.id ?? null,
      relatedDealId: relatedDeal?.id ?? null,
      createdAt,
      completedAt: status === "done" ? daysAgo(rand, 10) : null,
    };
  });

  // --- Lead conversions ---------------------------------------------------
  // Mark a handful of qualified/proposal leads as converted and link them to a
  // real customer and a won deal, so conversion metrics and the funnel are
  // populated out of the box.
  const wonForLink = deals.filter((d) => d.stage === "won");
  leads
    .filter((l) => l.status === "qualified" || l.status === "proposal")
    .slice(0, 7)
    .forEach((l, i) => {
      l.status = "converted";
      l.convertedCustomerId = customers[(i * 5) % customers.length].id;
      l.convertedDealId = wonForLink.length ? wonForLink[i % wonForLink.length].id : null;
      l.lastContactedAt = daysAgo(rand, 15);
    });

  // --- Activity log (derived from the records above) ----------------------
  const activity: ActivityLog[] = [];
  const admin = members[0];
  deals
    .filter((d) => d.stage === "won")
    .slice(0, 8)
    .forEach((d, i) => {
      activity.push({
        id: `act_won_${i}`,
        actorId: d.ownerId,
        action: "deal.stage_changed",
        targetType: "deal",
        targetId: d.id,
        targetLabel: d.name,
        detail: "Moved to Won",
        createdAt: d.updatedAt,
      });
    });
  customers.slice(0, 10).forEach((c, i) => {
    activity.push({
      id: `act_cust_${i}`,
      actorId: c.assignedRepId,
      action: "customer.created",
      targetType: "customer",
      targetId: c.id,
      targetLabel: `${c.name} · ${c.company}`,
      detail: `Added as ${c.status}`,
      createdAt: c.createdAt,
    });
  });
  tasks
    .filter((t) => t.status === "done")
    .slice(0, 8)
    .forEach((t, i) => {
      activity.push({
        id: `act_task_${i}`,
        actorId: t.assigneeId,
        action: "task.completed",
        targetType: "task",
        targetId: t.id,
        targetLabel: t.title,
        detail: "Marked complete",
        createdAt: t.completedAt ?? t.createdAt,
      });
    });
  activity.push({
    id: "act_role_seed",
    actorId: admin.id,
    action: "team.role_changed",
    targetType: "member",
    targetId: members[3].id,
    targetLabel: members[3].name,
    detail: "Promoted to Account Executive",
    createdAt: daysAgo(rand, 30),
  });
  activity.sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  return { version: DB_VERSION, members, customers, leads, deals, tasks, activity };
}
