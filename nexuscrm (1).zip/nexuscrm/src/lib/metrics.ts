/**
 * Deterministic business metrics.
 *
 * Every figure the dashboard and analytics screens show is computed here from
 * the actual records — there are no random or hard-coded KPI numbers. All
 * functions are pure so they can be unit-tested in isolation.
 */
import {
  type ActivityLog,
  type Customer,
  type Database,
  type Deal,
  type DealStage,
  DEAL_STAGE_LABELS,
  type Lead,
  type LeadSource,
  LEAD_SOURCES,
  OPEN_DEAL_STAGES,
  STAGE_WIN_PROBABILITY,
  type Task,
  type TeamMember,
} from "@/types/domain";
import { now } from "@/lib/clock";

export type DateRangeKey = "7d" | "30d" | "90d" | "custom";

export interface DateRange {
  from: Date;
  to: Date;
}

export function rangeFromKey(key: Exclude<DateRangeKey, "custom">): DateRange {
  const to = now();
  const from = new Date(to);
  const days = key === "7d" ? 7 : key === "30d" ? 30 : 90;
  from.setDate(from.getDate() - days);
  return { from, to };
}

function inRange(iso: string, range: DateRange): boolean {
  const t = new Date(iso).getTime();
  return t >= range.from.getTime() && t <= range.to.getTime();
}

function previousRange(range: DateRange): DateRange {
  const span = range.to.getTime() - range.from.getTime();
  return { from: new Date(range.from.getTime() - span), to: new Date(range.from.getTime()) };
}

function wonDeals(deals: Deal[]): Deal[] {
  return deals.filter((d) => d.stage === "won");
}

export function totalRevenue(deals: Deal[]): number {
  return wonDeals(deals).reduce((sum, d) => sum + d.value, 0);
}

export interface Kpi {
  key: string;
  label: string;
  value: number;
  /** Percentage change vs the previous comparable period (null if N/A). */
  deltaPercent: number | null;
  format: "currency" | "number" | "percent";
  hint: string;
}

/** Percentage change, guarding against divide-by-zero. */
export function pctChange(current: number, previous: number): number | null {
  if (previous === 0) return current === 0 ? 0 : null;
  return ((current - previous) / previous) * 100;
}

/** Headline KPI tiles for the executive dashboard, scoped to a date range. */
export function computeKpis(db: Database, range: DateRange): Kpi[] {
  const prev = previousRange(range);

  const wonInRange = db.deals.filter((d) => d.stage === "won" && inRange(d.updatedAt, range));
  const wonInPrev = db.deals.filter((d) => d.stage === "won" && inRange(d.updatedAt, prev));
  const revenue = wonInRange.reduce((s, d) => s + d.value, 0);
  const prevRevenue = wonInPrev.reduce((s, d) => s + d.value, 0);

  const activeCustomers = db.customers.filter((c) => c.status === "active").length;
  const prevActiveCustomers = db.customers.filter(
    (c) => c.status === "active" && new Date(c.createdAt) <= prev.to,
  ).length;

  const activeDeals = db.deals.filter((d) => OPEN_DEAL_STAGES.includes(d.stage)).length;

  const leadsInScope = db.leads.filter((l) => inRange(l.createdAt, range));
  const conversion = conversionRate(leadsInScope);
  const prevConversion = conversionRate(db.leads.filter((l) => inRange(l.createdAt, prev)));

  const openTasks = db.tasks.filter((t) => t.status !== "done").length;

  return [
    {
      key: "revenue",
      label: "Total Revenue",
      value: revenue,
      deltaPercent: pctChange(revenue, prevRevenue),
      format: "currency",
      hint: "Closed-won value in range",
    },
    {
      key: "customers",
      label: "Active Customers",
      value: activeCustomers,
      deltaPercent: pctChange(activeCustomers, prevActiveCustomers),
      format: "number",
      hint: "Customers in an active lifecycle",
    },
    {
      key: "deals",
      label: "Active Deals",
      value: activeDeals,
      deltaPercent: null,
      format: "number",
      hint: "Open opportunities in the pipeline",
    },
    {
      key: "conversion",
      label: "Conversion Rate",
      value: conversion,
      deltaPercent: pctChange(conversion, prevConversion),
      format: "percent",
      hint: "Leads converted vs created in range",
    },
    {
      key: "tasks",
      label: "Open Tasks",
      value: openTasks,
      deltaPercent: null,
      format: "number",
      hint: "Tasks not yet completed",
    },
    {
      key: "growth",
      label: "Revenue Growth",
      value: pctChange(revenue, prevRevenue) ?? 0,
      deltaPercent: pctChange(revenue, prevRevenue),
      format: "percent",
      hint: "Range vs previous period",
    },
  ];
}

/** Converted leads as a percentage of all leads in the set. */
export function conversionRate(leads: Lead[]): number {
  if (leads.length === 0) return 0;
  const converted = leads.filter((l) => l.status === "converted").length;
  return (converted / leads.length) * 100;
}

/** Win rate = won / (won + lost) among closed deals. */
export function winRate(deals: Deal[]): number {
  const won = deals.filter((d) => d.stage === "won").length;
  const lost = deals.filter((d) => d.stage === "lost").length;
  const closed = won + lost;
  return closed === 0 ? 0 : (won / closed) * 100;
}

export function averageDealValue(deals: Deal[]): number {
  const won = wonDeals(deals);
  return won.length === 0 ? 0 : totalRevenue(deals) / won.length;
}

/** Weighted pipeline forecast: open-deal value × stage probability. */
export function forecastPipelineValue(deals: Deal[]): number {
  return deals
    .filter((d) => OPEN_DEAL_STAGES.includes(d.stage))
    .reduce((sum, d) => sum + d.value * STAGE_WIN_PROBABILITY[d.stage], 0);
}

export function openPipelineValue(deals: Deal[]): number {
  return deals
    .filter((d) => OPEN_DEAL_STAGES.includes(d.stage))
    .reduce((sum, d) => sum + d.value, 0);
}

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export interface MonthlyPoint {
  month: string; // short label e.g. "Jan"
  key: string;
  revenue: number;
  deals: number;
}

/** Revenue and won-deal count per month for the last `months` months. */
export function revenueByMonth(deals: Deal[], months = 12): MonthlyPoint[] {
  const end = now();
  const buckets: MonthlyPoint[] = [];
  const index = new Map<string, MonthlyPoint>();
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(end.getFullYear(), end.getMonth() - i, 1);
    const point: MonthlyPoint = {
      month: d.toLocaleString("en-US", { month: "short" }),
      key: monthKey(d),
      revenue: 0,
      deals: 0,
    };
    buckets.push(point);
    index.set(point.key, point);
  }
  for (const d of wonDeals(deals)) {
    const point = index.get(monthKey(new Date(d.updatedAt)));
    if (point) {
      point.revenue += d.value;
      point.deals += 1;
    }
  }
  return buckets;
}

/** Average closed-won deal value per month (0 when no deals closed). */
export function avgDealValueByMonth(deals: Deal[], months = 12): { label: string; value: number }[] {
  return revenueByMonth(deals, months).map((m) => ({
    label: m.month,
    value: m.deals === 0 ? 0 : Math.round(m.revenue / m.deals),
  }));
}

/** Cumulative customer count at the end of each of the last `months` months. */
export function customerGrowthByMonth(
  customers: Customer[],
  months = 12,
): { label: string; value: number }[] {
  const end = now();
  const points: { label: string; value: number }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const monthEnd = new Date(end.getFullYear(), end.getMonth() - i + 1, 0, 23, 59, 59);
    const count = customers.filter((c) => new Date(c.createdAt) <= monthEnd).length;
    points.push({ label: monthEnd.toLocaleString("en-US", { month: "short" }), value: count });
  }
  return points;
}

export interface StageDatum {
  stage: DealStage;
  label: string;
  count: number;
  value: number;
}

export function dealsByStage(deals: Deal[]): StageDatum[] {
  return (Object.keys(DEAL_STAGE_LABELS) as DealStage[]).map((stage) => {
    const inStage = deals.filter((d) => d.stage === stage);
    return {
      stage,
      label: DEAL_STAGE_LABELS[stage],
      count: inStage.length,
      value: inStage.reduce((s, d) => s + d.value, 0),
    };
  });
}

export interface SourceDatum {
  source: LeadSource;
  count: number;
  value: number;
}

export function leadsBySource(leads: Lead[]): SourceDatum[] {
  return LEAD_SOURCES.map((source) => {
    const inSource = leads.filter((l) => l.source === source);
    return {
      source,
      count: inSource.length,
      value: inSource.reduce((s, l) => s + l.estimatedValue, 0),
    };
  }).filter((d) => d.count > 0);
}

export interface RepPerformance {
  member: TeamMember;
  wonValue: number;
  wonCount: number;
  openValue: number;
  openCount: number;
}

/** Sales reps ranked by closed-won value. */
export function repPerformance(db: Database): RepPerformance[] {
  return db.members
    .map((member) => {
      const theirDeals = db.deals.filter((d) => d.ownerId === member.id);
      const won = theirDeals.filter((d) => d.stage === "won");
      const open = theirDeals.filter((d) => OPEN_DEAL_STAGES.includes(d.stage));
      return {
        member,
        wonValue: won.reduce((s, d) => s + d.value, 0),
        wonCount: won.length,
        openValue: open.reduce((s, d) => s + d.value, 0),
        openCount: open.length,
      };
    })
    .sort((a, b) => b.wonValue - a.wonValue);
}

export interface FunnelStep {
  label: string;
  count: number;
}

/**
 * Lead-progression funnel. Each step is a subset of the one above it, so the
 * counts are monotonically non-increasing by construction.
 */
export function salesFunnel(db: Database): FunnelStep[] {
  const has = (statuses: string[]) => db.leads.filter((l) => statuses.includes(l.status)).length;
  return [
    { label: "Leads", count: db.leads.length },
    { label: "Contacted", count: has(["contacted", "qualified", "proposal", "converted"]) },
    { label: "Qualified", count: has(["qualified", "proposal", "converted"]) },
    { label: "Proposal", count: has(["proposal", "converted"]) },
    { label: "Converted", count: has(["converted"]) },
  ];
}

// --- Dashboard list selectors ---------------------------------------------

export function recentDeals(db: Database, limit = 5): Deal[] {
  return [...db.deals].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit);
}

export function upcomingTasks(db: Database, limit = 5): Task[] {
  const today = now().getTime();
  return db.tasks
    .filter((t) => t.status !== "done")
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .filter((t) => new Date(t.dueDate).getTime() >= today - 1000 * 60 * 60 * 24 * 30)
    .slice(0, limit);
}

export function recentActivity(activity: ActivityLog[], limit = 6): ActivityLog[] {
  return [...activity].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
}

export function isOverdue(task: Task): boolean {
  return task.status !== "done" && new Date(task.dueDate).getTime() < now().getTime();
}

export function customerById(db: Database, id: string): Customer | undefined {
  return db.customers.find((c) => c.id === id);
}

export function memberById(db: Database, id: string): TeamMember | undefined {
  return db.members.find((m) => m.id === id);
}
