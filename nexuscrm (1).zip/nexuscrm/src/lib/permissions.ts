import { type Role } from "@/types/domain";

/**
 * Role → permission matrix.
 *
 * This is the single source of truth for what each role may do. In demo mode
 * it documents intent and drives the permission matrix UI; in a Supabase
 * deployment the same rules are enforced by Row Level Security policies
 * (see supabase/migrations) so the frontend is never the only gatekeeper.
 */
export interface Permission {
  key: string;
  label: string;
  roles: Record<Role, boolean>;
}

/** Does `role` hold the permission identified by `key`? */
export function can(role: Role, key: string): boolean {
  return PERMISSIONS.find((p) => p.key === key)?.roles[role] ?? false;
}

export const PERMISSIONS: Permission[] = [
  { key: "view", label: "View customers, leads & deals", roles: { admin: true, manager: true, rep: true } },
  { key: "manage_own", label: "Create & edit own records", roles: { admin: true, manager: true, rep: true } },
  { key: "manage_all", label: "Edit any team member's records", roles: { admin: true, manager: true, rep: false } },
  { key: "delete", label: "Delete customers & deals", roles: { admin: true, manager: true, rep: false } },
  { key: "convert", label: "Convert leads", roles: { admin: true, manager: true, rep: true } },
  { key: "manage_team", label: "Manage team & change roles", roles: { admin: true, manager: false, rep: false } },
  { key: "org_settings", label: "Edit organization settings", roles: { admin: true, manager: false, rep: false } },
  { key: "view_activity", label: "View full activity log", roles: { admin: true, manager: true, rep: false } },
];
