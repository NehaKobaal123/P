/**
 * Centralized route builders.
 *
 * Detail pages use a query parameter (`?id=`) rather than a dynamic `[id]`
 * segment so the whole app is compatible with Next.js static export (no
 * server needed to render records created at runtime in the browser).
 */
export const routes = {
  dashboard: "/dashboard",
  customers: "/customers",
  customer: (id: string) => `/customers/record?id=${encodeURIComponent(id)}`,
  leads: "/leads",
  lead: (id: string) => `/leads/record?id=${encodeURIComponent(id)}`,
  deals: "/deals",
  tasks: "/tasks",
} as const;
