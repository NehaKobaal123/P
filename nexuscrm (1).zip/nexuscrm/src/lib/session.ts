import { useSessionStore } from "@/stores/session-store";

/**
 * The current simulated user's id, read synchronously from the session store.
 * Used to attribute activity-log entries. A real deployment would resolve this
 * from an authenticated session instead.
 */
export function getActorId(): string {
  return useSessionStore.getState().userId;
}
