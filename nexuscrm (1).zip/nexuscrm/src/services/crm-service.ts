/**
 * The data-access seam.
 *
 * Every screen talks to a `CrmService`, never to localStorage or Supabase
 * directly. The demo adapter and the Supabase adapter both implement this
 * interface, so switching backends never requires touching presentation code.
 * All methods are async to match a real network-backed implementation.
 */
import {
  type ActivityLog,
  type Customer,
  type CustomerStatus,
  type Database,
  type Deal,
  type DealStage,
  type Industry,
  type Lead,
  type LeadSource,
  type LeadStatus,
  type Priority,
  type Role,
  type Task,
  type TaskStatus,
  type TeamMember,
} from "@/types/domain";

export interface CustomerInput {
  name: string;
  company: string;
  email: string;
  phone: string;
  industry: Industry;
  status: CustomerStatus;
  assignedRepId: string;
  notes: string;
}

export interface LeadInput {
  name: string;
  company: string;
  email: string;
  phone: string;
  source: LeadSource;
  estimatedValue: number;
  assignedRepId: string;
  priority: Priority;
  status: LeadStatus;
}

export interface DealInput {
  name: string;
  customerId: string;
  value: number;
  ownerId: string;
  priority: Priority;
  stage: DealStage;
  expectedCloseDate: string;
}

export interface TaskInput {
  title: string;
  description: string;
  assigneeId: string;
  priority: Priority;
  status: TaskStatus;
  dueDate: string;
  relatedCustomerId: string | null;
  relatedDealId: string | null;
}

export interface ConvertLeadResult {
  customerId: string;
  dealId: string;
  linkedExistingCustomer: boolean;
}

export interface CrmService {
  /** Whole snapshot — used by dashboard & analytics aggregations. */
  getDatabase(): Promise<Database>;

  listMembers(): Promise<TeamMember[]>;
  getMember(id: string): Promise<TeamMember | null>;
  updateMemberRole(id: string, role: Role): Promise<TeamMember>;

  listCustomers(): Promise<Customer[]>;
  getCustomer(id: string): Promise<Customer | null>;
  createCustomer(input: CustomerInput): Promise<Customer>;
  updateCustomer(id: string, input: CustomerInput): Promise<Customer>;
  deleteCustomer(id: string): Promise<void>;
  deleteCustomers(ids: string[]): Promise<void>;

  listLeads(): Promise<Lead[]>;
  getLead(id: string): Promise<Lead | null>;
  createLead(input: LeadInput): Promise<Lead>;
  updateLead(id: string, input: LeadInput): Promise<Lead>;
  deleteLead(id: string): Promise<void>;
  convertLead(id: string): Promise<ConvertLeadResult>;

  listDeals(): Promise<Deal[]>;
  getDeal(id: string): Promise<Deal | null>;
  createDeal(input: DealInput): Promise<Deal>;
  updateDeal(id: string, input: DealInput): Promise<Deal>;
  deleteDeal(id: string): Promise<void>;
  reorderDeal(id: string, toStage: DealStage, toIndex: number): Promise<Deal[]>;

  listTasks(): Promise<Task[]>;
  createTask(input: TaskInput): Promise<Task>;
  updateTask(id: string, input: TaskInput): Promise<Task>;
  setTaskStatus(id: string, status: TaskStatus): Promise<Task>;
  deleteTask(id: string): Promise<void>;

  listActivity(): Promise<ActivityLog[]>;

  /** Demo-only: restore the seeded dataset. No-op for a real backend. */
  resetDemo?(): Promise<void>;
}
