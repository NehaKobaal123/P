import { type CrmService } from "@/services/crm-service";
import { LocalCrmService } from "@/services/local/local-crm-service";

/**
 * Resolve the active data adapter.
 *
 * The app ships in demo mode (localStorage) so it runs with zero configuration.
 * When Supabase env vars are present AND `NEXT_PUBLIC_DATA_MODE=supabase`, the
 * Supabase adapter is used instead — the UI is unchanged either way.
 */
let instance: CrmService | null = null;

export function isSupabaseConfigured(): boolean {
  return (
    process.env.NEXT_PUBLIC_DATA_MODE === "supabase" &&
    Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL) &&
    Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)
  );
}

export function getService(): CrmService {
  if (instance) return instance;
  // Demo mode is the default so the product is always runnable with zero config.
  //
  // To run against Supabase, implement a `SupabaseCrmService` (CrmService) using
  // the client in src/services/supabase/client.ts and the schema in
  // supabase/migrations, then return it here when `isSupabaseConfigured()`. No
  // presentation code changes, because every screen depends only on CrmService.
  instance = new LocalCrmService();
  return instance;
}

export const DATA_MODE: "demo" | "supabase" = isSupabaseConfigured() ? "supabase" : "demo";
