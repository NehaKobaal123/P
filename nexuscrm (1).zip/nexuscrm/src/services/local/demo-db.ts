/**
 * IndexedDB-backed demo database (via Dexie).
 *
 * The seeded dataset is loaded once into an in-memory cache, and every mutation
 * writes the cache back to IndexedDB. This gives reliable persistence across
 * browser refreshes while keeping the synchronous, whole-database business
 * logic simple. All data is per-browser and isolated — nothing leaves the
 * device or is shared between users.
 */
import { type Database } from "@/types/domain";
import { buildSeedDatabase, DB_VERSION } from "@/lib/demo/seed";
import { getDb } from "@/services/local/dexie";

const VERSION_KEY = "schema.version";

let cache: Database | null = null;
let readyPromise: Promise<Database> | null = null;

function isBrowser(): boolean {
  return typeof window !== "undefined" && typeof indexedDB !== "undefined";
}

/** Read every entity table into a single in-memory Database object. */
async function readAll(): Promise<Database> {
  const db = getDb();
  const [members, customers, leads, deals, tasks, activity, versionRow] = await Promise.all([
    db.members.toArray(),
    db.customers.toArray(),
    db.leads.toArray(),
    db.deals.toArray(),
    db.tasks.toArray(),
    db.activity.toArray(),
    db.meta.get(VERSION_KEY),
  ]);
  return {
    version: versionRow ? Number(versionRow.value) : 0,
    members,
    customers,
    leads,
    deals,
    tasks,
    activity,
  };
}

/** Replace all entity tables with the given dataset (meta preferences kept). */
async function writeAll(data: Database): Promise<void> {
  const db = getDb();
  await db.transaction(
    "rw",
    [db.members, db.customers, db.leads, db.deals, db.tasks, db.activity, db.meta],
    async () => {
      await Promise.all([
        db.members.clear(),
        db.customers.clear(),
        db.leads.clear(),
        db.deals.clear(),
        db.tasks.clear(),
        db.activity.clear(),
      ]);
      await Promise.all([
        db.members.bulkPut(data.members),
        db.customers.bulkPut(data.customers),
        db.leads.bulkPut(data.leads),
        db.deals.bulkPut(data.deals),
        db.tasks.bulkPut(data.tasks),
        db.activity.bulkPut(data.activity),
        db.meta.put({ key: VERSION_KEY, value: String(DB_VERSION) }),
      ]);
    },
  );
}

async function seedFresh(): Promise<Database> {
  const fresh = buildSeedDatabase();
  if (isBrowser()) await writeAll(fresh);
  return fresh;
}

/**
 * Ensure the database is loaded (seeding or migrating on first run) and return
 * the in-memory cache. Safe to call repeatedly; the work happens once.
 */
export async function ensureReady(): Promise<Database> {
  if (cache) return cache;
  if (!isBrowser()) {
    // SSR / build: provide the seed in memory without touching IndexedDB.
    cache = buildSeedDatabase();
    return cache;
  }
  if (!readyPromise) {
    readyPromise = (async () => {
      const loaded = await readAll();
      cache = loaded.version === DB_VERSION && loaded.customers.length > 0 ? loaded : await seedFresh();
      return cache;
    })();
  }
  return readyPromise;
}

/** The loaded in-memory database. Call `ensureReady()` first. */
export function getCache(): Database {
  if (!cache) throw new Error("Demo database not initialized — call ensureReady() first");
  return cache;
}

/** Persist the current cache to IndexedDB. */
export async function persist(): Promise<void> {
  if (!cache || !isBrowser()) return;
  await writeAll(cache);
}

/**
 * Apply a synchronous mutation to the cache, then persist it. Reuses the pure,
 * whole-database business logic the app already has.
 */
export async function mutate(fn: (db: Database) => void): Promise<Database> {
  await ensureReady();
  const db = getCache();
  fn(db);
  await persist();
  return db;
}

/** Restore the pristine seeded dataset (resets CRM records, keeps preferences). */
export async function resetDb(): Promise<Database> {
  cache = await seedFresh();
  readyPromise = Promise.resolve(cache);
  return cache;
}

/** Deep clone so callers can never mutate the cached store by reference. */
export function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}
