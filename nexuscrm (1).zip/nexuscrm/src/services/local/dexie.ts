import Dexie, { type Table } from "dexie";
import {
  type ActivityLog,
  type Customer,
  type Deal,
  type Lead,
  type Task,
  type TeamMember,
} from "@/types/domain";

/** A key/value row used for the schema version and client-only preferences. */
export interface MetaRow {
  key: string;
  value: string;
}

/**
 * The browser-local NexusCRM database (IndexedDB via Dexie).
 *
 * Entity tables hold the CRM records; the `meta` table holds the seed version
 * and serialized UI/session preferences. Everything lives in the visitor's
 * browser — nothing is shared between users or sent to a server.
 */
export class NexusDB extends Dexie {
  members!: Table<TeamMember, string>;
  customers!: Table<Customer, string>;
  leads!: Table<Lead, string>;
  deals!: Table<Deal, string>;
  tasks!: Table<Task, string>;
  activity!: Table<ActivityLog, string>;
  meta!: Table<MetaRow, string>;

  constructor() {
    super("nexuscrm");
    this.version(1).stores({
      members: "id",
      customers: "id, status, industry, assignedRepId",
      leads: "id, status, source, assignedRepId",
      deals: "id, stage, ownerId, customerId",
      tasks: "id, status, assigneeId",
      activity: "id, createdAt",
      meta: "key",
    });
  }
}

let instance: NexusDB | null = null;

/** Lazily construct the Dexie instance (only ever in the browser). */
export function getDb(): NexusDB {
  if (!instance) instance = new NexusDB();
  return instance;
}

/**
 * A Zustand `StateStorage` backed by the `meta` table, so UI and session
 * preferences persist in IndexedDB alongside the CRM data. All reads/writes are
 * guarded so SSR and private-mode failures never crash the app.
 */
function canUseDb(): boolean {
  return typeof window !== "undefined" && typeof indexedDB !== "undefined";
}

export const dexieKeyvalStorage = {
  async getItem(name: string): Promise<string | null> {
    if (!canUseDb()) return null;
    try {
      const row = await getDb().meta.get(name);
      return row?.value ?? null;
    } catch {
      return null;
    }
  },
  async setItem(name: string, value: string): Promise<void> {
    if (!canUseDb()) return;
    try {
      await getDb().meta.put({ key: name, value });
    } catch {
      // Ignore persistence errors (e.g. private mode) — state still works in memory.
    }
  },
  async removeItem(name: string): Promise<void> {
    if (!canUseDb()) return;
    try {
      await getDb().meta.delete(name);
    } catch {
      // No-op.
    }
  },
};
