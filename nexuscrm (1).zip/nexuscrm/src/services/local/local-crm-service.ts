import {
  type ActivityLog,
  type Customer,
  type Deal,
  type DealStage,
  type Lead,
  type Role,
  type Task,
  type TaskStatus,
  type TeamMember,
} from "@/types/domain";
import { now } from "@/lib/clock";
import { getActorId } from "@/lib/session";
import {
  convertLead as convertLeadRule,
  describeStageChange,
  genId,
  reorderDealToStage,
  topOrderForStage,
} from "@/lib/business";
import {
  type ConvertLeadResult,
  type CrmService,
  type CustomerInput,
  type DealInput,
  type LeadInput,
  type TaskInput,
} from "@/services/crm-service";
import { clone, ensureReady, getCache, mutate, resetDb } from "@/services/local/demo-db";
import { type Database } from "@/types/domain";

function nowIso(): string {
  return now().toISOString();
}

function logActivity(db: Database, entry: Omit<ActivityLog, "id" | "createdAt" | "actorId">): void {
  db.activity.unshift({ ...entry, actorId: getActorId(), id: genId("act"), createdAt: nowIso() });
}

/**
 * Demo adapter. Implements the full CrmService over the in-browser IndexedDB
 * database, recording activity-log entries for the operations a server would
 * audit. Swapping in a Supabase adapter requires no UI changes.
 */
export class LocalCrmService implements CrmService {
  async getDatabase() {
    return clone(await ensureReady());
  }

  // --- Members ------------------------------------------------------------
  async listMembers() {
    const db = await ensureReady();
    return clone(db.members);
  }
  async getMember(id: string) {
    const db = await ensureReady();
    return clone(db.members.find((m) => m.id === id) ?? null);
  }
  async updateMemberRole(id: string, role: Role) {
    let updated: TeamMember | undefined;
    await mutate((db) => {
      const member = db.members.find((m) => m.id === id);
      if (!member) throw new Error("Member not found");
      if (member.role !== role) {
        logActivity(db, {
          action: "team.role_changed",
          targetType: "member",
          targetId: member.id,
          targetLabel: member.name,
          detail: `Role set to ${role}`,
        });
      }
      member.role = role;
      updated = member;
    });
    return clone(updated!);
  }

  // --- Customers ----------------------------------------------------------
  async listCustomers() {
    const db = await ensureReady();
    return clone(db.customers);
  }
  async getCustomer(id: string) {
    const db = await ensureReady();
    return clone(db.customers.find((c) => c.id === id) ?? null);
  }
  async createCustomer(input: CustomerInput) {
    const customer: Customer = { ...input, id: genId("cust"), createdAt: nowIso(), updatedAt: nowIso() };
    await mutate((db) => {
      db.customers.unshift(customer);
      logActivity(db, {
        action: "customer.created",
        targetType: "customer",
        targetId: customer.id,
        targetLabel: `${customer.name} · ${customer.company}`,
        detail: `Added as ${customer.status}`,
      });
    });
    return clone(customer);
  }
  async updateCustomer(id: string, input: CustomerInput) {
    let updated: Customer | undefined;
    await mutate((db) => {
      const idx = db.customers.findIndex((c) => c.id === id);
      if (idx === -1) throw new Error("Customer not found");
      updated = { ...db.customers[idx], ...input, updatedAt: nowIso() };
      db.customers[idx] = updated;
      logActivity(db, {
        action: "customer.updated",
        targetType: "customer",
        targetId: id,
        targetLabel: `${updated.name} · ${updated.company}`,
        detail: "Details updated",
      });
    });
    return clone(updated!);
  }
  async deleteCustomer(id: string) {
    await this.deleteCustomers([id]);
  }
  async deleteCustomers(ids: string[]) {
    await mutate((db) => {
      for (const id of ids) {
        const customer = db.customers.find((c) => c.id === id);
        if (!customer) continue;
        db.customers = db.customers.filter((c) => c.id !== id);
        logActivity(db, {
          action: "customer.deleted",
          targetType: "customer",
          targetId: id,
          targetLabel: `${customer.name} · ${customer.company}`,
          detail: "Removed",
        });
      }
    });
  }

  // --- Leads --------------------------------------------------------------
  async listLeads() {
    const db = await ensureReady();
    return clone(db.leads);
  }
  async getLead(id: string) {
    const db = await ensureReady();
    return clone(db.leads.find((l) => l.id === id) ?? null);
  }
  async createLead(input: LeadInput) {
    const lead: Lead = {
      ...input,
      id: genId("lead"),
      createdAt: nowIso(),
      lastContactedAt: input.status === "new" ? null : nowIso(),
      convertedCustomerId: null,
      convertedDealId: null,
    };
    await mutate((db) => {
      db.leads.unshift(lead);
      logActivity(db, {
        action: "lead.created",
        targetType: "lead",
        targetId: lead.id,
        targetLabel: `${lead.name} · ${lead.company}`,
        detail: `Source: ${lead.source}`,
      });
    });
    return clone(lead);
  }
  async updateLead(id: string, input: LeadInput) {
    let updated: Lead | undefined;
    await mutate((db) => {
      const idx = db.leads.findIndex((l) => l.id === id);
      if (idx === -1) throw new Error("Lead not found");
      updated = { ...db.leads[idx], ...input };
      db.leads[idx] = updated;
      logActivity(db, {
        action: "lead.updated",
        targetType: "lead",
        targetId: id,
        targetLabel: `${updated.name} · ${updated.company}`,
        detail: `Status: ${updated.status}`,
      });
    });
    return clone(updated!);
  }
  async deleteLead(id: string) {
    await mutate((db) => {
      db.leads = db.leads.filter((l) => l.id !== id);
    });
  }
  async convertLead(id: string): Promise<ConvertLeadResult> {
    let result: ConvertLeadResult | undefined;
    await mutate((db) => {
      const outcome = convertLeadRule(db, id, getActorId(), nowIso());
      if (!outcome.linkedExistingCustomer) db.customers.unshift(outcome.customer);
      db.deals.unshift(outcome.deal);
      const idx = db.leads.findIndex((l) => l.id === id);
      db.leads[idx] = outcome.lead;
      db.activity.unshift(...outcome.activity);
      result = {
        customerId: outcome.customer.id,
        dealId: outcome.deal.id,
        linkedExistingCustomer: outcome.linkedExistingCustomer,
      };
    });
    return result!;
  }

  // --- Deals --------------------------------------------------------------
  async listDeals() {
    const db = await ensureReady();
    return clone(db.deals);
  }
  async getDeal(id: string) {
    const db = await ensureReady();
    return clone(db.deals.find((d) => d.id === id) ?? null);
  }
  async createDeal(input: DealInput) {
    await ensureReady();
    const deal: Deal = {
      ...input,
      id: genId("deal"),
      createdAt: nowIso(),
      updatedAt: nowIso(),
      order: topOrderForStage(getCache().deals, input.stage),
      sourceLeadId: null,
    };
    await mutate((db) => {
      db.deals.unshift(deal);
      logActivity(db, {
        action: "deal.created",
        targetType: "deal",
        targetId: deal.id,
        targetLabel: deal.name,
        detail: `Created in ${deal.stage}`,
      });
    });
    return clone(deal);
  }
  async updateDeal(id: string, input: DealInput) {
    let updated: Deal | undefined;
    await mutate((db) => {
      const idx = db.deals.findIndex((d) => d.id === id);
      if (idx === -1) throw new Error("Deal not found");
      const prev = db.deals[idx];
      updated = { ...prev, ...input, updatedAt: nowIso() };
      db.deals[idx] = updated;
      logActivity(db, {
        action: prev.stage !== input.stage ? "deal.stage_changed" : "deal.updated",
        targetType: "deal",
        targetId: id,
        targetLabel: updated.name,
        detail: prev.stage !== input.stage ? describeStageChange(updated, prev.stage, input.stage) : "Details updated",
      });
    });
    return clone(updated!);
  }
  async deleteDeal(id: string) {
    await mutate((db) => {
      const deal = db.deals.find((d) => d.id === id);
      db.deals = db.deals.filter((d) => d.id !== id);
      if (deal) {
        logActivity(db, {
          action: "deal.deleted",
          targetType: "deal",
          targetId: id,
          targetLabel: deal.name,
          detail: "Removed",
        });
      }
    });
  }
  async reorderDeal(id: string, toStage: DealStage, toIndex: number) {
    let result: Deal[] = [];
    await mutate((db) => {
      const prev = db.deals.find((d) => d.id === id);
      const fromStage = prev?.stage;
      db.deals = reorderDealToStage(db.deals, id, toStage, toIndex, nowIso());
      if (prev && fromStage !== toStage) {
        logActivity(db, {
          action: "deal.stage_changed",
          targetType: "deal",
          targetId: id,
          targetLabel: prev.name,
          detail: `Moved to ${toStage}`,
        });
      }
      result = clone(db.deals);
    });
    return result;
  }

  // --- Tasks --------------------------------------------------------------
  async listTasks() {
    const db = await ensureReady();
    return clone(db.tasks);
  }
  async createTask(input: TaskInput) {
    const task: Task = {
      ...input,
      id: genId("task"),
      createdAt: nowIso(),
      completedAt: input.status === "done" ? nowIso() : null,
    };
    await mutate((db) => {
      db.tasks.unshift(task);
      logActivity(db, {
        action: "task.created",
        targetType: "task",
        targetId: task.id,
        targetLabel: task.title,
        detail: "Assigned",
      });
    });
    return clone(task);
  }
  async updateTask(id: string, input: TaskInput) {
    let updated: Task | undefined;
    await mutate((db) => {
      const idx = db.tasks.findIndex((t) => t.id === id);
      if (idx === -1) throw new Error("Task not found");
      const prev = db.tasks[idx];
      updated = {
        ...prev,
        ...input,
        completedAt: input.status === "done" ? prev.completedAt ?? nowIso() : null,
      };
      db.tasks[idx] = updated;
    });
    return clone(updated!);
  }
  async setTaskStatus(id: string, status: TaskStatus) {
    let updated: Task | undefined;
    await mutate((db) => {
      const task = db.tasks.find((t) => t.id === id);
      if (!task) throw new Error("Task not found");
      task.status = status;
      task.completedAt = status === "done" ? nowIso() : null;
      updated = task;
      if (status === "done") {
        logActivity(db, {
          action: "task.completed",
          targetType: "task",
          targetId: id,
          targetLabel: task.title,
          detail: "Marked complete",
        });
      }
    });
    return clone(updated!);
  }
  async deleteTask(id: string) {
    await mutate((db) => {
      db.tasks = db.tasks.filter((t) => t.id !== id);
    });
  }

  // --- Activity -----------------------------------------------------------
  async listActivity() {
    const db = await ensureReady();
    return clone(db.activity);
  }

  async resetDemo() {
    await resetDb();
  }
}
