import { createBrowserClient } from "@supabase/ssr";

/**
 * Browser Supabase client, created from public env vars. Only the anon key is
 * ever exposed to the client; Row Level Security (see supabase/migrations)
 * enforces tenant isolation and role permissions on top of it.
 *
 * This is the foundation for a `SupabaseCrmService` that implements the same
 * `CrmService` interface the demo adapter does — wiring it into `getService()`
 * is all that's required to move from demo mode to a live backend. The UI never
 * changes because it only ever depends on the interface.
 */
export function createSupabaseBrowserClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anonKey) {
    throw new Error(
      "Supabase env vars are missing. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.",
    );
  }
  return createBrowserClient(url, anonKey);
}
