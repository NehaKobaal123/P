"use client";

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { type Role } from "@/types/domain";
import { dexieKeyvalStorage } from "@/services/local/dexie";

/**
 * Simulated session. This is NOT secure authentication — it only records which
 * demo role the visitor chose, so the UI can reflect role-based permissions.
 * Every visitor still has full local control of their own browser data.
 */

/** A representative seed member for each role (admin / manager / rep). */
export const ROLE_MEMBER_ID: Record<Role, string> = {
  admin: "member_1",
  manager: "member_2",
  rep: "member_4",
};

interface SessionState {
  userId: string;
  role: Role;
  /** True once a role has been explicitly chosen on the demo login screen. */
  authenticated: boolean;
  loginAs: (role: Role) => void;
  logout: () => void;
}

export const useSessionStore = create<SessionState>()(
  persist(
    (set) => ({
      userId: ROLE_MEMBER_ID.admin,
      role: "admin",
      authenticated: false,
      loginAs: (role) => set({ role, userId: ROLE_MEMBER_ID[role], authenticated: true }),
      logout: () => set({ role: "admin", userId: ROLE_MEMBER_ID.admin, authenticated: false }),
    }),
    {
      name: "session",
      storage: createJSONStorage(() => dexieKeyvalStorage),
    },
  ),
);
