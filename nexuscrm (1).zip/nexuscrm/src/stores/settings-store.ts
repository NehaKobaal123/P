"use client";

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { dexieKeyvalStorage } from "@/services/local/dexie";

interface SettingsState {
  organizationName: string;
  weeklyDigest: boolean;
  dealAlerts: boolean;
  taskReminders: boolean;
  setOrganizationName: (name: string) => void;
  toggle: (key: "weeklyDigest" | "dealAlerts" | "taskReminders", value: boolean) => void;
}

/** Per-viewer workspace preferences, persisted locally in demo mode. */
export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      organizationName: "Acme Revenue Co.",
      weeklyDigest: true,
      dealAlerts: true,
      taskReminders: false,
      setOrganizationName: (organizationName) => set({ organizationName }),
      toggle: (key, value) => set({ [key]: value } as Partial<SettingsState>),
    }),
    {
      name: "settings",
      storage: createJSONStorage(() => dexieKeyvalStorage),
    },
  ),
);
