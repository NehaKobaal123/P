import { describe, expect, it } from "vitest";
import {
  convertLead,
  LeadConversionError,
  reorderDealToStage,
  topOrderForStage,
} from "@/lib/business";
import { buildSeedDatabase } from "@/lib/demo/seed";
import { type Database } from "@/types/domain";

const AT = "2026-10-15T09:00:00.000Z";

function freshDb(): Database {
  return buildSeedDatabase();
}

describe("convertLead", () => {
  it("creates a customer and an open deal, and marks the lead converted", () => {
    const db = freshDb();
    const lead = db.leads.find((l) => l.status === "new" || l.status === "qualified")!;
    const before = db.customers.length;

    const result = convertLead(db, lead.id, "member_1", AT);

    expect(result.linkedExistingCustomer).toBe(false);
    expect(result.customer.name).toBe(lead.name);
    expect(result.deal.stage).toBe("qualified");
    expect(result.deal.value).toBe(lead.estimatedValue);
    expect(result.deal.sourceLeadId).toBe(lead.id);
    expect(result.lead.status).toBe("converted");
    expect(result.lead.convertedCustomerId).toBe(result.customer.id);
    // The rule is pure — it does not mutate the arrays itself.
    expect(db.customers.length).toBe(before);
  });

  it("is idempotent: a converted lead cannot be converted again", () => {
    const db = freshDb();
    const lead = db.leads.find((l) => l.status === "qualified")!;
    const result = convertLead(db, lead.id, "member_1", AT);
    // Simulate the service applying the result.
    db.customers.unshift(result.customer);
    db.deals.unshift(result.deal);
    const idx = db.leads.findIndex((l) => l.id === lead.id);
    db.leads[idx] = result.lead;

    expect(() => convertLead(db, lead.id, "member_1", AT)).toThrow(LeadConversionError);
  });

  it("links an existing customer by email instead of duplicating", () => {
    const db = freshDb();
    const existing = db.customers[0];
    const lead = db.leads.find((l) => l.status !== "converted" && l.status !== "lost")!;
    lead.email = existing.email; // same contact email

    const result = convertLead(db, lead.id, "member_1", AT);
    expect(result.linkedExistingCustomer).toBe(true);
    expect(result.customer.id).toBe(existing.id);
  });

  it("refuses to convert a lost lead", () => {
    const db = freshDb();
    const lead = db.leads.find((l) => l.status === "lost");
    if (!lead) return; // seed always includes lost leads, but guard anyway
    expect(() => convertLead(db, lead.id, "member_1", AT)).toThrow(/lost/i);
  });
});

describe("deal ordering", () => {
  it("topOrderForStage returns a value above the current top", () => {
    const db = freshDb();
    const order = topOrderForStage(db.deals, "qualified");
    const minInStage = Math.min(...db.deals.filter((d) => d.stage === "qualified").map((d) => d.order), 0);
    expect(order).toBeLessThanOrEqual(minInStage);
  });

  it("reorderDealToStage moves a deal to a new stage and reindexes", () => {
    const db = freshDb();
    const moving = db.deals.find((d) => d.stage === "new")!;
    const next = reorderDealToStage(db.deals, moving.id, "proposal", 0, AT);

    const moved = next.find((d) => d.id === moving.id)!;
    expect(moved.stage).toBe("proposal");
    expect(moved.order).toBe(0);

    // Orders within the target stage are unique and gap-free.
    const proposalOrders = next.filter((d) => d.stage === "proposal").map((d) => d.order).sort((a, b) => a - b);
    proposalOrders.forEach((o, i) => expect(o).toBe(i));
  });

  it("reordering within the same stage keeps the stage", () => {
    const db = freshDb();
    const column = db.deals.filter((d) => d.stage === "proposal");
    if (column.length < 2) return;
    const next = reorderDealToStage(db.deals, column[0].id, "proposal", 1, AT);
    expect(next.find((d) => d.id === column[0].id)!.stage).toBe("proposal");
  });
});
