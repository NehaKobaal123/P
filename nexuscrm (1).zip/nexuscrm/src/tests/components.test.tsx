import { describe, expect, it, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { DollarSign } from "lucide-react";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { DataPagination } from "@/components/common/data-pagination";
import { type Kpi } from "@/lib/metrics";

describe("KpiCard", () => {
  it("formats a currency KPI and renders its label and hint", () => {
    const kpi: Kpi = {
      key: "revenue", label: "Total Revenue", value: 40000,
      deltaPercent: 12.5, format: "currency", hint: "Closed-won value in range",
    };
    render(<KpiCard kpi={kpi} icon={DollarSign} />);
    expect(screen.getByText("Total Revenue")).toBeInTheDocument();
    expect(screen.getByText("$40K")).toBeInTheDocument();
    expect(screen.getByText("Closed-won value in range")).toBeInTheDocument();
  });

  it("renders a dash when the delta is unavailable", () => {
    const kpi: Kpi = {
      key: "deals", label: "Active Deals", value: 12,
      deltaPercent: null, format: "number", hint: "Open opportunities",
    };
    render(<KpiCard kpi={kpi} icon={DollarSign} />);
    expect(screen.getByText("12")).toBeInTheDocument();
    expect(screen.getByText("—")).toBeInTheDocument();
  });
});

describe("DataPagination", () => {
  it("shows the current range and disables Previous on page 1", () => {
    const onPageChange = vi.fn();
    render(<DataPagination page={1} pageSize={8} total={20} onPageChange={onPageChange} />);
    expect(screen.getByText("1–8 of 20")).toBeInTheDocument();
    expect(screen.getByLabelText("Previous page")).toBeDisabled();
  });

  it("advances the page when Next is clicked", () => {
    const onPageChange = vi.fn();
    render(<DataPagination page={1} pageSize={8} total={20} onPageChange={onPageChange} />);
    fireEvent.click(screen.getByLabelText("Next page"));
    expect(onPageChange).toHaveBeenCalledWith(2);
  });
});
