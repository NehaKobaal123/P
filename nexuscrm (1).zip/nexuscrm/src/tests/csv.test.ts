import { describe, expect, it } from "vitest";
import { toCsv } from "@/lib/csv";

interface Row {
  name: string;
  value: number;
  note: string;
}

const rows: Row[] = [
  { name: "Acme, Inc.", value: 1000, note: 'He said "hi"' },
  { name: "Line\nBreak Co", value: 2000, note: "plain" },
];

describe("toCsv", () => {
  it("writes a header row from the column definitions", () => {
    const csv = toCsv(rows, [
      { header: "Name", value: (r) => r.name },
      { header: "Value", value: (r) => r.value },
    ]);
    expect(csv.split("\n")[0]).toBe("Name,Value");
  });

  it("escapes commas, quotes and newlines", () => {
    const csv = toCsv(rows, [
      { header: "Name", value: (r) => r.name },
      { header: "Note", value: (r) => r.note },
    ]);
    expect(csv).toContain('"Acme, Inc."');
    expect(csv).toContain('"He said ""hi"""');
    expect(csv).toContain('"Line\nBreak Co"');
  });
});
