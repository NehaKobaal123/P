import { describe, expect, it } from "vitest";
import { type Customer, type Database, type Deal, type Lead } from "@/types/domain";
import {
  averageDealValue,
  conversionRate,
  dealsByStage,
  forecastPipelineValue,
  leadsBySource,
  openPipelineValue,
  pctChange,
  repPerformance,
  revenueByMonth,
  salesFunnel,
  totalRevenue,
  winRate,
} from "@/lib/metrics";
import { buildSeedDatabase } from "@/lib/demo/seed";

// --- Fixtures --------------------------------------------------------------

function deal(partial: Partial<Deal> & Pick<Deal, "id" | "stage" | "value">): Deal {
  return {
    name: partial.id, customerId: "c1", ownerId: "m1", priority: "medium",
    expectedCloseDate: "2026-10-01T00:00:00.000Z", createdAt: "2026-09-01T00:00:00.000Z",
    updatedAt: "2026-10-01T00:00:00.000Z", order: 0, sourceLeadId: null, ...partial,
  };
}

function lead(partial: Partial<Lead> & Pick<Lead, "id" | "status">): Lead {
  return {
    name: partial.id, company: "Co", email: `${partial.id}@co.com`, phone: "x",
    source: "Website", estimatedValue: 10000, assignedRepId: "m1", priority: "medium",
    createdAt: "2026-10-01T00:00:00.000Z", lastContactedAt: null,
    convertedCustomerId: null, convertedDealId: null, ...partial,
  };
}

const deals: Deal[] = [
  deal({ id: "d1", stage: "won", value: 10000 }),
  deal({ id: "d2", stage: "won", value: 30000 }),
  deal({ id: "d3", stage: "lost", value: 5000 }),
  deal({ id: "d4", stage: "proposal", value: 20000 }),
  deal({ id: "d5", stage: "new", value: 8000 }),
];

describe("revenue & deal metrics", () => {
  it("totalRevenue sums only won deals", () => {
    expect(totalRevenue(deals)).toBe(40000);
  });

  it("averageDealValue divides won revenue by won count", () => {
    expect(averageDealValue(deals)).toBe(20000);
  });

  it("winRate is won / (won + lost)", () => {
    expect(winRate(deals)).toBeCloseTo((2 / 3) * 100);
  });

  it("openPipelineValue counts only open stages", () => {
    expect(openPipelineValue(deals)).toBe(28000); // proposal 20k + new 8k
  });

  it("forecastPipelineValue weights open deals by stage probability", () => {
    // proposal 20000*0.55 + new 8000*0.1 = 11000 + 800
    expect(forecastPipelineValue(deals)).toBeCloseTo(11800);
  });

  it("dealsByStage reports counts and values per stage", () => {
    const stages = dealsByStage(deals);
    expect(stages.find((s) => s.stage === "won")?.count).toBe(2);
    expect(stages.find((s) => s.stage === "won")?.value).toBe(40000);
  });
});

describe("conversion & pctChange", () => {
  it("conversionRate = converted / total leads", () => {
    const leads = [lead({ id: "l1", status: "converted" }), lead({ id: "l2", status: "new" })];
    expect(conversionRate(leads)).toBe(50);
  });

  it("conversionRate is 0 for an empty set", () => {
    expect(conversionRate([])).toBe(0);
  });

  it("pctChange handles a zero baseline", () => {
    expect(pctChange(10, 0)).toBeNull();
    expect(pctChange(0, 0)).toBe(0);
    expect(pctChange(150, 100)).toBe(50);
  });
});

describe("source & funnel aggregation", () => {
  it("leadsBySource groups and omits empty sources", () => {
    const leads = [
      lead({ id: "l1", status: "new", source: "Referral", estimatedValue: 1000 }),
      lead({ id: "l2", status: "new", source: "Referral", estimatedValue: 2000 }),
    ];
    const result = leadsBySource(leads);
    const referral = result.find((r) => r.source === "Referral");
    expect(referral?.count).toBe(2);
    expect(referral?.value).toBe(3000);
    expect(result.find((r) => r.source === "Website")).toBeUndefined();
  });

  it("salesFunnel is monotonically non-increasing", () => {
    const db = buildSeedDatabase();
    const funnel = salesFunnel(db);
    for (let i = 1; i < funnel.length; i++) {
      expect(funnel[i].count).toBeLessThanOrEqual(funnel[i - 1].count);
    }
  });
});

describe("time series", () => {
  it("revenueByMonth returns exactly N buckets and reconciles with in-window revenue", () => {
    const months = revenueByMonth(deals, 12);
    expect(months).toHaveLength(12);
    // All fixture won deals close on 2026-10-01, within the last 12 months.
    const summed = months.reduce((s, m) => s + m.revenue, 0);
    expect(summed).toBe(40000);
  });
});

describe("seed-backed sanity", () => {
  const db: Database = buildSeedDatabase();

  it("produces positive revenue and a sensible conversion rate", () => {
    expect(totalRevenue(db.deals)).toBeGreaterThan(0);
    const rate = conversionRate(db.leads);
    expect(rate).toBeGreaterThanOrEqual(0);
    expect(rate).toBeLessThanOrEqual(100);
  });

  it("ranks reps by closed-won value (descending)", () => {
    const reps = repPerformance(db);
    for (let i = 1; i < reps.length; i++) {
      expect(reps[i - 1].wonValue).toBeGreaterThanOrEqual(reps[i].wonValue);
    }
  });

  it("every deal references a real customer and owner", () => {
    const customerIds = new Set(db.customers.map((c: Customer) => c.id));
    const memberIds = new Set(db.members.map((m) => m.id));
    for (const d of db.deals) {
      expect(customerIds.has(d.customerId)).toBe(true);
      expect(memberIds.has(d.ownerId)).toBe(true);
    }
  });
});
