/**
 * NexusCRM domain model.
 *
 * These types are the single source of truth for the shape of business data.
 * Both the local demo adapter and the (optional) Supabase adapter return
 * objects that satisfy these interfaces, so presentation code never needs to
 * know which backend is active.
 */

export type Role = "admin" | "manager" | "rep";

export const ROLES: Role[] = ["admin", "manager", "rep"];

export const ROLE_LABELS: Record<Role, string> = {
  admin: "Administrator",
  manager: "Manager",
  rep: "Sales Representative",
};

export type MemberStatus = "active" | "invited" | "inactive";

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: Role;
  status: MemberStatus;
  title: string;
  avatarColor: string;
  createdAt: string;
}

export type Industry =
  | "Technology"
  | "Healthcare"
  | "Finance"
  | "Retail"
  | "Manufacturing"
  | "Education"
  | "Real Estate"
  | "Media";

export const INDUSTRIES: Industry[] = [
  "Technology",
  "Healthcare",
  "Finance",
  "Retail",
  "Manufacturing",
  "Education",
  "Real Estate",
  "Media",
];

export type CustomerStatus = "prospect" | "active" | "at_risk" | "churned";

export const CUSTOMER_STATUSES: CustomerStatus[] = ["prospect", "active", "at_risk", "churned"];

export const CUSTOMER_STATUS_LABELS: Record<CustomerStatus, string> = {
  prospect: "Prospect",
  active: "Active",
  at_risk: "At Risk",
  churned: "Churned",
};

export interface Customer {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  industry: Industry;
  status: CustomerStatus;
  assignedRepId: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export type LeadSource =
  | "Website"
  | "Referral"
  | "Cold Outreach"
  | "Event"
  | "Partner"
  | "Advertisement"
  | "Social";

export const LEAD_SOURCES: LeadSource[] = [
  "Website",
  "Referral",
  "Cold Outreach",
  "Event",
  "Partner",
  "Advertisement",
  "Social",
];

export type LeadStatus = "new" | "contacted" | "qualified" | "proposal" | "converted" | "lost";

export const LEAD_STATUSES: LeadStatus[] = [
  "new",
  "contacted",
  "qualified",
  "proposal",
  "converted",
  "lost",
];

export const LEAD_STATUS_LABELS: Record<LeadStatus, string> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  proposal: "Proposal",
  converted: "Converted",
  lost: "Lost",
};

export type Priority = "low" | "medium" | "high";

export const PRIORITIES: Priority[] = ["low", "medium", "high"];

export const PRIORITY_LABELS: Record<Priority, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
};

export interface Lead {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  source: LeadSource;
  estimatedValue: number;
  assignedRepId: string;
  priority: Priority;
  status: LeadStatus;
  createdAt: string;
  lastContactedAt: string | null;
  convertedCustomerId: string | null;
  convertedDealId: string | null;
}

export type DealStage = "new" | "qualified" | "proposal" | "negotiation" | "won" | "lost";

export const DEAL_STAGES: DealStage[] = [
  "new",
  "qualified",
  "proposal",
  "negotiation",
  "won",
  "lost",
];

export const DEAL_STAGE_LABELS: Record<DealStage, string> = {
  new: "New Opportunity",
  qualified: "Qualified",
  proposal: "Proposal Sent",
  negotiation: "Negotiation",
  won: "Won",
  lost: "Lost",
};

/** Stages that count as still-open pipeline. */
export const OPEN_DEAL_STAGES: DealStage[] = ["new", "qualified", "proposal", "negotiation"];

/** Rough probability weighting per stage, used for weighted-pipeline forecasts. */
export const STAGE_WIN_PROBABILITY: Record<DealStage, number> = {
  new: 0.1,
  qualified: 0.3,
  proposal: 0.55,
  negotiation: 0.75,
  won: 1,
  lost: 0,
};

export interface Deal {
  id: string;
  name: string;
  customerId: string;
  value: number;
  ownerId: string;
  priority: Priority;
  stage: DealStage;
  expectedCloseDate: string;
  createdAt: string;
  updatedAt: string;
  /** Sort order within a stage column; smaller = higher on the board. */
  order: number;
  sourceLeadId: string | null;
}

export type TaskStatus = "todo" | "in_progress" | "done";

export const TASK_STATUSES: TaskStatus[] = ["todo", "in_progress", "done"];

export const TASK_STATUS_LABELS: Record<TaskStatus, string> = {
  todo: "To Do",
  in_progress: "In Progress",
  done: "Done",
};

export interface Task {
  id: string;
  title: string;
  description: string;
  assigneeId: string;
  priority: Priority;
  status: TaskStatus;
  dueDate: string;
  relatedCustomerId: string | null;
  relatedDealId: string | null;
  createdAt: string;
  completedAt: string | null;
}

export type ActivityAction =
  | "customer.created"
  | "customer.updated"
  | "customer.deleted"
  | "lead.created"
  | "lead.updated"
  | "lead.converted"
  | "deal.created"
  | "deal.updated"
  | "deal.stage_changed"
  | "deal.deleted"
  | "task.created"
  | "task.completed"
  | "task.assigned"
  | "team.role_changed";

export interface ActivityLog {
  id: string;
  actorId: string;
  action: ActivityAction;
  targetType: "customer" | "lead" | "deal" | "task" | "member";
  targetId: string;
  targetLabel: string;
  detail: string;
  createdAt: string;
}

/** The complete demo dataset, serialised to localStorage as one blob. */
export interface Database {
  version: number;
  members: TeamMember[];
  customers: Customer[];
  leads: Lead[];
  deals: Deal[];
  tasks: Task[];
  activity: ActivityLog[];
}
