# NexusCRM — Supabase

This directory contains the database schema, Row Level Security policies, auth
integration and an illustrative seed for running NexusCRM against a real
Supabase backend. **The app ships in demo mode and needs none of this to run** —
these files are the path to a server-backed deployment.

## Files

| File | Purpose |
| --- | --- |
| `migrations/0001_schema.sql` | Tables, enums, indexes, `updated_at` triggers |
| `migrations/0002_policies.sql` | RLS: tenant isolation + role-based authorization |
| `migrations/0003_auth.sql` | Auto-provision a profile on user signup |
| `seed.sql` | Minimal illustrative data to smoke-test a live database |

## Apply the schema

Using the [Supabase CLI](https://supabase.com/docs/guides/cli):

```bash
supabase start                 # local stack (optional)
supabase db reset              # applies migrations/ in order
psql "$DATABASE_URL" -f supabase/seed.sql   # optional sample rows
```

Or paste each migration, in order, into the Supabase SQL editor for a hosted
project.

## Security model

- **Tenant isolation.** Every business row carries an `organization_id`. RLS
  policies only expose rows whose organization the caller belongs to
  (`auth_is_member`).
- **Role-based authorization.** `admin` and `manager` may edit any record and
  delete; a `rep` may create and edit only records they own (`assigned_rep_id`
  / `owner_id` / `assignee_id`). Only `admin` manages the team and org settings.
  This mirrors `src/lib/permissions.ts`.
- **Least privilege.** The browser only ever receives the anon key. The
  service-role key is never shipped to the client and must never be committed.

## Wiring the app to Supabase

1. Create a Supabase project and apply the migrations above.
2. Copy `.env.example` to `.env.local` and set `NEXT_PUBLIC_SUPABASE_URL`,
   `NEXT_PUBLIC_SUPABASE_ANON_KEY` and `NEXT_PUBLIC_DATA_MODE=supabase`.
3. Implement a `SupabaseCrmService` that satisfies the `CrmService` interface
   (`src/services/crm-service.ts`) using `src/services/supabase/client.ts`, and
   return it from `getService()` when `isSupabaseConfigured()` is true.

Because every screen depends only on `CrmService`, no presentation code changes.
