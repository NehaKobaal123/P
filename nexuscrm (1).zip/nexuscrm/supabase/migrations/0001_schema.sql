-- NexusCRM — schema
-- Normalized multi-tenant schema. Every business row is owned by an
-- organization; all access is later constrained by Row Level Security
-- (see 0002_policies.sql).

create extension if not exists "pgcrypto";

-- Enumerated domains keep invalid values out of the database.
create type crm_role            as enum ('admin', 'manager', 'rep');
create type member_status       as enum ('active', 'invited', 'inactive');
create type customer_status     as enum ('prospect', 'active', 'at_risk', 'churned');
create type lead_status         as enum ('new', 'contacted', 'qualified', 'proposal', 'converted', 'lost');
create type deal_stage          as enum ('new', 'qualified', 'proposal', 'negotiation', 'won', 'lost');
create type task_status         as enum ('todo', 'in_progress', 'done');
create type priority_level      as enum ('low', 'medium', 'high');

-- Organizations -------------------------------------------------------------
create table organizations (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  created_at timestamptz not null default now()
);

-- Profiles (1:1 with auth.users) --------------------------------------------
create table profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  full_name    text not null,
  email        text not null,
  title        text not null default '',
  avatar_color text not null default '#4F46E5',
  created_at   timestamptz not null default now()
);

-- Organization membership (join table) --------------------------------------
create table organization_members (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations (id) on delete cascade,
  user_id         uuid not null references profiles (id) on delete cascade,
  role            crm_role not null default 'rep',
  status          member_status not null default 'active',
  created_at      timestamptz not null default now(),
  unique (organization_id, user_id)
);
create index on organization_members (user_id);
create index on organization_members (organization_id);

-- Customers -----------------------------------------------------------------
create table customers (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references organizations (id) on delete cascade,
  name             text not null,
  company          text not null,
  email            text not null,
  phone            text not null default '',
  industry         text not null default 'Technology',
  status           customer_status not null default 'prospect',
  assigned_rep_id  uuid references profiles (id) on delete set null,
  notes            text not null default '',
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index on customers (organization_id);
create index on customers (assigned_rep_id);
create index on customers (organization_id, status);

-- Leads ---------------------------------------------------------------------
create table leads (
  id                    uuid primary key default gen_random_uuid(),
  organization_id       uuid not null references organizations (id) on delete cascade,
  name                  text not null,
  company               text not null,
  email                 text not null,
  phone                 text not null default '',
  source                text not null default 'Website',
  estimated_value       numeric(12,2) not null default 0 check (estimated_value >= 0),
  assigned_rep_id       uuid references profiles (id) on delete set null,
  priority              priority_level not null default 'medium',
  status                lead_status not null default 'new',
  last_contacted_at     timestamptz,
  converted_customer_id uuid references customers (id) on delete set null,
  converted_deal_id     uuid,
  created_at            timestamptz not null default now()
);
create index on leads (organization_id);
create index on leads (organization_id, status);

-- Deals ---------------------------------------------------------------------
create table deals (
  id                  uuid primary key default gen_random_uuid(),
  organization_id     uuid not null references organizations (id) on delete cascade,
  name                text not null,
  customer_id         uuid references customers (id) on delete set null,
  value               numeric(12,2) not null default 0 check (value >= 0),
  owner_id            uuid references profiles (id) on delete set null,
  priority            priority_level not null default 'medium',
  stage               deal_stage not null default 'new',
  expected_close_date date not null,
  sort_order          integer not null default 0,
  source_lead_id      uuid references leads (id) on delete set null,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index on deals (organization_id);
create index on deals (organization_id, stage);
create index on deals (owner_id);

-- Close the lead → deal reference now that deals exists.
alter table leads
  add constraint leads_converted_deal_fk
  foreign key (converted_deal_id) references deals (id) on delete set null;

-- Tasks ---------------------------------------------------------------------
create table tasks (
  id                  uuid primary key default gen_random_uuid(),
  organization_id     uuid not null references organizations (id) on delete cascade,
  title               text not null,
  description         text not null default '',
  assignee_id         uuid references profiles (id) on delete set null,
  priority            priority_level not null default 'medium',
  status              task_status not null default 'todo',
  due_date            date not null,
  related_customer_id uuid references customers (id) on delete set null,
  related_deal_id     uuid references deals (id) on delete set null,
  completed_at        timestamptz,
  created_at          timestamptz not null default now()
);
create index on tasks (organization_id);
create index on tasks (assignee_id);
create index on tasks (organization_id, status);

-- Activity log --------------------------------------------------------------
create table activity_logs (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations (id) on delete cascade,
  actor_id        uuid references profiles (id) on delete set null,
  action          text not null,
  target_type     text not null,
  target_id       uuid,
  target_label    text not null default '',
  detail          text not null default '',
  created_at      timestamptz not null default now()
);
create index on activity_logs (organization_id, created_at desc);

-- User preferences ----------------------------------------------------------
create table user_preferences (
  user_id    uuid primary key references profiles (id) on delete cascade,
  theme      text not null default 'system',
  settings   jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- updated_at maintenance ----------------------------------------------------
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

create trigger customers_updated_at before update on customers
  for each row execute function set_updated_at();
create trigger deals_updated_at before update on deals
  for each row execute function set_updated_at();
