-- NexusCRM — Row Level Security
-- Tenant isolation + role-based authorization enforced in the database, so the
-- frontend is never the only gatekeeper (principle of least privilege).

-- Helper functions run as SECURITY DEFINER so membership checks inside policies
-- do not recurse through the same policies they guard.

create or replace function auth_is_member(org uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from organization_members m
    where m.organization_id = org and m.user_id = auth.uid()
  );
$$;

create or replace function auth_can_manage(org uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from organization_members m
    where m.organization_id = org
      and m.user_id = auth.uid()
      and m.role in ('admin', 'manager')
  );
$$;

create or replace function auth_is_admin(org uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from organization_members m
    where m.organization_id = org
      and m.user_id = auth.uid()
      and m.role = 'admin'
  );
$$;

alter table organizations        enable row level security;
alter table profiles             enable row level security;
alter table organization_members enable row level security;
alter table customers            enable row level security;
alter table leads                enable row level security;
alter table deals                enable row level security;
alter table tasks                enable row level security;
alter table activity_logs        enable row level security;
alter table user_preferences     enable row level security;

-- Organizations -------------------------------------------------------------
create policy org_select on organizations for select
  using (auth_is_member(id));
create policy org_update on organizations for update
  using (auth_is_admin(id)) with check (auth_is_admin(id));

-- Profiles: you can read profiles that share an org with you; edit only yours.
create policy profile_select_self on profiles for select
  using (
    id = auth.uid()
    or exists (
      select 1 from organization_members me
      join organization_members them on them.organization_id = me.organization_id
      where me.user_id = auth.uid() and them.user_id = profiles.id
    )
  );
create policy profile_upsert_self on profiles for insert with check (id = auth.uid());
create policy profile_update_self on profiles for update using (id = auth.uid());

-- Membership: members read their org roster; only admins mutate it.
create policy members_select on organization_members for select
  using (auth_is_member(organization_id));
create policy members_insert on organization_members for insert
  with check (auth_is_admin(organization_id));
create policy members_update on organization_members for update
  using (auth_is_admin(organization_id)) with check (auth_is_admin(organization_id));
create policy members_delete on organization_members for delete
  using (auth_is_admin(organization_id));

-- Generic record policies (customers, leads, tasks) -------------------------
-- SELECT: any member of the owning org.
-- INSERT/UPDATE: managers/admins freely; reps on records they own.
-- DELETE: managers/admins only.

create policy customers_select on customers for select using (auth_is_member(organization_id));
create policy customers_insert on customers for insert with check (
  auth_is_member(organization_id) and (auth_can_manage(organization_id) or assigned_rep_id = auth.uid())
);
create policy customers_update on customers for update using (
  auth_can_manage(organization_id) or assigned_rep_id = auth.uid()
);
create policy customers_delete on customers for delete using (auth_can_manage(organization_id));

create policy leads_select on leads for select using (auth_is_member(organization_id));
create policy leads_insert on leads for insert with check (
  auth_is_member(organization_id) and (auth_can_manage(organization_id) or assigned_rep_id = auth.uid())
);
create policy leads_update on leads for update using (
  auth_can_manage(organization_id) or assigned_rep_id = auth.uid()
);
create policy leads_delete on leads for delete using (auth_can_manage(organization_id));

create policy tasks_select on tasks for select using (auth_is_member(organization_id));
create policy tasks_insert on tasks for insert with check (
  auth_is_member(organization_id) and (auth_can_manage(organization_id) or assignee_id = auth.uid())
);
create policy tasks_update on tasks for update using (
  auth_can_manage(organization_id) or assignee_id = auth.uid()
);
create policy tasks_delete on tasks for delete using (auth_can_manage(organization_id));

-- Deals use owner_id as the ownership column.
create policy deals_select on deals for select using (auth_is_member(organization_id));
create policy deals_insert on deals for insert with check (
  auth_is_member(organization_id) and (auth_can_manage(organization_id) or owner_id = auth.uid())
);
create policy deals_update on deals for update using (
  auth_can_manage(organization_id) or owner_id = auth.uid()
);
create policy deals_delete on deals for delete using (auth_can_manage(organization_id));

-- Activity log: full log is manager/admin only; any member may append entries.
create policy activity_select on activity_logs for select using (auth_can_manage(organization_id));
create policy activity_insert on activity_logs for insert with check (auth_is_member(organization_id));

-- Preferences: strictly your own.
create policy prefs_all on user_preferences for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());
