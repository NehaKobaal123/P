-- NexusCRM — illustrative seed data
-- Safe to run after the migrations to smoke-test the schema. It creates one
-- organization and a handful of rows with no assigned rep (reps require real
-- auth users). The application's full synthetic dataset is generated in the
-- browser for demo mode; this file is only for verifying a live database.

insert into organizations (id, name)
values ('00000000-0000-0000-0000-000000000001', 'Acme Revenue Co.')
on conflict do nothing;

insert into customers (organization_id, name, company, email, industry, status)
values
  ('00000000-0000-0000-0000-000000000001', 'Ava Reyes',   'Vertex Systems', 'ava@vertex.com',   'Technology',    'active'),
  ('00000000-0000-0000-0000-000000000001', 'Marcus Haddad','Lumen Analytics','marcus@lumen.com', 'Finance',       'prospect'),
  ('00000000-0000-0000-0000-000000000001', 'Priya Patel',  'Cobalt Health',  'priya@cobalt.com', 'Healthcare',    'at_risk');

insert into leads (organization_id, name, company, email, source, estimated_value, priority, status)
values
  ('00000000-0000-0000-0000-000000000001', 'Theo Novak',  'Harbor Media', 'theo@harbor.com',  'Referral', 24000, 'high',   'qualified'),
  ('00000000-0000-0000-0000-000000000001', 'Nina Serrano','Orbit Works',  'nina@orbit.com',   'Website',  12000, 'medium', 'new');

insert into deals (organization_id, name, value, stage, priority, expected_close_date, customer_id)
select
  '00000000-0000-0000-0000-000000000001',
  c.company || ' — Platform Deal',
  45000, 'proposal', 'high', current_date + 30, c.id
from customers c
where c.organization_id = '00000000-0000-0000-0000-000000000001'
limit 2;

insert into tasks (organization_id, title, priority, status, due_date)
values
  ('00000000-0000-0000-0000-000000000001', 'Follow up on proposal', 'high',   'todo',        current_date + 2),
  ('00000000-0000-0000-0000-000000000001', 'Schedule discovery call','medium','in_progress', current_date + 5);
